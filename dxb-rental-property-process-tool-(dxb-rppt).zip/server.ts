import express from 'express';
import multer from 'multer';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// Set up Multer for handling file uploads in memory
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
});

app.use(express.json({ limit: '25mb' }));

// Initialize Google Gemini API
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  aiClient = new GoogleGenAI({ apiKey });
}

// Extraction API
app.post('/api/extract', upload.single('file'), async (req, res) => {
  try {
    const documentType = req.body.documentType || 'contract';
    let fileBuffer: Buffer | null = null;
    let mimeType = 'image/jpeg';

    if (req.file) {
      fileBuffer = req.file.buffer;
      mimeType = req.file.mimetype;
    } else if (req.body.fileData) {
      // Base64 encoded file
      const matches = req.body.fileData.match(/^data:([A-Za-z-+/]+);base64,(.+)$/);
      if (matches && matches.length === 3) {
        mimeType = matches[1];
        fileBuffer = Buffer.from(matches[2], 'base64');
      } else {
        fileBuffer = Buffer.from(req.body.fileData, 'base64');
        if (req.body.mimeType) mimeType = req.body.mimeType;
      }
    }

    if (!fileBuffer) {
      return res.status(400).json({ error: 'No file provided for extraction.' });
    }

    // Call Gemini API if available
    if (aiClient) {
      let prompt = '';
      if (documentType === 'contract') {
        prompt = `You are a UAE Tenancy Contract (Ejari) processing engine. Analyze this document and extract the exact details as JSON.
Format required:
{
  "ownerName": "Full owner/landlord name",
  "buildingName": "Building/Tower or Community name",
  "propertyNo": "Unit/Apartment/Villa/Shop number (e.g., Apt 1402)",
  "type": "Residential or Commercial",
  "subType": "Apartment, Villa, Office, Retail, or Warehouse",
  "size": number in sq ft (e.g. 1150),
  "tenantName": "Tenant full name or company name",
  "contractAmount": total rental contract amount in AED as number,
  "actualAnnualAmount": actual annual rent amount in AED as number,
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD",
  "securityDeposit": security deposit in AED as number (default 0 if not stated),
  "lessorName": "Lessor/Management company name",
  "registrationDate": "Ejari registration date YYYY-MM-DD"
}
Ensure numeric values have no commas or currency symbols. If unknown, use reasonable estimates or null.`;
      } else if (documentType === 'receipt') {
        prompt = `You are a UAE Rental Receipt / Cheque processing engine. Analyze this receipt and extract details as JSON.
Format required:
{
  "propertyNo": "Property or unit number if mentioned",
  "tenantName": "Tenant name if mentioned",
  "installmentDate": "YYYY-MM-DD",
  "amount": amount in AED as number,
  "chequeNo": "cheque number",
  "bankName": "Bank name (e.g., Emirates NBD, ADCB, FAB, DIB, Mashreq)",
  "status": "Deposited, Cleared, or Pending"
}
Ensure numeric values are numbers.`;
      } else if (documentType === 'invoice') {
        prompt = `You are a UAE Purchase Tax Invoice processing engine for property maintenance.
Analyze this invoice and extract details as JSON conforming to UAE Federal Tax Authority (FTA) 5% VAT rules.
Format required:
{
  "invoiceNumber": "Invoice number or reference",
  "invoiceDate": "YYYY-MM-DD",
  "supplierName": "Supplier / Contractor company name",
  "supplierTRN": "15-digit UAE Tax Registration Number (TRN) if present",
  "propertyNo": "Property/Unit/Building serviced",
  "buildingName": "Building name",
  "description": "Summary of maintenance / service work done",
  "totalInvoiceAmount": total invoice amount including VAT in AED as number,
  "netAmount": net amount before VAT in AED as number,
  "taxAmount": VAT 5% amount in AED as number
}`;
      } else if (documentType === 'statement') {
        prompt = `You are a UAE Bank Statement parsing engine. Analyze this bank statement page/snippet and extract the transactions.
Format required:
{
  "bankName": "Bank name",
  "accountNumber": "Account number if visible",
  "statementPeriod": "Period string e.g. Oct 2026",
  "transactions": [
    {
      "transactionDate": "YYYY-MM-DD",
      "transactionName": "Description or transaction details / payee",
      "chequeNumber": "cheque number if applicable",
      "debitAmount": debit / expense amount in AED as number (0 if credit),
      "creditAmount": credit / deposit amount in AED as number (0 if debit),
      "netBalance": running balance in AED as number
    }
  ]
}`;
      }

      const response = await aiClient.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  mimeType: mimeType === 'application/pdf' ? 'application/pdf' : (mimeType.startsWith('image/') ? mimeType : 'image/jpeg'),
                  data: fileBuffer.toString('base64'),
                },
              },
              {
                text: prompt,
              },
            ],
          },
        ],
        config: {
          responseMimeType: 'application/json',
        },
      });

      const text = response.text || '{}';
      try {
        const parsed = JSON.parse(text);
        return res.json({ success: true, data: parsed });
      } catch (e) {
        return res.json({ success: true, raw: text });
      }
    } else {
      // Fallback heuristics for prototyping if GEMINI_API_KEY is not set
      // Returns structured template based on document type
      const defaultData: Record<string, any> = {
        contract: {
          ownerName: "Emaar Properties PJSC",
          buildingName: "Downtown Heights Tower A",
          propertyNo: "Unit 1402",
          type: "Residential",
          subType: "Apartment",
          size: 1250,
          tenantName: "Mohammed Al Hashimi",
          contractAmount: 110000,
          actualAnnualAmount: 110000,
          startDate: "2026-01-01",
          endDate: "2026-12-31",
          securityDeposit: 5500,
          lessorName: "Emaar Real Estate Asset Management",
          registrationDate: "2025-12-28",
        },
        receipt: {
          propertyNo: "Unit 1402",
          tenantName: "Mohammed Al Hashimi",
          installmentDate: "2026-01-05",
          amount: 27500,
          chequeNo: "CHQ-889102",
          bankName: "Emirates NBD",
          status: "Cleared",
        },
        invoice: {
          invoiceNumber: "INV-2026-0914",
          invoiceDate: "2026-02-12",
          supplierName: "Al Futtaim Engineering & Air Conditioning LLC",
          supplierTRN: "100234567800003",
          propertyNo: "Unit 1402",
          buildingName: "Downtown Heights Tower A",
          description: "Annual HVAC Chiller Servicing and Filter Replacement",
          totalInvoiceAmount: 3150,
          netAmount: 3000,
          taxAmount: 150,
        },
        statement: {
          bankName: "Emirates NBD",
          accountNumber: "101-9876543-01",
          statementPeriod: "Q1 2026",
          transactions: [
            {
              transactionDate: "2026-01-06",
              transactionName: "Cheque Deposit - Mohammed Al Hashimi CHQ-889102",
              chequeNumber: "889102",
              debitAmount: 0,
              creditAmount: 27500,
              netBalance: 127500,
            },
            {
              transactionDate: "2026-02-15",
              transactionName: "Debit Card / Wire - Al Futtaim Engineering INV-2026-0914",
              chequeNumber: "",
              debitAmount: 3150,
              creditAmount: 0,
              netBalance: 124350,
            },
          ],
        },
      };

      return res.json({
        success: true,
        data: defaultData[documentType] || defaultData.contract,
        note: 'Fallback simulation (Gemini API key not configured). Upload parsed successfully.',
      });
    }
  } catch (error: any) {
    console.error('Extraction error:', error);
    return res.status(500).json({
      error: 'Failed to extract document contents',
      details: error?.message || String(error),
    });
  }
});

// Mount Vite or serve static assets
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, () => {
    console.log(`DXB-RPPT Server running on http://0.0.0.0:${port}`);
  });
}

startServer();
