# Security Specification for DXB-RPPT

## 1. Data Invariants
1. A Tenancy Contract, Rental Receipt, or Purchase Tax Invoice document must contain valid property structures, valid numeric amounts (AED), and cannot be created without a valid owner UID matching the authenticated user.
2. User profiles can only be written by the user themselves (or the admin). A user cannot self-assign the `admin` role unless they match the bootstrapped admin email `velayudham.e@gmail.com`.
3. Read access to user documents is restricted to signed-in users for their own documents, or admins.
4. Updates to contracts, receipts, and invoices are limited to the creator or users with `admin` / `manager` / `accountant` roles.

## 2. The Dirty Dozen Payloads
1. Contract creation with mismatched `userId != request.auth.uid`. (Expected: PERMISSION_DENIED)
2. Contract creation with negative `contractAmount`. (Expected: PERMISSION_DENIED)
3. User profile creation self-assigning `role = "admin"` from non-admin email. (Expected: PERMISSION_DENIED)
4. Reading another user's contract document without admin privileges. (Expected: PERMISSION_DENIED)
5. Unauthenticated read or write to any collection. (Expected: PERMISSION_DENIED)
6. Updating a contract's immutable `id` or `userId`. (Expected: PERMISSION_DENIED)
7. Injecting oversized string (>5000 chars) into building or tenant name. (Expected: PERMISSION_DENIED)
8. Invoicing record creation with negative tax amount. (Expected: PERMISSION_DENIED)
9. Tampering with another user's receipts. (Expected: PERMISSION_DENIED)
10. Setting random unapproved role such as `superhero`. (Expected: PERMISSION_DENIED)
11. Deleting a contract by a `viewer` role user. (Expected: PERMISSION_DENIED)
12. Blanket list queries bypassing security filters. (Expected: PERMISSION_DENIED)
