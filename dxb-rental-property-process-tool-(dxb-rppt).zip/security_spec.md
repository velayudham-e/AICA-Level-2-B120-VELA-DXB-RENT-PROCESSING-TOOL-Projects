# Security Specification for DXB-RPPT

## 1. Data Invariants
- Only authenticated users can access the system.
- Users can view and manage property tenancy contracts, receipts, invoices, and bank statements if they are authenticated members of the system.
- Admins have full access to manage roles and user permissions.
- Invariants: A document cannot be saved with unauthorized fields or oversized strings.
- Users cannot self-escalate roles without admin rights.
- Initial admin is bootstrapped with user email `aelogan81@gmail.com`.

## 2. Dirty Dozen Payloads (Simulated Threat Vectors)
1. User profile tampering: User sets role='admin' without admin privileges -> REJECTED.
2. Unauthenticated reads: Anonymous query to `/tenancyContracts` -> REJECTED.
3. String payload explosion: `propertyNo` greater than 100 characters -> REJECTED.
4. Schema pollution: Extra ghost field `secretBackdoor: true` inside contract -> REJECTED.
5. Injected Document ID: docId with illegal characters `../hack` -> REJECTED.
6. Email spoofing: unverified email impersonating admin -> REJECTED.
7. Negative amount injection: Negative contract amount or corrupt numbers -> REJECTED.
8. Orphaned Receipts: Receipt created without authenticated author -> REJECTED.
9. Malicious updates: Non-admin changing another user's role -> REJECTED.
10. SQL/Script injection inside transactionName -> sanitized by length & type constraint.
11. Admin table write by non-admin -> REJECTED.
12. Blanket list queries without auth -> REJECTED.
