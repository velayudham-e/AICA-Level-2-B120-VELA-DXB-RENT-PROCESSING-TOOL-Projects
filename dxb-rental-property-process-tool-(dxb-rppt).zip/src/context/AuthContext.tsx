import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
} from 'firebase/auth';
import { auth, googleProvider } from '../lib/firebase';
import { getUserProfile, upsertUserProfile } from '../services/dbService';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  activeRole: UserRole;
  isAdmin: boolean;
  canEdit: boolean;
  canUpload: boolean;
  canManageUsers: boolean;
  canExportFinances: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, name: string, preferredRole?: UserRole) => Promise<void>;
  logout: () => Promise<void>;
  setActiveRoleOverride: (role: UserRole | null) => void;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const BOOTSTRAP_ADMIN_EMAIL = 'velayudham.e@gmail.com';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [roleOverride, setRoleOverride] = useState<UserRole | null>(null);

  const fetchOrCreateProfile = async (firebaseUser: User, desiredRole?: UserRole) => {
    try {
      const existing = await getUserProfile(firebaseUser.uid);
      const isMasterAdmin =
        firebaseUser.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase();

      if (existing) {
        // Ensure master admin always retains admin role
        if (isMasterAdmin && existing.role !== 'admin') {
          const updated = { ...existing, role: 'admin' as UserRole };
          await upsertUserProfile(updated);
          setProfile(updated);
        } else {
          setProfile(existing);
        }
      } else {
        const assignedRole: UserRole = isMasterAdmin ? 'admin' : desiredRole || 'manager';
        const newProfile: UserProfile = {
          userId: firebaseUser.uid,
          email: firebaseUser.email || '',
          displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
          role: assignedRole,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        await upsertUserProfile(newProfile);
        setProfile(newProfile);
      }
    } catch (err) {
      console.error('Error fetching or creating profile:', err);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        await fetchOrCreateProfile(currentUser);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    setLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        await fetchOrCreateProfile(result.user);
      }
    } finally {
      setLoading(false);
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const result = await signInWithEmailAndPassword(auth, email, pass);
      if (result.user) {
        await fetchOrCreateProfile(result.user);
      }
    } finally {
      setLoading(false);
    }
  };

  const signUpWithEmail = async (
    email: string,
    pass: string,
    name: string,
    preferredRole?: UserRole
  ) => {
    setLoading(true);
    try {
      const result = await createUserWithEmailAndPassword(auth, email, pass);
      if (result.user) {
        await updateProfile(result.user, { displayName: name });
        await fetchOrCreateProfile(result.user, preferredRole);
      }
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    await signOut(auth);
    setProfile(null);
    setRoleOverride(null);
  };

  const refreshProfile = async () => {
    if (user) {
      await fetchOrCreateProfile(user);
    }
  };

  const isMaster = user?.email?.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL.toLowerCase();
  const effectiveRole: UserRole =
    roleOverride || profile?.role || (isMaster ? 'admin' : 'viewer');

  const isAdmin = effectiveRole === 'admin';
  const canEdit = ['admin', 'manager', 'accountant'].includes(effectiveRole);
  const canUpload = ['admin', 'manager'].includes(effectiveRole);
  const canManageUsers = isAdmin;
  const canExportFinances = ['admin', 'manager', 'accountant'].includes(effectiveRole);

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        loading,
        activeRole: effectiveRole,
        isAdmin,
        canEdit,
        canUpload,
        canManageUsers,
        canExportFinances,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        logout,
        setActiveRoleOverride: setRoleOverride,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
