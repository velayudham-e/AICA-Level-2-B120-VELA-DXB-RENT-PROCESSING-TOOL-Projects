import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  signInWithPopup,
  signOut as fbSignOut,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, googleProvider, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  role: UserRole;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, name: string) => Promise<void>;
  signOut: () => Promise<void>;
  switchDemoRole: (newRole: UserRole) => void;
  canEdit: boolean;
  canDelete: boolean;
  canManageUsers: boolean;
  canReconcile: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ADMIN_EMAIL = 'aelogan81@gmail.com';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [role, setRole] = useState<UserRole>('admin');
  const [loading, setLoading] = useState<boolean>(true);

  // Sync Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userRef = doc(db, 'users', currentUser.uid);
          const snap = await getDoc(userRef);

          let userRole: UserRole = 'manager';
          if (currentUser.email === ADMIN_EMAIL) {
            userRole = 'admin';
          }

          if (snap.exists()) {
            const data = snap.data();
            const fetchedRole = (data.role as UserRole) || (currentUser.email === ADMIN_EMAIL ? 'admin' : 'manager');
            const userProf: UserProfile = {
              uid: currentUser.uid,
              email: currentUser.email || '',
              displayName: currentUser.displayName || data.displayName || 'UAE Real Estate Officer',
              role: fetchedRole,
              photoURL: currentUser.photoURL || '',
              createdAt: data.createdAt || new Date().toISOString(),
            };
            setProfile(userProf);
            setRole(userProf.role);
          } else {
            // New user registration in Firestore
            const initialRole: UserRole = currentUser.email === ADMIN_EMAIL ? 'admin' : 'manager';
            const newProf: UserProfile = {
              uid: currentUser.uid,
              email: currentUser.email || '',
              displayName: currentUser.displayName || currentUser.email?.split('@')[0] || 'Property Specialist',
              role: initialRole,
              photoURL: currentUser.photoURL || '',
              createdAt: new Date().toISOString(),
            };
            await setDoc(userRef, newProf);
            setProfile(newProf);
            setRole(initialRole);
          }
        } catch (error) {
          console.error('Error fetching/setting user profile:', error);
          // Set fallback profile for smooth user experience
          const fallbackRole: UserRole = currentUser.email === ADMIN_EMAIL ? 'admin' : 'manager';
          setProfile({
            uid: currentUser.uid,
            email: currentUser.email || 'user@example.com',
            displayName: currentUser.displayName || 'Property Specialist',
            role: fallbackRole,
            createdAt: new Date().toISOString(),
          });
          setRole(fallbackRole);
        }
      } else {
        // Fallback default admin profile for immediate demo exploration
        setProfile({
          uid: 'demo-admin-uid',
          email: ADMIN_EMAIL,
          displayName: 'Finance Director (AED Admin)',
          role: 'admin',
          createdAt: new Date().toISOString(),
        });
        setRole('admin');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    setLoading(true);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      console.error('Google Sign-In Error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, pass);
    } catch (err) {
      console.error('Email Sign-In Error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signUpWithEmail = async (email: string, pass: string, name: string) => {
    setLoading(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      if (cred.user) {
        await updateProfile(cred.user, { displayName: name });
        const userRole: UserRole = email === ADMIN_EMAIL ? 'admin' : 'manager';
        const newProf: UserProfile = {
          uid: cred.user.uid,
          email,
          displayName: name,
          role: userRole,
          createdAt: new Date().toISOString(),
        };
        try {
          await setDoc(doc(db, 'users', cred.user.uid), newProf);
        } catch (e) {
          handleFirestoreError(e, OperationType.WRITE, `users/${cred.user.uid}`);
        }
        setProfile(newProf);
        setRole(userRole);
      }
    } catch (err) {
      console.error('Email Sign-Up Error:', err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      await fbSignOut(auth);
      setProfile(null);
      setUser(null);
    } catch (err) {
      console.error('Sign-Out Error:', err);
    }
  };

  // Demo role switch allows reviewer or accountant to test RBAC live
  const switchDemoRole = (newRole: UserRole) => {
    setRole(newRole);
    if (profile) {
      setProfile({ ...profile, role: newRole });
    }
  };

  // RBAC permissions matrix
  const canEdit = role === 'admin' || role === 'manager' || role === 'accountant';
  const canDelete = role === 'admin' || role === 'manager';
  const canManageUsers = role === 'admin';
  const canReconcile = role === 'admin' || role === 'accountant' || role === 'manager';

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        role,
        loading,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        signOut,
        switchDemoRole,
        canEdit,
        canDelete,
        canManageUsers,
        canReconcile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
