import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  collection,
  onSnapshot,
  setDoc,
  deleteDoc,
  doc,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from './AuthContext';
import {
  TenancyContract,
  Receipt,
  PurchaseInvoice,
  BankStatement,
  DashboardMetrics,
  FilterState,
} from '../types';

interface PropertyDataContextType {
  contracts: TenancyContract[];
  receipts: Receipt[];
  invoices: PurchaseInvoice[];
  bankStatements: BankStatement[];
  loading: boolean;
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  // CRUD
  addContract: (contract: Omit<TenancyContract, 'id' | 'createdBy' | 'createdAt'>) => Promise<{ success: boolean; error?: string }>;
  updateContract: (id: string, updates: Partial<TenancyContract>) => Promise<{ success: boolean; error?: string }>;
  deleteContract: (id: string) => Promise<{ success: boolean; error?: string }>;

  addReceipt: (receipt: Omit<Receipt, 'id' | 'createdBy' | 'createdAt'>) => Promise<{ success: boolean; error?: string }>;
  updateReceipt: (id: string, updates: Partial<Receipt>) => Promise<{ success: boolean; error?: string }>;
  deleteReceipt: (id: string) => Promise<{ success: boolean; error?: string }>;

  addInvoice: (invoice: Omit<PurchaseInvoice, 'id' | 'createdBy' | 'createdAt'>) => Promise<{ success: boolean; error?: string }>;
  updateInvoice: (id: string, updates: Partial<PurchaseInvoice>) => Promise<{ success: boolean; error?: string }>;
  deleteInvoice: (id: string) => Promise<{ success: boolean; error?: string }>;

  addBankStatement: (stmt: Omit<BankStatement, 'id' | 'createdBy' | 'createdAt'>) => Promise<{ success: boolean; error?: string }>;
  updateBankStatement: (id: string, updates: Partial<BankStatement>) => Promise<{ success: boolean; error?: string }>;
  deleteBankStatement: (id: string) => Promise<{ success: boolean; error?: string }>;

  // Batch imports
  addBatchContracts: (contracts: Omit<TenancyContract, 'id' | 'createdBy' | 'createdAt'>[]) => Promise<{ added: number; errors: string[] }>;
  addBatchReceipts: (receipts: Omit<Receipt, 'id' | 'createdBy' | 'createdAt'>[]) => Promise<{ added: number }>;
  addBatchInvoices: (invoices: Omit<PurchaseInvoice, 'id' | 'createdBy' | 'createdAt'>[]) => Promise<{ added: number; errors: string[] }>;
  addBatchBankStatements: (statements: Omit<BankStatement, 'id' | 'createdBy' | 'createdAt'>[]) => Promise<{ added: number }>;

  // Validation
  checkContractDuplicate: (propertyNo: string, startDate: string, endDate: string, excludeId?: string) => string | null;
  checkInvoiceDuplicate: (invoiceNumber: string, invoiceDate: string, excludeId?: string) => string | null;

  // Reconciliation
  autoReconcile: () => { matchedCount: number; matchedAmount: number };
  manualMatch: (bankTxId: string, refType: 'Receipt' | 'PurchaseInvoice', refId: string) => void;
  unmatchTransaction: (bankTxId: string) => void;

  // Metrics
  filteredContracts: TenancyContract[];
  filteredReceipts: Receipt[];
  filteredInvoices: PurchaseInvoice[];
  filteredStatements: BankStatement[];
  metrics: DashboardMetrics;
  propertiesList: string[];
}

const PropertyDataContext = createContext<PropertyDataContextType | undefined>(undefined);

export const PropertyDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const currentUid = user?.uid || 'local-user';

  // No test or dummy tenancy contracts! Strictly empty by default.
  const [contracts, setContracts] = useState<TenancyContract[]>(() => {
    try {
      const saved = localStorage.getItem('dxb_contracts');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [receipts, setReceipts] = useState<Receipt[]>(() => {
    try {
      const saved = localStorage.getItem('dxb_receipts');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [invoices, setInvoices] = useState<PurchaseInvoice[]>(() => {
    try {
      const saved = localStorage.getItem('dxb_invoices');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [bankStatements, setBankStatements] = useState<BankStatement[]>(() => {
    try {
      const saved = localStorage.getItem('dxb_bank_statements');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [loading, setLoading] = useState<boolean>(false);

  const [filters, setFilters] = useState<FilterState>({
    propertyFilter: 'ALL',
    periodFilter: 'ALL',
    searchTerm: '',
  });

  // Save to localStorage as quick local backup
  useEffect(() => {
    localStorage.setItem('dxb_contracts', JSON.stringify(contracts));
  }, [contracts]);

  useEffect(() => {
    localStorage.setItem('dxb_receipts', JSON.stringify(receipts));
  }, [receipts]);

  useEffect(() => {
    localStorage.setItem('dxb_invoices', JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem('dxb_bank_statements', JSON.stringify(bankStatements));
  }, [bankStatements]);

  // Firestore Sync when user is authenticated
  useEffect(() => {
    if (!user) return;

    const unsubContracts = onSnapshot(
      collection(db, 'tenancyContracts'),
      (snapshot) => {
        const loaded: TenancyContract[] = [];
        snapshot.forEach((d) => loaded.push({ ...(d.data() as TenancyContract), id: d.id }));
        if (loaded.length > 0) setContracts(loaded);
      },
      (error) => {
        console.warn('Contracts snapshot warning:', error);
      }
    );

    const unsubReceipts = onSnapshot(
      collection(db, 'receipts'),
      (snapshot) => {
        const loaded: Receipt[] = [];
        snapshot.forEach((d) => loaded.push({ ...(d.data() as Receipt), id: d.id }));
        if (loaded.length > 0) setReceipts(loaded);
      },
      (error) => {
        console.warn('Receipts snapshot warning:', error);
      }
    );

    const unsubInvoices = onSnapshot(
      collection(db, 'purchaseInvoices'),
      (snapshot) => {
        const loaded: PurchaseInvoice[] = [];
        snapshot.forEach((d) => loaded.push({ ...(d.data() as PurchaseInvoice), id: d.id }));
        if (loaded.length > 0) setInvoices(loaded);
      },
      (error) => {
        console.warn('Invoices snapshot warning:', error);
      }
    );

    const unsubBank = onSnapshot(
      collection(db, 'bankStatements'),
      (snapshot) => {
        const loaded: BankStatement[] = [];
        snapshot.forEach((d) => loaded.push({ ...(d.data() as BankStatement), id: d.id }));
        if (loaded.length > 0) setBankStatements(loaded);
      },
      (error) => {
        console.warn('Bank statements snapshot warning:', error);
      }
    );

    return () => {
      unsubContracts();
      unsubReceipts();
      unsubInvoices();
      unsubBank();
    };
  }, [user]);

  // DUPLICATE PREVENTIONS:
  // 1. Tenancy Contract: No duplicate on propertyNo within same contract period
  const checkContractDuplicate = (
    propertyNo: string,
    startDate: string,
    endDate: string,
    excludeId?: string
  ): string | null => {
    const cleanProp = propertyNo.trim().toLowerCase();
    const newStart = new Date(startDate).getTime();
    const newEnd = new Date(endDate).getTime();

    const existing = contracts.find((c) => {
      if (excludeId && c.id === excludeId) return false;
      if (c.propertyNo.trim().toLowerCase() !== cleanProp) return false;

      const cStart = new Date(c.startDate).getTime();
      const cEnd = new Date(c.endDate).getTime();

      // Overlap condition: startA <= endB && endA >= startB
      const overlaps = newStart <= cEnd && newEnd >= cStart;
      return overlaps;
    });

    if (existing) {
      return `Duplicate prevented: Property "${propertyNo}" already has an active tenancy contract during period ${existing.startDate} to ${existing.endDate} (Tenant: ${existing.tenantName}).`;
    }
    return null;
  };

  // 2. Purchase Tax Invoice: No duplicate on invoiceNumber with same date/contract period
  const checkInvoiceDuplicate = (
    invoiceNumber: string,
    invoiceDate: string,
    excludeId?: string
  ): string | null => {
    const cleanNum = invoiceNumber.trim().toLowerCase();
    const cleanDate = invoiceDate.trim();

    const existing = invoices.find((inv) => {
      if (excludeId && inv.id === excludeId) return false;
      const matchNum = inv.invoiceNumber.trim().toLowerCase() === cleanNum;
      if (!matchNum) return false;

      // Same date or same month/year period
      const invDateStr = inv.invoiceDate.trim();
      const sameExactDate = invDateStr === cleanDate;
      const sameMonth = invDateStr.slice(0, 7) === cleanDate.slice(0, 7);

      return sameExactDate || sameMonth;
    });

    if (existing) {
      return `Duplicate prevented: Purchase Tax Invoice #${invoiceNumber} already exists for date ${existing.invoiceDate} (Supplier: ${existing.supplierName}, Total: AED ${existing.totalInvoiceAmount.toLocaleString()}).`;
    }
    return null;
  };

  // CRUD Implementations
  const addContract = async (data: Omit<TenancyContract, 'id' | 'createdBy' | 'createdAt'>) => {
    const duplicateError = checkContractDuplicate(data.propertyNo, data.startDate, data.endDate);
    if (duplicateError) {
      return { success: false, error: duplicateError };
    }

    const id = `tc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newDoc: TenancyContract = {
      ...data,
      id,
      createdBy: currentUid,
      createdAt: new Date().toISOString(),
    };

    setContracts((prev) => [newDoc, ...prev]);

    if (user) {
      try {
        await setDoc(doc(db, 'tenancyContracts', id), newDoc);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `tenancyContracts/${id}`);
      }
    }
    return { success: true };
  };

  const updateContract = async (id: string, updates: Partial<TenancyContract>) => {
    const current = contracts.find((c) => c.id === id);
    if (!current) return { success: false, error: 'Contract not found' };

    const propNo = updates.propertyNo ?? current.propertyNo;
    const sDate = updates.startDate ?? current.startDate;
    const eDate = updates.endDate ?? current.endDate;

    const duplicateError = checkContractDuplicate(propNo, sDate, eDate, id);
    if (duplicateError) {
      return { success: false, error: duplicateError };
    }

    const updated = { ...current, ...updates };
    setContracts((prev) => prev.map((c) => (c.id === id ? updated : c)));

    if (user) {
      try {
        await setDoc(doc(db, 'tenancyContracts', id), updated);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `tenancyContracts/${id}`);
      }
    }
    return { success: true };
  };

  const deleteContract = async (id: string) => {
    setContracts((prev) => prev.filter((c) => c.id !== id));
    if (user) {
      try {
        await deleteDoc(doc(db, 'tenancyContracts', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `tenancyContracts/${id}`);
      }
    }
    return { success: true };
  };

  const addReceipt = async (data: Omit<Receipt, 'id' | 'createdBy' | 'createdAt'>) => {
    const id = `rc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newDoc: Receipt = {
      ...data,
      id,
      createdBy: currentUid,
      createdAt: new Date().toISOString(),
    };
    setReceipts((prev) => [newDoc, ...prev]);

    if (user) {
      try {
        await setDoc(doc(db, 'receipts', id), newDoc);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `receipts/${id}`);
      }
    }
    return { success: true };
  };

  const updateReceipt = async (id: string, updates: Partial<Receipt>) => {
    setReceipts((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r)));
    if (user) {
      try {
        const item = receipts.find((r) => r.id === id);
        if (item) {
          await setDoc(doc(db, 'receipts', id), { ...item, ...updates });
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `receipts/${id}`);
      }
    }
    return { success: true };
  };

  const deleteReceipt = async (id: string) => {
    setReceipts((prev) => prev.filter((r) => r.id !== id));
    if (user) {
      try {
        await deleteDoc(doc(db, 'receipts', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `receipts/${id}`);
      }
    }
    return { success: true };
  };

  const addInvoice = async (data: Omit<PurchaseInvoice, 'id' | 'createdBy' | 'createdAt'>) => {
    const duplicateError = checkInvoiceDuplicate(data.invoiceNumber, data.invoiceDate);
    if (duplicateError) {
      return { success: false, error: duplicateError };
    }

    const id = `inv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newDoc: PurchaseInvoice = {
      ...data,
      id,
      createdBy: currentUid,
      createdAt: new Date().toISOString(),
    };
    setInvoices((prev) => [newDoc, ...prev]);

    if (user) {
      try {
        await setDoc(doc(db, 'purchaseInvoices', id), newDoc);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `purchaseInvoices/${id}`);
      }
    }
    return { success: true };
  };

  const updateInvoice = async (id: string, updates: Partial<PurchaseInvoice>) => {
    const current = invoices.find((i) => i.id === id);
    if (!current) return { success: false, error: 'Invoice not found' };

    const invNum = updates.invoiceNumber ?? current.invoiceNumber;
    const invDate = updates.invoiceDate ?? current.invoiceDate;

    const duplicateError = checkInvoiceDuplicate(invNum, invDate, id);
    if (duplicateError) {
      return { success: false, error: duplicateError };
    }

    const updated = { ...current, ...updates };
    setInvoices((prev) => prev.map((i) => (i.id === id ? updated : i)));

    if (user) {
      try {
        await setDoc(doc(db, 'purchaseInvoices', id), updated);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `purchaseInvoices/${id}`);
      }
    }
    return { success: true };
  };

  const deleteInvoice = async (id: string) => {
    setInvoices((prev) => prev.filter((i) => i.id !== id));
    if (user) {
      try {
        await deleteDoc(doc(db, 'purchaseInvoices', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `purchaseInvoices/${id}`);
      }
    }
    return { success: true };
  };

  const addBankStatement = async (data: Omit<BankStatement, 'id' | 'createdBy' | 'createdAt'>) => {
    const id = `bs_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const newDoc: BankStatement = {
      ...data,
      id,
      createdBy: currentUid,
      createdAt: new Date().toISOString(),
    };
    setBankStatements((prev) => [newDoc, ...prev]);

    if (user) {
      try {
        await setDoc(doc(db, 'bankStatements', id), newDoc);
      } catch (err) {
        handleFirestoreError(err, OperationType.CREATE, `bankStatements/${id}`);
      }
    }
    return { success: true };
  };

  const updateBankStatement = async (id: string, updates: Partial<BankStatement>) => {
    setBankStatements((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
    if (user) {
      try {
        const item = bankStatements.find((s) => s.id === id);
        if (item) {
          await setDoc(doc(db, 'bankStatements', id), { ...item, ...updates });
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, `bankStatements/${id}`);
      }
    }
    return { success: true };
  };

  const deleteBankStatement = async (id: string) => {
    setBankStatements((prev) => prev.filter((s) => s.id !== id));
    if (user) {
      try {
        await deleteDoc(doc(db, 'bankStatements', id));
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `bankStatements/${id}`);
      }
    }
    return { success: true };
  };

  // Batch imports
  const addBatchContracts = async (newItems: Omit<TenancyContract, 'id' | 'createdBy' | 'createdAt'>[]) => {
    const errors: string[] = [];
    const validToAdd: TenancyContract[] = [];

    for (const item of newItems) {
      const dup = checkContractDuplicate(item.propertyNo, item.startDate, item.endDate);
      if (dup) {
        errors.push(dup);
      } else {
        const id = `tc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        validToAdd.push({
          ...item,
          id,
          createdBy: currentUid,
          createdAt: new Date().toISOString(),
        });
      }
    }

    if (validToAdd.length > 0) {
      setContracts((prev) => [...validToAdd, ...prev]);
      if (user) {
        for (const item of validToAdd) {
          try {
            await setDoc(doc(db, 'tenancyContracts', item.id), item);
          } catch (e) {
            console.error(e);
          }
        }
      }
    }
    return { added: validToAdd.length, errors };
  };

  const addBatchReceipts = async (newItems: Omit<Receipt, 'id' | 'createdBy' | 'createdAt'>[]) => {
    const validToAdd: Receipt[] = newItems.map((item) => ({
      ...item,
      id: `rc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdBy: currentUid,
      createdAt: new Date().toISOString(),
    }));

    setReceipts((prev) => [...validToAdd, ...prev]);
    if (user) {
      for (const item of validToAdd) {
        try {
          await setDoc(doc(db, 'receipts', item.id), item);
        } catch (e) {
          console.error(e);
        }
      }
    }
    return { added: validToAdd.length };
  };

  const addBatchInvoices = async (newItems: Omit<PurchaseInvoice, 'id' | 'createdBy' | 'createdAt'>[]) => {
    const errors: string[] = [];
    const validToAdd: PurchaseInvoice[] = [];

    for (const item of newItems) {
      const dup = checkInvoiceDuplicate(item.invoiceNumber, item.invoiceDate);
      if (dup) {
        errors.push(dup);
      } else {
        const id = `inv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        validToAdd.push({
          ...item,
          id,
          createdBy: currentUid,
          createdAt: new Date().toISOString(),
        });
      }
    }

    if (validToAdd.length > 0) {
      setInvoices((prev) => [...validToAdd, ...prev]);
      if (user) {
        for (const item of validToAdd) {
          try {
            await setDoc(doc(db, 'purchaseInvoices', item.id), item);
          } catch (e) {
            console.error(e);
          }
        }
      }
    }
    return { added: validToAdd.length, errors };
  };

  const addBatchBankStatements = async (newItems: Omit<BankStatement, 'id' | 'createdBy' | 'createdAt'>[]) => {
    const validToAdd: BankStatement[] = newItems.map((item) => ({
      ...item,
      id: `bs_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdBy: currentUid,
      createdAt: new Date().toISOString(),
    }));

    setBankStatements((prev) => [...validToAdd, ...prev]);
    if (user) {
      for (const item of validToAdd) {
        try {
          await setDoc(doc(db, 'bankStatements', item.id), item);
        } catch (e) {
          console.error(e);
        }
      }
    }
    return { added: validToAdd.length };
  };

  // BANK RECONCILIATION MATCHING ENGINE:
  // Matches bank statement credit with receipts & debit with purchase tax invoices
  const autoReconcile = () => {
    let matchedCount = 0;
    let matchedAmount = 0;

    const updatedBank = [...bankStatements];
    const updatedReceipts = [...receipts];
    const updatedInvoices = [...invoices];

    // Pass 1: Match Credit transactions with Receipts
    for (let i = 0; i < updatedBank.length; i++) {
      const bTx = updatedBank[i];
      if (bTx.reconciliationStatus === 'Matched' || bTx.creditAmount <= 0) continue;

      // Match by cheque number first
      let matchedReceiptIndex = -1;
      if (bTx.chequeNumber && bTx.chequeNumber.trim() !== '') {
        const cleanChq = bTx.chequeNumber.trim().toLowerCase();
        matchedReceiptIndex = updatedReceipts.findIndex(
          (r) => !r.matchedBankTxId && r.chequeNo.toLowerCase().includes(cleanChq)
        );
      }

      // If no match by cheque number, match by exact credit amount and approximate date
      if (matchedReceiptIndex === -1) {
        matchedReceiptIndex = updatedReceipts.findIndex(
          (r) => !r.matchedBankTxId && Math.abs(r.amount - bTx.creditAmount) < 0.01
        );
      }

      if (matchedReceiptIndex !== -1) {
        const rec = updatedReceipts[matchedReceiptIndex];
        updatedBank[i] = {
          ...bTx,
          reconciliationStatus: 'Matched',
          matchedType: 'Receipt',
          matchedRefId: rec.id,
        };
        updatedReceipts[matchedReceiptIndex] = {
          ...rec,
          status: 'Cleared',
          matchedBankTxId: bTx.id,
        };
        matchedCount++;
        matchedAmount += bTx.creditAmount;
      }
    }

    // Pass 2: Match Debit transactions with Purchase Invoices (maintenance exp)
    for (let i = 0; i < updatedBank.length; i++) {
      const bTx = updatedBank[i];
      if (bTx.reconciliationStatus === 'Matched' || bTx.debitAmount <= 0) continue;

      // Match by exact debit amount with total invoice amount
      const matchedInvoiceIndex = updatedInvoices.findIndex(
        (inv) => !inv.matchedBankTxId && Math.abs(inv.totalInvoiceAmount - bTx.debitAmount) < 0.01
      );

      if (matchedInvoiceIndex !== -1) {
        const inv = updatedInvoices[matchedInvoiceIndex];
        updatedBank[i] = {
          ...bTx,
          reconciliationStatus: 'Matched',
          matchedType: 'PurchaseInvoice',
          matchedRefId: inv.id,
        };
        updatedInvoices[matchedInvoiceIndex] = {
          ...inv,
          matchedBankTxId: bTx.id,
        };
        matchedCount++;
        matchedAmount += bTx.debitAmount;
      }
    }

    setBankStatements(updatedBank);
    setReceipts(updatedReceipts);
    setInvoices(updatedInvoices);

    return { matchedCount, matchedAmount };
  };

  const manualMatch = (bankTxId: string, refType: 'Receipt' | 'PurchaseInvoice', refId: string) => {
    setBankStatements((prev) =>
      prev.map((b) =>
        b.id === bankTxId
          ? { ...b, reconciliationStatus: 'Matched', matchedType: refType, matchedRefId: refId }
          : b
      )
    );

    if (refType === 'Receipt') {
      setReceipts((prev) =>
        prev.map((r) => (r.id === refId ? { ...r, matchedBankTxId: bankTxId, status: 'Cleared' } : r))
      );
    } else {
      setInvoices((prev) =>
        prev.map((inv) => (inv.id === refId ? { ...inv, matchedBankTxId: bankTxId } : inv))
      );
    }
  };

  const unmatchTransaction = (bankTxId: string) => {
    const bankTx = bankStatements.find((b) => b.id === bankTxId);
    if (!bankTx) return;

    if (bankTx.matchedType === 'Receipt' && bankTx.matchedRefId) {
      setReceipts((prev) =>
        prev.map((r) => (r.id === bankTx.matchedRefId ? { ...r, matchedBankTxId: undefined } : r))
      );
    } else if (bankTx.matchedType === 'PurchaseInvoice' && bankTx.matchedRefId) {
      setInvoices((prev) =>
        prev.map((inv) => (inv.id === bankTx.matchedRefId ? { ...inv, matchedBankTxId: undefined } : inv))
      );
    }

    setBankStatements((prev) =>
      prev.map((b) =>
        b.id === bankTxId
          ? { ...b, reconciliationStatus: 'Unmatched', matchedType: 'None', matchedRefId: undefined }
          : b
      )
    );
  };

  // Distinct property list for dropdown filters
  const propertiesList = useMemo(() => {
    const set = new Set<string>();
    contracts.forEach((c) => {
      if (c.propertyNo) set.add(c.propertyNo);
    });
    receipts.forEach((r) => {
      if (r.propertyNo) set.add(r.propertyNo);
    });
    invoices.forEach((i) => {
      if (i.propertyNo) set.add(i.propertyNo);
    });
    return Array.from(set).sort();
  }, [contracts, receipts, invoices]);

  // Filtering Logic
  const filteredContracts = useMemo(() => {
    return contracts.filter((c) => {
      if (filters.propertyFilter !== 'ALL' && c.propertyNo !== filters.propertyFilter) {
        return false;
      }
      if (filters.searchTerm) {
        const q = filters.searchTerm.toLowerCase();
        const matches =
          c.propertyNo.toLowerCase().includes(q) ||
          c.tenantName.toLowerCase().includes(q) ||
          c.buildingName.toLowerCase().includes(q) ||
          c.ownerName.toLowerCase().includes(q);
        if (!matches) return false;
      }
      if (filters.periodFilter === 'THIS_YEAR') {
        const currentYear = new Date().getFullYear().toString();
        return c.startDate.startsWith(currentYear) || c.endDate.startsWith(currentYear);
      }
      return true;
    });
  }, [contracts, filters]);

  const filteredReceipts = useMemo(() => {
    return receipts.filter((r) => {
      if (filters.propertyFilter !== 'ALL' && r.propertyNo !== filters.propertyFilter) {
        return false;
      }
      if (filters.searchTerm) {
        const q = filters.searchTerm.toLowerCase();
        const matches =
          r.chequeNo.toLowerCase().includes(q) ||
          r.tenantName.toLowerCase().includes(q) ||
          r.bankName.toLowerCase().includes(q) ||
          r.propertyNo.toLowerCase().includes(q);
        if (!matches) return false;
      }
      if (filters.periodFilter === 'THIS_YEAR') {
        const currentYear = new Date().getFullYear().toString();
        return r.installmentDate.startsWith(currentYear);
      }
      return true;
    });
  }, [receipts, filters]);

  const filteredInvoices = useMemo(() => {
    return invoices.filter((i) => {
      if (filters.propertyFilter !== 'ALL' && i.propertyNo !== filters.propertyFilter) {
        return false;
      }
      if (filters.searchTerm) {
        const q = filters.searchTerm.toLowerCase();
        const matches =
          i.invoiceNumber.toLowerCase().includes(q) ||
          i.supplierName.toLowerCase().includes(q) ||
          i.description.toLowerCase().includes(q) ||
          i.propertyNo.toLowerCase().includes(q);
        if (!matches) return false;
      }
      if (filters.periodFilter === 'THIS_YEAR') {
        const currentYear = new Date().getFullYear().toString();
        return i.invoiceDate.startsWith(currentYear);
      }
      return true;
    });
  }, [invoices, filters]);

  const filteredStatements = useMemo(() => {
    return bankStatements.filter((s) => {
      if (filters.searchTerm) {
        const q = filters.searchTerm.toLowerCase();
        const matches =
          s.transactionName.toLowerCase().includes(q) ||
          (s.chequeNumber && s.chequeNumber.toLowerCase().includes(q)) ||
          s.bankName.toLowerCase().includes(q);
        if (!matches) return false;
      }
      return true;
    });
  }, [bankStatements, filters.searchTerm]);

  // Dashboard Metrics Computations
  const metrics = useMemo<DashboardMetrics>(() => {
    const totalContractAmount = filteredContracts.reduce((sum, c) => sum + (c.contractAmount || 0), 0);
    const totalActualAnnualAmount = filteredContracts.reduce((sum, c) => sum + (c.actualAnnualAmount || 0), 0);
    const totalSecurityDeposit = filteredContracts.reduce((sum, c) => sum + (c.securityDeposit || 0), 0);
    const totalReceipts = filteredReceipts.reduce((sum, r) => sum + (r.amount || 0), 0);
    const totalPurchaseMaintenanceExp = filteredInvoices.reduce((sum, i) => sum + (i.totalInvoiceAmount || 0), 0);
    const totalVATOnPurchaseInvoice = filteredInvoices.reduce((sum, i) => sum + (i.taxAmount || 0), 0);

    // Net rent income = total actual annual amount - total purchase maintenance exp
    const netRentIncome = totalActualAnnualAmount - totalPurchaseMaintenanceExp;

    // Total VAT on actual rent (Commercial properties are subject to 5% UAE VAT, Residential is 0%)
    const totalVATOnActualRent = filteredContracts.reduce((sum, c) => {
      if (c.type === 'Commercial') {
        return sum + (c.vatAmount || (c.actualAnnualAmount || 0) * 0.05);
      }
      return sum + (c.vatAmount || 0);
    }, 0);

    // Net VAT = total VAT on actual rent - total VAT on purchase invoices
    const netVAT = totalVATOnActualRent - totalVATOnPurchaseInvoice;

    // Monthly trends computation
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const currentYear = new Date().getFullYear();

    const monthlyTrends = monthNames.map((month, idx) => {
      const monthPrefix = `${currentYear}-${String(idx + 1).padStart(2, '0')}`;

      const cAmt = filteredContracts
        .filter((c) => c.startDate?.startsWith(monthPrefix))
        .reduce((sum, c) => sum + (c.contractAmount || 0), 0);

      const aAmt = filteredContracts
        .filter((c) => c.startDate?.startsWith(monthPrefix))
        .reduce((sum, c) => sum + (c.actualAnnualAmount || 0), 0);

      const rAmt = filteredReceipts
        .filter((r) => r.installmentDate?.startsWith(monthPrefix))
        .reduce((sum, r) => sum + (r.amount || 0), 0);

      const eAmt = filteredInvoices
        .filter((i) => i.invoiceDate?.startsWith(monthPrefix))
        .reduce((sum, i) => sum + (i.totalInvoiceAmount || 0), 0);

      return {
        month,
        contractAmount: cAmt,
        actualAnnualAmount: aAmt,
        receipts: rAmt,
        expenses: eAmt,
      };
    });

    return {
      totalContractAmount,
      totalActualAnnualAmount,
      totalSecurityDeposit,
      totalReceipts,
      totalPurchaseMaintenanceExp,
      totalVATOnPurchaseInvoice,
      netRentIncome,
      totalVATOnActualRent,
      netVAT,
      monthlyTrends,
    };
  }, [filteredContracts, filteredReceipts, filteredInvoices]);

  return (
    <PropertyDataContext.Provider
      value={{
        contracts,
        receipts,
        invoices,
        bankStatements,
        loading,
        filters,
        setFilters,
        addContract,
        updateContract,
        deleteContract,
        addReceipt,
        updateReceipt,
        deleteReceipt,
        addInvoice,
        updateInvoice,
        deleteInvoice,
        addBankStatement,
        updateBankStatement,
        deleteBankStatement,
        addBatchContracts,
        addBatchReceipts,
        addBatchInvoices,
        addBatchBankStatements,
        checkContractDuplicate,
        checkInvoiceDuplicate,
        autoReconcile,
        manualMatch,
        unmatchTransaction,
        filteredContracts,
        filteredReceipts,
        filteredInvoices,
        filteredStatements,
        metrics,
        propertiesList,
      }}
    >
      {children}
    </PropertyDataContext.Provider>
  );
};

export const usePropertyData = () => {
  const context = useContext(PropertyDataContext);
  if (!context) {
    throw new Error('usePropertyData must be used within a PropertyDataProvider');
  }
  return context;
};
