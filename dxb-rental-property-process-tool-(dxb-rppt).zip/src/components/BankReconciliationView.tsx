import React, { useState, useMemo, useRef, useEffect } from 'react';
import {
  Landmark,
  ArrowUpRight,
  ArrowDownLeft,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  RefreshCw,
  Upload,
  Download,
  FileSpreadsheet,
  FileText,
  Filter,
  Search,
  Plus,
  Trash2,
  Link as LinkIcon,
  Unlink,
  Check,
  X,
  SlidersHorizontal,
  ChevronRight,
  DollarSign,
  ShieldCheck,
  Calendar,
  Layers,
  Sparkles,
  Building2,
  Receipt,
  CreditCard,
  Percent,
  Clock,
  Printer,
  ChevronDown,
} from 'lucide-react';
import {
  BankStatement,
  BankTransaction,
  BankReconciliationSummary,
  RentalReceipt,
  PurchaseTaxInvoice,
  OtherPaymentCategory,
  ReconciliationStatus,
} from '../types';
import { formatAED, exportBankReconciliationToExcel, exportBankReconciliationToPDF } from '../utils/exportUtils';
import {
  parseCSVBankStatement,
  parseExcelBankStatement,
  autoReconcileTransactions,
  computeBankReconciliationSummary,
  generateSampleUAEBankStatement,
  downloadBankStatementTemplate,
  detectOtherPaymentCategory,
} from '../utils/bankReconciliation';
import {
  saveBankStatement,
  saveBankTransactionsBatch,
  updateBankTransaction,
  deleteBankStatement,
  deleteBankTransaction,
} from '../services/dbService';
import { useAuth } from '../context/AuthContext';

interface BankReconciliationViewProps {
  receipts: RentalReceipt[];
  invoices: PurchaseTaxInvoice[];
  bankStatements?: BankStatement[];
  bankTransactions?: BankTransaction[];
  onNavigateTab?: (tab: any) => void;
}

export const BankReconciliationView: React.FC<BankReconciliationViewProps> = ({
  receipts = [],
  invoices = [],
  bankStatements: initialStatements = [],
  bankTransactions: initialTransactions = [],
  onNavigateTab,
}) => {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Local state for bank statements and transactions (with localStorage persistence)
  const [statements, setStatements] = useState<BankStatement[]>(() => {
    if (initialStatements.length > 0) return initialStatements;
    const saved = localStorage.getItem('dxb_bank_statements');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [];
  });

  const [activeStatementId, setActiveStatementId] = useState<string>(() => {
    if (statements.length > 0) return statements[0].id;
    return '';
  });

  const [transactions, setTransactions] = useState<BankTransaction[]>(() => {
    if (initialTransactions.length > 0) return initialTransactions;
    const saved = localStorage.getItem('dxb_bank_transactions');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [];
  });

  // Keep local storage in sync
  useEffect(() => {
    localStorage.setItem('dxb_bank_statements', JSON.stringify(statements));
  }, [statements]);

  useEffect(() => {
    localStorage.setItem('dxb_bank_transactions', JSON.stringify(transactions));
  }, [transactions]);

  // Sync active statement ID if statements list changes
  useEffect(() => {
    if (!activeStatementId && statements.length > 0) {
      setActiveStatementId(statements[0].id);
    }
  }, [statements, activeStatementId]);

  // Current active statement
  const currentStatement = useMemo(() => {
    return statements.find((s) => s.id === activeStatementId) || statements[0] || null;
  }, [statements, activeStatementId]);

  // Transactions belonging to active statement
  const currentTransactions = useMemo(() => {
    if (!currentStatement) return [];
    return transactions.filter((t) => t.statementId === currentStatement.id);
  }, [transactions, currentStatement]);

  // Views & navigation
  const [activeSubTab, setActiveSubTab] = useState<'brs' | 'debits' | 'credits' | 'ledger' | 'uncleared'>('brs');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'matched' | 'suggested' | 'unreconciled'>('all');

  // Modals state
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isLinkInvoiceModalOpen, setIsLinkInvoiceModalOpen] = useState(false);
  const [isLinkReceiptModalOpen, setIsLinkReceiptModalOpen] = useState(false);
  const [isOtherPaymentModalOpen, setIsOtherPaymentModalOpen] = useState(false);
  const [selectedTxForMatch, setSelectedTxForMatch] = useState<BankTransaction | null>(null);

  // Other payment modal inputs
  const [otherCategory, setOtherCategory] = useState<OtherPaymentCategory>('Maintenance & Repairs');
  const [otherNotes, setOtherNotes] = useState('');

  // Notification banners
  const [bannerMessage, setBannerMessage] = useState<{ text: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showBanner = (text: string, type: 'success' | 'info' | 'error' = 'success') => {
    setBannerMessage({ text, type });
    setTimeout(() => setBannerMessage(null), 5000);
  };

  // Compute formal BRS summary
  const summary: BankReconciliationSummary = useMemo(() => {
    return computeBankReconciliationSummary(currentStatement, currentTransactions, receipts, invoices);
  }, [currentStatement, currentTransactions, receipts, invoices]);

  // Handle Loading UAE Sample Statement
  const handleLoadSampleStatement = async () => {
    const sample = generateSampleUAEBankStatement(invoices, receipts);

    // Auto-reconcile initial batch
    const { reconciledTransactions, matchedCount, suggestedCount } = autoReconcileTransactions(
      sample.transactions,
      invoices,
      receipts
    );

    const newStatement: BankStatement = {
      ...sample.statement,
      userId: user?.uid || 'guest_user',
      reconciledCount: matchedCount,
      unreconciledCount: sample.transactions.length - matchedCount,
      status: matchedCount === sample.transactions.length ? 'reconciled' : 'in_progress',
    };

    setStatements((prev) => [newStatement, ...prev.filter((s) => s.id !== newStatement.id)]);
    setActiveStatementId(newStatement.id);
    setTransactions((prev) => [...reconciledTransactions, ...prev.filter((t) => t.statementId !== newStatement.id)]);

    if (user) {
      await saveBankStatement(newStatement);
      await saveBankTransactionsBatch(reconciledTransactions);
    }

    showBanner(
      `Loaded Emirates NBD statement (${sample.transactions.length} lines). Automatically reconciled ${matchedCount} items with ${suggestedCount} suggested matches!`
    );
  };

  // Run Smart Auto-Reconcile on Current Statement
  const handleRunAutoReconcile = async () => {
    if (!currentStatement || currentTransactions.length === 0) {
      showBanner('Please upload or load a bank statement first.', 'error');
      return;
    }

    const { reconciledTransactions, matchedCount, suggestedCount } = autoReconcileTransactions(
      currentTransactions,
      invoices,
      receipts
    );

    // Update state
    setTransactions((prev) =>
      prev.map((t) => {
        const updated = reconciledTransactions.find((rt) => rt.id === t.id);
        return updated || t;
      })
    );

    const updatedStatement: BankStatement = {
      ...currentStatement,
      reconciledCount: reconciledTransactions.filter((t) => t.reconciliationStatus === 'matched').length,
      unreconciledCount: reconciledTransactions.filter((t) => t.reconciliationStatus !== 'matched').length,
      status:
        reconciledTransactions.filter((t) => t.reconciliationStatus === 'matched').length === currentTransactions.length
          ? 'reconciled'
          : 'in_progress',
    };

    setStatements((prev) => prev.map((s) => (s.id === updatedStatement.id ? updatedStatement : s)));

    if (user) {
      await saveBankStatement(updatedStatement);
      await saveBankTransactionsBatch(reconciledTransactions);
    }

    showBanner(
      `Reconciliation complete: ${matchedCount} transactions verified & matched, ${suggestedCount} suggested matches waiting for confirmation.`
    );
  };

  // Confirm a Suggested Match
  const handleConfirmSuggestedMatch = async (tx: BankTransaction) => {
    const updatedTx: BankTransaction = {
      ...tx,
      reconciliationStatus: 'matched',
      reconciledAt: new Date().toISOString(),
      reconciledBy: user?.displayName || user?.email || 'Authorized Accountant',
      notes: tx.notes ? `${tx.notes} (Confirmed)` : 'Confirmed match',
    };

    setTransactions((prev) => prev.map((t) => (t.id === tx.id ? updatedTx : t)));
    if (user) await updateBankTransaction(tx.id, updatedTx);
    showBanner(`Transaction #${tx.referenceNo || tx.id} confirmed and reconciled.`);
  };

  // Unlink / Break Match
  const handleUnlinkMatch = async (tx: BankTransaction) => {
    const updatedTx: BankTransaction = {
      ...tx,
      reconciliationStatus: 'unreconciled',
      matchedEntityType: undefined,
      matchedEntityId: undefined,
      matchedEntityRef: undefined,
      matchedEntityName: undefined,
      matchedAmount: undefined,
      differenceAmount: undefined,
      otherPaymentCategory: undefined,
      notes: undefined,
      reconciledAt: undefined,
      reconciledBy: undefined,
    };

    setTransactions((prev) => prev.map((t) => (t.id === tx.id ? updatedTx : t)));
    if (user) await updateBankTransaction(tx.id, updatedTx);
    showBanner(`Unlinked match for transaction #${tx.referenceNo || tx.id}. Status set to Unreconciled.`);
  };

  // Manual Match with Invoice
  const handleApplyInvoiceMatch = async (invoice: PurchaseTaxInvoice) => {
    if (!selectedTxForMatch) return;

    const diff = Number((selectedTxForMatch.amount - Number(invoice.totalInvoiceAmount)).toFixed(2));
    const updatedTx: BankTransaction = {
      ...selectedTxForMatch,
      reconciliationStatus: 'matched',
      matchedEntityType: 'invoice',
      matchedEntityId: invoice.id,
      matchedEntityRef: invoice.invoiceNumber,
      matchedEntityName: invoice.supplierName,
      matchedAmount: invoice.totalInvoiceAmount,
      differenceAmount: diff,
      notes: diff === 0
        ? `Manually reconciled with Invoice #${invoice.invoiceNumber}`
        : `Manually matched with Invoice #${invoice.invoiceNumber} (Variance: ${formatAED(diff)})`,
      reconciledAt: new Date().toISOString(),
      reconciledBy: user?.displayName || user?.email || 'Authorized Accountant',
    };

    setTransactions((prev) => prev.map((t) => (t.id === selectedTxForMatch.id ? updatedTx : t)));
    if (user) await updateBankTransaction(selectedTxForMatch.id, updatedTx);

    setIsLinkInvoiceModalOpen(false);
    setSelectedTxForMatch(null);
    showBanner(`Successfully reconciled bank debit with Maintenance Invoice #${invoice.invoiceNumber}.`);
  };

  // Manual Match with Receipt
  const handleApplyReceiptMatch = async (receipt: RentalReceipt) => {
    if (!selectedTxForMatch) return;

    const diff = Number((selectedTxForMatch.amount - Number(receipt.amount)).toFixed(2));
    const updatedTx: BankTransaction = {
      ...selectedTxForMatch,
      reconciliationStatus: 'matched',
      matchedEntityType: 'receipt',
      matchedEntityId: receipt.id,
      matchedEntityRef: receipt.receiptNo || receipt.chequeNo,
      matchedEntityName: receipt.tenantName || 'Tenant Deposit',
      matchedAmount: receipt.amount,
      differenceAmount: diff,
      notes: diff === 0
        ? `Manually reconciled with Rent Receipt #${receipt.receiptNo}`
        : `Manually matched with Rent Receipt #${receipt.receiptNo} (Variance: ${formatAED(diff)})`,
      reconciledAt: new Date().toISOString(),
      reconciledBy: user?.displayName || user?.email || 'Authorized Accountant',
    };

    setTransactions((prev) => prev.map((t) => (t.id === selectedTxForMatch.id ? updatedTx : t)));
    if (user) await updateBankTransaction(selectedTxForMatch.id, updatedTx);

    setIsLinkReceiptModalOpen(false);
    setSelectedTxForMatch(null);
    showBanner(`Successfully reconciled bank credit with Rental Receipt #${receipt.receiptNo}.`);
  };

  // Save Other Payment Categorization
  const handleSaveOtherPayment = async () => {
    if (!selectedTxForMatch) return;

    const updatedTx: BankTransaction = {
      ...selectedTxForMatch,
      reconciliationStatus: 'manual_other',
      otherPaymentCategory: otherCategory,
      notes: otherNotes ? `[${otherCategory}] ${otherNotes}` : `Classified as ${otherCategory}`,
      reconciledAt: new Date().toISOString(),
      reconciledBy: user?.displayName || user?.email || 'Authorized Accountant',
    };

    setTransactions((prev) => prev.map((t) => (t.id === selectedTxForMatch.id ? updatedTx : t)));
    if (user) await updateBankTransaction(selectedTxForMatch.id, updatedTx);

    setIsOtherPaymentModalOpen(false);
    setSelectedTxForMatch(null);
    setOtherNotes('');
    showBanner(`Debit transaction classified as "${otherCategory}" and marked as reconciled.`);
  };

  // Handle Bank Statement File Upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const fileName = file.name;
      const lower = fileName.toLowerCase();
      let parseResult;

      if (lower.endsWith('.xlsx') || lower.endsWith('.xls')) {
        const buffer = await file.arrayBuffer();
        parseResult = parseExcelBankStatement(buffer, fileName);
      } else {
        const text = await file.text();
        parseResult = parseCSVBankStatement(text, fileName);
      }

      if (parseResult.transactions.length === 0) {
        showBanner('Could not find transactions in statement file. Check CSV/Excel format.', 'error');
        return;
      }

      const statementId = 'stmt_' + Date.now();
      const statementUserId = user?.uid || 'guest_user';

      const fullTransactions: BankTransaction[] = parseResult.transactions.map((tx, idx) => ({
        ...tx,
        id: `tx_${statementId}_${idx + 1}`,
        statementId,
        userId: statementUserId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }));

      // Auto reconcile initially
      const { reconciledTransactions, matchedCount, suggestedCount } = autoReconcileTransactions(
        fullTransactions,
        invoices,
        receipts
      );

      const newStatement: BankStatement = {
        ...parseResult.statement,
        id: statementId,
        userId: statementUserId,
        reconciledCount: matchedCount,
        unreconciledCount: fullTransactions.length - matchedCount,
        status: matchedCount === fullTransactions.length ? 'reconciled' : 'in_progress',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      setStatements((prev) => [newStatement, ...prev]);
      setActiveStatementId(statementId);
      setTransactions((prev) => [...reconciledTransactions, ...prev]);

      if (user) {
        await saveBankStatement(newStatement);
        await saveBankTransactionsBatch(reconciledTransactions);
      }

      setIsUploadModalOpen(false);
      showBanner(
        `Uploaded "${fileName}" successfully! ${fullTransactions.length} lines parsed, ${matchedCount} auto-matched.`
      );
    } catch (err) {
      console.error('File parsing error:', err);
      showBanner('Failed to parse bank statement file. Please verify CSV or Excel format.', 'error');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Filtered transactions for debits tab
  const debitTransactions = useMemo(() => {
    return currentTransactions.filter((tx) => {
      if (tx.type !== 'debit') return false;
      if (statusFilter === 'matched' && tx.reconciliationStatus !== 'matched' && tx.reconciliationStatus !== 'manual_other') return false;
      if (statusFilter === 'suggested' && tx.reconciliationStatus !== 'suggested') return false;
      if (statusFilter === 'unreconciled' && tx.reconciliationStatus !== 'unreconciled') return false;

      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          tx.description.toLowerCase().includes(q) ||
          (tx.referenceNo && tx.referenceNo.toLowerCase().includes(q)) ||
          (tx.matchedEntityRef && tx.matchedEntityRef.toLowerCase().includes(q)) ||
          (tx.matchedEntityName && tx.matchedEntityName.toLowerCase().includes(q)) ||
          String(tx.amount).includes(q)
        );
      }
      return true;
    });
  }, [currentTransactions, statusFilter, searchQuery]);

  // Filtered transactions for credits tab
  const creditTransactions = useMemo(() => {
    return currentTransactions.filter((tx) => {
      if (tx.type !== 'credit') return false;
      if (statusFilter === 'matched' && tx.reconciliationStatus !== 'matched') return false;
      if (statusFilter === 'suggested' && tx.reconciliationStatus !== 'suggested') return false;
      if (statusFilter === 'unreconciled' && tx.reconciliationStatus !== 'unreconciled') return false;

      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        return (
          tx.description.toLowerCase().includes(q) ||
          (tx.referenceNo && tx.referenceNo.toLowerCase().includes(q)) ||
          (tx.matchedEntityRef && tx.matchedEntityRef.toLowerCase().includes(q)) ||
          (tx.matchedEntityName && tx.matchedEntityName.toLowerCase().includes(q)) ||
          String(tx.amount).includes(q)
        );
      }
      return true;
    });
  }, [currentTransactions, statusFilter, searchQuery]);

  // Uncleared items
  const matchedReceiptIds = useMemo(() => {
    return new Set(currentTransactions.filter((t) => t.type === 'credit' && t.matchedEntityId).map((t) => t.matchedEntityId));
  }, [currentTransactions]);

  const matchedInvoiceIds = useMemo(() => {
    return new Set(currentTransactions.filter((t) => t.type === 'debit' && t.matchedEntityId).map((t) => t.matchedEntityId));
  }, [currentTransactions]);

  const unclearedReceipts = useMemo(() => {
    return receipts.filter((r) => !matchedReceiptIds.has(r.id));
  }, [receipts, matchedReceiptIds]);

  const unclearedInvoices = useMemo(() => {
    return invoices.filter((i) => !matchedInvoiceIds.has(i.id));
  }, [invoices, matchedInvoiceIds]);

  return (
    <div className="space-y-6">
      {/* Top Banner Message */}
      {bannerMessage && (
        <div
          className={`p-4 rounded-2xl flex items-center justify-between text-xs font-semibold shadow-xs transition-all ${
            bannerMessage.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : bannerMessage.type === 'info'
              ? 'bg-blue-50 text-blue-800 border border-blue-200'
              : 'bg-rose-50 text-rose-800 border border-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{bannerMessage.text}</span>
          </div>
          <button onClick={() => setBannerMessage(null)} className="p-1 hover:bg-black/5 rounded-lg">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Workspace Header */}
      <div className="bg-white rounded-3xl p-6 shadow-xs border border-slate-200/80">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-blue-500/20 ring-4 ring-blue-50">
              <Landmark className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
                  Bank Reconciliation Statement (BRS)
                </h1>
                <span className="text-[11px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-200/60 px-2 py-0.5 rounded-full">
                  UAE IFRS Compliant
                </span>
                {summary.isBalanced ? (
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 px-2.5 py-0.5 rounded-full shadow-xs">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Reconciled & Balanced (AED 0.00)
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-amber-100 text-amber-800 border border-amber-300 px-2.5 py-0.5 rounded-full shadow-xs">
                    <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                    Variance: {formatAED(summary.variance)}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-1 font-medium">
                Reconcile bank debits with maintenance invoices & payments, and bank credits with rental receipts.
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setIsUploadModalOpen(true)}
              className="px-3.5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition shadow-xs flex items-center gap-1.5"
            >
              <Upload className="w-3.5 h-3.5" />
              Upload Bank Statement
            </button>

            <button
              onClick={handleRunAutoReconcile}
              disabled={currentTransactions.length === 0}
              className="px-3.5 py-2 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-xl transition shadow-xs flex items-center gap-1.5 disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              Auto-Reconcile Match
            </button>

            <button
              onClick={handleLoadSampleStatement}
              className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition shadow-xs flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Load UAE Sample
            </button>

            <div className="relative group">
              <button
                className="px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition shadow-xs flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-slate-500" />
                Export
                <ChevronDown className="w-3 h-3 text-slate-400" />
              </button>

              <div className="absolute right-0 mt-1 w-52 bg-white rounded-2xl shadow-xl border border-slate-200 p-1.5 hidden group-hover:block z-30">
                <button
                  onClick={() => exportBankReconciliationToExcel(currentStatement, currentTransactions, summary, receipts, invoices)}
                  className="w-full text-left px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl flex items-center gap-2"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                  Export Excel (.xlsx)
                </button>
                <button
                  onClick={() => exportBankReconciliationToPDF(currentStatement, currentTransactions, summary)}
                  className="w-full text-left px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl flex items-center gap-2"
                >
                  <FileText className="w-3.5 h-3.5 text-rose-600" />
                  Official BRS PDF Report
                </button>
                <div className="my-1 border-t border-slate-100" />
                <button
                  onClick={downloadBankStatementTemplate}
                  className="w-full text-left px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl flex items-center gap-2"
                >
                  <Download className="w-3.5 h-3.5 text-blue-600" />
                  Download CSV Template
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Statement Selector & Summary Info Bar */}
        <div className="pt-4 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs text-slate-600">
          <div className="flex items-center gap-3">
            <span className="font-bold text-slate-700">Active Statement:</span>
            {statements.length > 0 ? (
              <select
                value={activeStatementId}
                onChange={(e) => setActiveStatementId(e.target.value)}
                className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              >
                {statements.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.bankName} • {s.accountNumber.slice(-8)} ({s.statementPeriodStart} to {s.statementPeriodEnd}) - {s.status.toUpperCase()}
                  </option>
                ))}
              </select>
            ) : (
              <span className="text-slate-400 italic">No statement loaded yet. Click "Load UAE Sample" or "Upload".</span>
            )}
          </div>

          {currentStatement && (
            <div className="flex items-center gap-4 text-slate-500">
              <span>
                Bank: <strong className="text-slate-800">{currentStatement.bankName}</strong>
              </span>
              <span>
                Account: <strong className="text-slate-800">{currentStatement.accountNumber}</strong>
              </span>
              <span>
                Period: <strong className="text-slate-800">{currentStatement.statementPeriodStart} to {currentStatement.statementPeriodEnd}</strong>
              </span>
            </div>
          )}
        </div>
      </div>

      {/* 5 Executive KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Card 1: Bank Closing Balance */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/80">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Bank Balance (Closing)</span>
            <Landmark className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-lg font-black text-slate-900 tracking-tight">
            {formatAED(summary.statementClosingBalance)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
            <span>As per Bank Statement</span>
            <span className="font-semibold text-slate-600">{currentTransactions.length} txns</span>
          </div>
        </div>

        {/* Card 2: Deposits in Transit */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/80">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Deposits in Transit</span>
            <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-lg font-black text-emerald-600 tracking-tight">
            +{formatAED(summary.depositsInTransit)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
            <span>Uncleared Rent Receipts</span>
            <span className="font-semibold text-emerald-700">{unclearedReceipts.length} receipts</span>
          </div>
        </div>

        {/* Card 3: Outstanding Debits */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/80">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Outstanding Debits</span>
            <ArrowUpRight className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-lg font-black text-rose-600 tracking-tight">
            -{formatAED(summary.unclearedDebits)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
            <span>Uncleared Invoices / Payments</span>
            <span className="font-semibold text-rose-700">{unclearedInvoices.length} invoices</span>
          </div>
        </div>

        {/* Card 4: Adjusted Balance */}
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200/80">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Adjusted Bank Balance</span>
            <Building2 className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-lg font-black text-indigo-900 tracking-tight">
            {formatAED(summary.adjustedBankBalance)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Bank + Deposits - Outstanding
          </div>
        </div>

        {/* Card 5: Net Variance */}
        <div
          className={`rounded-2xl p-4 shadow-xs border transition-all ${
            summary.isBalanced
              ? 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white border-emerald-600 shadow-emerald-500/10'
              : 'bg-gradient-to-br from-amber-500 to-orange-600 text-white border-amber-600 shadow-amber-500/10'
          }`}
        >
          <div className="flex items-center justify-between text-white/90 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">Reconciliation Variance</span>
            {summary.isBalanced ? <CheckCircle2 className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          </div>
          <div className="text-lg font-black tracking-tight">
            {formatAED(summary.variance)}
          </div>
          <div className="text-[10px] text-white/90 mt-1 font-semibold flex items-center justify-between">
            <span>{summary.isBalanced ? 'Audit Passed: Balanced' : 'Unreconciled Variance'}</span>
            <span>{summary.isBalanced ? '100% OK' : 'Action Req.'}</span>
          </div>
        </div>
      </div>

      {/* Sub-Tabs Navigation */}
      <div className="bg-white rounded-2xl p-2 shadow-xs border border-slate-200/80 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setActiveSubTab('brs')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'brs'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            1. Formal BRS Statement
          </button>

          <button
            onClick={() => setActiveSubTab('debits')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'debits'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            2. Debit Recon (Maintenance & Payments)
            <span className="text-[10px] bg-rose-100 text-rose-800 px-1.5 py-0.2 rounded-full font-bold">
              {currentTransactions.filter((t) => t.type === 'debit').length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('credits')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'credits'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Receipt className="w-3.5 h-3.5" />
            3. Credit Recon (Rent Receipts)
            <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded-full font-bold">
              {currentTransactions.filter((t) => t.type === 'credit').length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('ledger')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'ledger'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            4. Bank Ledger
          </button>

          <button
            onClick={() => setActiveSubTab('uncleared')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
              activeSubTab === 'uncleared'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            5. Uncleared Book Items
            {(unclearedReceipts.length > 0 || unclearedInvoices.length > 0) && (
              <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded-full font-bold">
                {unclearedReceipts.length + unclearedInvoices.length}
              </span>
            )}
          </button>
        </div>

        {/* Quick Search */}
        {(activeSubTab === 'debits' || activeSubTab === 'credits' || activeSubTab === 'ledger') && (
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:w-60">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search description, ref, amount..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 pl-8 pr-3 py-1.5 rounded-xl text-xs focus:outline-hidden focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e: any) => setStatusFilter(e.target.value)}
              className="bg-slate-50 border border-slate-200 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-slate-700 focus:outline-hidden"
            >
              <option value="all">All Status</option>
              <option value="matched">Matched Only</option>
              <option value="suggested">Suggested Matches</option>
              <option value="unreconciled">Unreconciled Only</option>
            </select>
          </div>
        )}
      </div>

      {/* SUB-TAB 1: Formal Bank Reconciliation Statement */}
      {activeSubTab === 'brs' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-xs border border-slate-200/80 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-4">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                Official Bank Reconciliation Statement
              </h2>
              <p className="text-xs text-slate-500">
                Standard accounting statement reconciling Bank Statement with General Ledger books.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => exportBankReconciliationToPDF(currentStatement, currentTransactions, summary)}
                className="px-3.5 py-2 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                Print / PDF Report
              </button>
            </div>
          </div>

          {/* Formal Accounting Reconciliation Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border border-slate-200 rounded-2xl overflow-hidden">
              <thead className="bg-[#0A2540] text-white">
                <tr>
                  <th className="py-3 px-4 font-bold">Line</th>
                  <th className="py-3 px-4 font-bold">Reconciliation Item / Accounting Schedule</th>
                  <th className="py-3 px-4 font-bold text-right">Subtotal (AED)</th>
                  <th className="py-3 px-4 font-bold text-right">Total Balance (AED)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {/* Section A: Bank Statement */}
                <tr className="bg-slate-50/80 font-bold text-slate-900">
                  <td className="py-3 px-4">1</td>
                  <td className="py-3 px-4">Balance as per Bank Statement (Closing Balance)</td>
                  <td className="py-3 px-4 text-right"></td>
                  <td className="py-3 px-4 text-right text-base text-blue-900">
                    {formatAED(summary.statementClosingBalance)}
                  </td>
                </tr>

                {/* Add: Deposits in Transit */}
                <tr>
                  <td className="py-3 px-4 text-slate-400">2</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-emerald-700">ADD:</span>
                      <span>Deposits in Transit (Rent Receipts entered in books, not yet cleared by bank)</span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {unclearedReceipts.length} rental receipts awaiting bank credit
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right text-emerald-600 font-bold">
                    +{formatAED(summary.depositsInTransit)}
                  </td>
                  <td className="py-3 px-4 text-right"></td>
                </tr>

                {/* Less: Outstanding Cheques / Payments */}
                <tr>
                  <td className="py-3 px-4 text-slate-400">3</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-rose-700">LESS:</span>
                      <span>Outstanding Cheques / Payments (Maintenance Invoices recorded in books, not yet debited by bank)</span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">
                      {unclearedInvoices.length} maintenance invoices / unpresented cheques
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right text-rose-600 font-bold">
                    -{formatAED(summary.unclearedDebits)}
                  </td>
                  <td className="py-3 px-4 text-right"></td>
                </tr>

                {/* Adjusted Bank Balance */}
                <tr className="bg-blue-50/60 font-bold text-blue-900 border-t-2 border-b-2 border-blue-200">
                  <td className="py-3 px-4">4</td>
                  <td className="py-3 px-4">= ADJUSTED BANK BALANCE</td>
                  <td className="py-3 px-4 text-right"></td>
                  <td className="py-3 px-4 text-right text-base font-black">
                    {formatAED(summary.adjustedBankBalance)}
                  </td>
                </tr>

                {/* Section B: Books (General Ledger) */}
                <tr className="bg-slate-50/80 font-bold text-slate-900">
                  <td className="py-3 px-4">5</td>
                  <td className="py-3 px-4">Balance as per Books (Rental Receipts - Maintenance Expenses)</td>
                  <td className="py-3 px-4 text-right"></td>
                  <td className="py-3 px-4 text-right text-base text-slate-900">
                    {formatAED(summary.bookBalance)}
                  </td>
                </tr>

                {/* Add: Direct Bank Credits not in books */}
                <tr>
                  <td className="py-3 px-4 text-slate-400">6</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-emerald-700">ADD:</span>
                      <span>Direct Bank Credits not yet booked (Unrecorded bank deposits)</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right text-emerald-600 font-bold">
                    +{formatAED(summary.unrecordedBankCredits)}
                  </td>
                  <td className="py-3 px-4 text-right"></td>
                </tr>

                {/* Less: Direct Bank Debits not in books */}
                <tr>
                  <td className="py-3 px-4 text-slate-400">7</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-rose-700">LESS:</span>
                      <span>Direct Bank Debits / Utility Bills / Charges not yet booked</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right text-rose-600 font-bold">
                    -{formatAED(summary.unrecordedBankDebits)}
                  </td>
                  <td className="py-3 px-4 text-right"></td>
                </tr>

                {/* Adjusted Book Balance */}
                <tr className="bg-indigo-50/60 font-bold text-indigo-900 border-t-2 border-b-2 border-indigo-200">
                  <td className="py-3 px-4">8</td>
                  <td className="py-3 px-4">= ADJUSTED BOOK BALANCE</td>
                  <td className="py-3 px-4 text-right"></td>
                  <td className="py-3 px-4 text-right text-base font-black">
                    {formatAED(summary.adjustedBookBalance)}
                  </td>
                </tr>

                {/* Net Variance */}
                <tr className={summary.isBalanced ? 'bg-emerald-50 text-emerald-950 font-black' : 'bg-amber-50 text-amber-950 font-black'}>
                  <td className="py-3 px-4">9</td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <span>NET RECONCILIATION VARIANCE (Adjusted Bank - Adjusted Book)</span>
                      {summary.isBalanced ? (
                        <span className="bg-emerald-600 text-white text-[10px] px-2 py-0.5 rounded-full uppercase">
                          Balanced
                        </span>
                      ) : (
                        <span className="bg-amber-600 text-white text-[10px] px-2 py-0.5 rounded-full uppercase">
                          Action Required
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right"></td>
                  <td className="py-3 px-4 text-right text-lg">
                    {formatAED(summary.variance)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Audit Certification Block */}
          <div className="bg-slate-50 rounded-2xl p-6 border border-slate-200/80">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              Accounting Sign-Off & Audit Certification
            </h3>
            <p className="text-xs text-slate-500 mb-6">
              This statement certifies that all cash and bank entries for the period have been verified against invoices, receipts, and bank statements pursuant to UAE accounting regulations.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 border-t border-slate-200">
              <div>
                <div className="h-10 border-b border-dashed border-slate-400"></div>
                <div className="text-xs font-bold text-slate-800 mt-2">Prepared By</div>
                <div className="text-[11px] text-slate-500">Property Accountant</div>
              </div>
              <div>
                <div className="h-10 border-b border-dashed border-slate-400"></div>
                <div className="text-xs font-bold text-slate-800 mt-2">Verified By</div>
                <div className="text-[11px] text-slate-500">Finance Manager</div>
              </div>
              <div>
                <div className="h-10 border-b border-dashed border-slate-400"></div>
                <div className="text-xs font-bold text-slate-800 mt-2">Approved By</div>
                <div className="text-[11px] text-slate-500">Director / Auditor</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 2: Debit Reconciliation (Money Out / Maintenance Invoices & Other Payments) */}
      {activeSubTab === 'debits' && (
        <div className="bg-white rounded-3xl p-6 shadow-xs border border-slate-200/80 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold text-slate-900">
                  Debit Reconciliation (Money Out)
                </h2>
                <span className="text-xs bg-rose-50 text-rose-700 font-bold border border-rose-200 px-2 py-0.5 rounded-full">
                  Maintenance Invoices & Payments
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Every bank withdrawal/debit must be reconciled with a Maintenance Purchase Tax Invoice or classified as utility/bank fee.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500">
                Debits Reconciled: <strong className="text-slate-800">{currentTransactions.filter((t) => t.type === 'debit' && (t.reconciliationStatus === 'matched' || t.reconciliationStatus === 'manual_other')).length}</strong> / {currentTransactions.filter((t) => t.type === 'debit').length}
              </span>
            </div>
          </div>

          {/* Debits Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-3 font-bold">Date</th>
                  <th className="py-3 px-3 font-bold">Bank Description / Particulars</th>
                  <th className="py-3 px-3 font-bold">Cheque / Ref #</th>
                  <th className="py-3 px-3 font-bold text-right">Debit (AED)</th>
                  <th className="py-3 px-3 font-bold">Status</th>
                  <th className="py-3 px-3 font-bold">Matched Maintenance Invoice / Classification</th>
                  <th className="py-3 px-3 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {debitTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      No debit transactions match your search or filter.
                    </td>
                  </tr>
                ) : (
                  debitTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3 px-3 font-medium text-slate-700 whitespace-nowrap">
                        {tx.date}
                      </td>
                      <td className="py-3 px-3 text-slate-800 font-semibold max-w-xs truncate" title={tx.description}>
                        {tx.description}
                      </td>
                      <td className="py-3 px-3 text-slate-600 font-mono">
                        {tx.referenceNo || '—'}
                      </td>
                      <td className="py-3 px-3 text-right font-black text-rose-600 whitespace-nowrap">
                        {formatAED(tx.amount)}
                      </td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        {tx.reconciliationStatus === 'matched' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Matched
                          </span>
                        ) : tx.reconciliationStatus === 'manual_other' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
                            <Check className="w-3 h-3 text-blue-600" />
                            Other Payment
                          </span>
                        ) : tx.reconciliationStatus === 'suggested' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
                            <HelpCircle className="w-3 h-3 text-amber-600" />
                            Suggested
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
                            <AlertCircle className="w-3 h-3 text-slate-400" />
                            Unreconciled
                          </span>
                        )}
                      </td>

                      {/* Matched Info */}
                      <td className="py-3 px-3">
                        {tx.matchedEntityRef ? (
                          <div>
                            <div className="font-bold text-slate-800 flex items-center gap-1">
                              <CreditCard className="w-3 h-3 text-indigo-600" />
                              <span>Invoice #{tx.matchedEntityRef}</span>
                              <span className="text-[10px] text-slate-400">({tx.matchedEntityName})</span>
                            </div>
                            {tx.notes && <div className="text-[10px] text-slate-500 truncate">{tx.notes}</div>}
                          </div>
                        ) : tx.otherPaymentCategory ? (
                          <div>
                            <div className="font-bold text-blue-800">{tx.otherPaymentCategory}</div>
                            {tx.notes && <div className="text-[10px] text-slate-500 truncate">{tx.notes}</div>}
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">No invoice linked yet</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {tx.reconciliationStatus === 'suggested' && (
                            <button
                              onClick={() => handleConfirmSuggestedMatch(tx)}
                              className="px-2.5 py-1 text-[11px] font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition shadow-xs flex items-center gap-1"
                              title="Accept suggested match"
                            >
                              <Check className="w-3 h-3" />
                              Confirm
                            </button>
                          )}

                          <button
                            onClick={() => {
                              setSelectedTxForMatch(tx);
                              setIsLinkInvoiceModalOpen(true);
                            }}
                            className="px-2.5 py-1 text-[11px] font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition"
                            title="Link to Maintenance Invoice"
                          >
                            <LinkIcon className="w-3 h-3" />
                            Link Invoice
                          </button>

                          <button
                            onClick={() => {
                              setSelectedTxForMatch(tx);
                              setOtherCategory(tx.otherPaymentCategory || detectOtherPaymentCategory(tx.description) || 'Maintenance & Repairs');
                              setIsOtherPaymentModalOpen(true);
                            }}
                            className="px-2.5 py-1 text-[11px] font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition"
                            title="Classify as Other Payment (DEWA, Bank fees, Chiller)"
                          >
                            Other Payment
                          </button>

                          {(tx.reconciliationStatus === 'matched' || tx.reconciliationStatus === 'manual_other') && (
                            <button
                              onClick={() => handleUnlinkMatch(tx)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition"
                              title="Unlink match"
                            >
                              <Unlink className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB 3: Credit Reconciliation (Money In / Rental Receipts) */}
      {activeSubTab === 'credits' && (
        <div className="bg-white rounded-3xl p-6 shadow-xs border border-slate-200/80 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-extrabold text-slate-900">
                  Credit Reconciliation (Money In)
                </h2>
                <span className="text-xs bg-emerald-50 text-emerald-700 font-bold border border-emerald-200 px-2 py-0.5 rounded-full">
                  Rental Receipts & Cheques
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Every bank deposit/credit must be reconciled with a Rental Receipt voucher or tenant deposit.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500">
                Credits Reconciled: <strong className="text-slate-800">{currentTransactions.filter((t) => t.type === 'credit' && t.reconciliationStatus === 'matched').length}</strong> / {currentTransactions.filter((t) => t.type === 'credit').length}
              </span>
            </div>
          </div>

          {/* Credits Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-3 font-bold">Date</th>
                  <th className="py-3 px-3 font-bold">Bank Description / Particulars</th>
                  <th className="py-3 px-3 font-bold">Cheque / Ref #</th>
                  <th className="py-3 px-3 font-bold text-right">Credit (AED)</th>
                  <th className="py-3 px-3 font-bold">Status</th>
                  <th className="py-3 px-3 font-bold">Matched Rental Receipt</th>
                  <th className="py-3 px-3 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {creditTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      No credit transactions match your search or filter.
                    </td>
                  </tr>
                ) : (
                  creditTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3 px-3 font-medium text-slate-700 whitespace-nowrap">
                        {tx.date}
                      </td>
                      <td className="py-3 px-3 text-slate-800 font-semibold max-w-xs truncate" title={tx.description}>
                        {tx.description}
                      </td>
                      <td className="py-3 px-3 text-slate-600 font-mono">
                        {tx.referenceNo || '—'}
                      </td>
                      <td className="py-3 px-3 text-right font-black text-emerald-600 whitespace-nowrap">
                        {formatAED(tx.amount)}
                      </td>
                      <td className="py-3 px-3 whitespace-nowrap">
                        {tx.reconciliationStatus === 'matched' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Matched
                          </span>
                        ) : tx.reconciliationStatus === 'suggested' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full">
                            <HelpCircle className="w-3 h-3 text-amber-600" />
                            Suggested
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full">
                            <AlertCircle className="w-3 h-3 text-slate-400" />
                            Unreconciled
                          </span>
                        )}
                      </td>

                      {/* Matched Receipt Info */}
                      <td className="py-3 px-3">
                        {tx.matchedEntityRef ? (
                          <div>
                            <div className="font-bold text-slate-800 flex items-center gap-1">
                              <Receipt className="w-3 h-3 text-emerald-600" />
                              <span>Receipt #{tx.matchedEntityRef}</span>
                              <span className="text-[10px] text-slate-400">({tx.matchedEntityName})</span>
                            </div>
                            {tx.notes && <div className="text-[10px] text-slate-500 truncate">{tx.notes}</div>}
                          </div>
                        ) : (
                          <span className="text-slate-400 italic">No receipt linked yet</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {tx.reconciliationStatus === 'suggested' && (
                            <button
                              onClick={() => handleConfirmSuggestedMatch(tx)}
                              className="px-2.5 py-1 text-[11px] font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition shadow-xs flex items-center gap-1"
                              title="Accept suggested match"
                            >
                              <Check className="w-3 h-3" />
                              Confirm
                            </button>
                          )}

                          <button
                            onClick={() => {
                              setSelectedTxForMatch(tx);
                              setIsLinkReceiptModalOpen(true);
                            }}
                            className="px-2.5 py-1 text-[11px] font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition"
                            title="Link to Rental Receipt"
                          >
                            <LinkIcon className="w-3 h-3" />
                            Link Receipt
                          </button>

                          {tx.reconciliationStatus === 'matched' && (
                            <button
                              onClick={() => handleUnlinkMatch(tx)}
                              className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition"
                              title="Unlink match"
                            >
                              <Unlink className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: Bank Statement Ledger */}
      {activeSubTab === 'ledger' && (
        <div className="bg-white rounded-3xl p-6 shadow-xs border border-slate-200/80 space-y-4">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">
                Full Bank Statement Ledger
              </h2>
              <p className="text-xs text-slate-500">
                Chronological list of all statement entries with running balances and audit status.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="py-3 px-3 font-bold">Date</th>
                  <th className="py-3 px-3 font-bold">Description</th>
                  <th className="py-3 px-3 font-bold">Ref / Cheque #</th>
                  <th className="py-3 px-3 font-bold text-right">Debit (AED)</th>
                  <th className="py-3 px-3 font-bold text-right">Credit (AED)</th>
                  <th className="py-3 px-3 font-bold text-right">Balance (AED)</th>
                  <th className="py-3 px-3 font-bold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {currentTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-slate-400">
                      No bank transactions available.
                    </td>
                  </tr>
                ) : (
                  currentTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-3 px-3 text-slate-700 whitespace-nowrap">{tx.date}</td>
                      <td className="py-3 px-3 font-semibold text-slate-800">{tx.description}</td>
                      <td className="py-3 px-3 font-mono text-slate-500">{tx.referenceNo || '—'}</td>
                      <td className="py-3 px-3 text-right font-bold text-rose-600">
                        {tx.type === 'debit' ? formatAED(tx.amount) : '—'}
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-emerald-600">
                        {tx.type === 'credit' ? formatAED(tx.amount) : '—'}
                      </td>
                      <td className="py-3 px-3 text-right font-medium text-slate-700">
                        {tx.balance !== undefined ? formatAED(tx.balance) : '—'}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            tx.reconciliationStatus === 'matched'
                              ? 'bg-emerald-100 text-emerald-800'
                              : tx.reconciliationStatus === 'manual_other'
                              ? 'bg-blue-100 text-blue-800'
                              : tx.reconciliationStatus === 'suggested'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {tx.reconciliationStatus.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SUB-TAB 5: Uncleared Book Items (Deposits in Transit & Unpresented Cheques) */}
      {activeSubTab === 'uncleared' && (
        <div className="space-y-6">
          {/* Uncleared Rent Receipts */}
          <div className="bg-white rounded-3xl p-6 shadow-xs border border-slate-200/80 space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-extrabold text-slate-900">
                    Deposits in Transit (Uncleared Rental Receipts)
                  </h3>
                  <span className="text-xs bg-emerald-50 text-emerald-700 font-bold border border-emerald-200 px-2 py-0.5 rounded-full">
                    {unclearedReceipts.length} items • Total: {formatAED(summary.depositsInTransit)}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Rental Receipts entered in ERP/books that have not yet cleared or appeared in the bank statement.
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3 font-bold">Receipt #</th>
                    <th className="py-2.5 px-3 font-bold">Date</th>
                    <th className="py-2.5 px-3 font-bold">Tenant Name</th>
                    <th className="py-2.5 px-3 font-bold">Cheque #</th>
                    <th className="py-2.5 px-3 font-bold">Bank</th>
                    <th className="py-2.5 px-3 font-bold text-right">Amount (AED)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {unclearedReceipts.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-400">
                        <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-1" />
                        All rental receipts in books have been cleared and reconciled in the bank!
                      </td>
                    </tr>
                  ) : (
                    unclearedReceipts.map((r) => (
                      <tr key={r.id} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-3 font-bold text-slate-800">#{r.receiptNo}</td>
                        <td className="py-2.5 px-3 text-slate-600">{r.installmentDate}</td>
                        <td className="py-2.5 px-3 font-medium text-slate-800">{r.tenantName || '—'}</td>
                        <td className="py-2.5 px-3 font-mono text-slate-600">{r.chequeNo || '—'}</td>
                        <td className="py-2.5 px-3 text-slate-600">{r.bankName || '—'}</td>
                        <td className="py-2.5 px-3 text-right font-black text-emerald-600">
                          {formatAED(r.amount)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Uncleared Maintenance Invoices */}
          <div className="bg-white rounded-3xl p-6 shadow-xs border border-slate-200/80 space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-extrabold text-slate-900">
                    Outstanding Cheques / Payments (Uncleared Maintenance Invoices)
                  </h3>
                  <span className="text-xs bg-rose-50 text-rose-700 font-bold border border-rose-200 px-2 py-0.5 rounded-full">
                    {unclearedInvoices.length} items • Total: {formatAED(summary.unclearedDebits)}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-0.5">
                  Maintenance bills & vendor invoices entered in books where cheques or payments have not yet presented at the bank.
                </p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 text-slate-600 border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3 font-bold">Invoice #</th>
                    <th className="py-2.5 px-3 font-bold">Date</th>
                    <th className="py-2.5 px-3 font-bold">Supplier / Vendor</th>
                    <th className="py-2.5 px-3 font-bold">Category</th>
                    <th className="py-2.5 px-3 font-bold text-right">Net Amount</th>
                    <th className="py-2.5 px-3 font-bold text-right">VAT 5%</th>
                    <th className="py-2.5 px-3 font-bold text-right">Gross Total (AED)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {unclearedInvoices.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        <CheckCircle2 className="w-6 h-6 text-emerald-500 mx-auto mb-1" />
                        All maintenance invoices in books have cleared the bank!
                      </td>
                    </tr>
                  ) : (
                    unclearedInvoices.map((i) => (
                      <tr key={i.id} className="hover:bg-slate-50/80">
                        <td className="py-2.5 px-3 font-bold text-slate-800">#{i.invoiceNumber}</td>
                        <td className="py-2.5 px-3 text-slate-600">{i.invoiceDate}</td>
                        <td className="py-2.5 px-3 font-medium text-slate-800">{i.supplierName}</td>
                        <td className="py-2.5 px-3 text-slate-600">{i.expenseCategory || 'Maintenance'}</td>
                        <td className="py-2.5 px-3 text-right text-slate-600">{formatAED(i.netAmount)}</td>
                        <td className="py-2.5 px-3 text-right text-indigo-600 font-semibold">{formatAED(i.taxAmount)}</td>
                        <td className="py-2.5 px-3 text-right font-black text-rose-600">
                          {formatAED(i.totalInvoiceAmount)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: Upload Bank Statement */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                  <Upload className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">Upload Bank Statement</h3>
                  <p className="text-[11px] text-slate-500">Supports CSV, XLSX, XLS format from UAE banks</p>
                </div>
              </div>
              <button
                onClick={() => setIsUploadModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Dropzone */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-blue-200 hover:border-blue-500 rounded-2xl p-8 text-center cursor-pointer bg-blue-50/40 hover:bg-blue-50/80 transition group"
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleFileUpload}
                className="hidden"
              />
              <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto mb-3 shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
                <FileSpreadsheet className="w-6 h-6" />
              </div>
              <div className="text-xs font-bold text-slate-800">
                Click to browse or drop your bank statement here
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Emirates NBD, ADCB, DIB, FAB, Mashreq, or standard CSV / Excel statement
              </p>
            </div>

            {/* Template Download Prompt */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-slate-800">Need a format template?</div>
                <div className="text-[11px] text-slate-500">Download standard CSV template with UAE columns</div>
              </div>
              <button
                onClick={downloadBankStatementTemplate}
                className="px-3 py-1.5 text-xs font-bold text-blue-700 bg-white border border-blue-200 hover:bg-blue-50 rounded-xl transition shadow-xs flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                Template
              </button>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setIsUploadModalOpen(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Link Bank Debit to Maintenance Invoice */}
      {isLinkInvoiceModalOpen && selectedTxForMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900">
                  Link Debit to Maintenance Invoice
                </h3>
                <p className="text-[11px] text-slate-500">
                  Bank Debit: <strong className="text-rose-600">{formatAED(selectedTxForMatch.amount)}</strong> on {selectedTxForMatch.date} ({selectedTxForMatch.description})
                </p>
              </div>
              <button
                onClick={() => {
                  setIsLinkInvoiceModalOpen(false);
                  setSelectedTxForMatch(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Invoices List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {invoices.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  No invoices available in the system. Upload invoices in the Upload workspace first.
                </div>
              ) : (
                invoices.map((inv) => {
                  const isExact = Math.abs(Number(inv.totalInvoiceAmount) - selectedTxForMatch.amount) < 0.05;
                  const isAlreadyMatched = currentTransactions.some(
                    (t) => t.matchedEntityId === inv.id && t.id !== selectedTxForMatch.id
                  );

                  return (
                    <div
                      key={inv.id}
                      onClick={() => handleApplyInvoiceMatch(inv)}
                      className={`p-3 rounded-2xl border transition cursor-pointer flex items-center justify-between gap-3 ${
                        isExact
                          ? 'border-emerald-300 bg-emerald-50/60 hover:bg-emerald-50'
                          : 'border-slate-200 hover:border-blue-400 hover:bg-slate-50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-xs text-slate-900">
                            Invoice #{inv.invoiceNumber}
                          </span>
                          <span className="text-[10px] font-semibold text-slate-500">
                            {inv.invoiceDate}
                          </span>
                          {isExact && (
                            <span className="text-[10px] font-bold bg-emerald-600 text-white px-2 py-0.2 rounded-full">
                              Exact Amount Match
                            </span>
                          )}
                          {isAlreadyMatched && (
                            <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.2 rounded-full">
                              Matched to another tx
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-slate-700 mt-0.5">
                          Supplier: <strong>{inv.supplierName}</strong> • {inv.expenseCategory || 'Maintenance'}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Net: {formatAED(inv.netAmount)} + VAT 5%: {formatAED(inv.taxAmount)}
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-sm font-black text-slate-900">
                          {formatAED(inv.totalInvoiceAmount)}
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleApplyInvoiceMatch(inv);
                          }}
                          className="mt-1 px-3 py-1 text-[11px] font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition"
                        >
                          Match This Invoice
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end shrink-0">
              <button
                onClick={() => {
                  setIsLinkInvoiceModalOpen(false);
                  setSelectedTxForMatch(null);
                }}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Link Bank Credit to Rental Receipt */}
      {isLinkReceiptModalOpen && selectedTxForMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-2xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900">
                  Link Credit to Rental Receipt
                </h3>
                <p className="text-[11px] text-slate-500">
                  Bank Credit: <strong className="text-emerald-600">{formatAED(selectedTxForMatch.amount)}</strong> on {selectedTxForMatch.date} ({selectedTxForMatch.description})
                </p>
              </div>
              <button
                onClick={() => {
                  setIsLinkReceiptModalOpen(false);
                  setSelectedTxForMatch(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Receipts List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {receipts.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  No rental receipts available in the system. Upload receipts in the Upload workspace first.
                </div>
              ) : (
                receipts.map((rec) => {
                  const isExact = Math.abs(Number(rec.amount) - selectedTxForMatch.amount) < 0.05;
                  const isAlreadyMatched = currentTransactions.some(
                    (t) => t.matchedEntityId === rec.id && t.id !== selectedTxForMatch.id
                  );

                  return (
                    <div
                      key={rec.id}
                      onClick={() => handleApplyReceiptMatch(rec)}
                      className={`p-3 rounded-2xl border transition cursor-pointer flex items-center justify-between gap-3 ${
                        isExact
                          ? 'border-emerald-300 bg-emerald-50/60 hover:bg-emerald-50'
                          : 'border-slate-200 hover:border-blue-400 hover:bg-slate-50'
                      }`}
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-xs text-slate-900">
                            Receipt #{rec.receiptNo}
                          </span>
                          <span className="text-[10px] font-semibold text-slate-500">
                            {rec.installmentDate}
                          </span>
                          {isExact && (
                            <span className="text-[10px] font-bold bg-emerald-600 text-white px-2 py-0.2 rounded-full">
                              Exact Amount Match
                            </span>
                          )}
                          {isAlreadyMatched && (
                            <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.2 rounded-full">
                              Matched to another tx
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-slate-700 mt-0.5">
                          Tenant: <strong>{rec.tenantName || 'N/A'}</strong> • Cheque #{rec.chequeNo || 'N/A'}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          Bank: {rec.bankName || 'N/A'} • Property: {rec.propertyRef || 'N/A'}
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-sm font-black text-emerald-700">
                          {formatAED(rec.amount)}
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleApplyReceiptMatch(rec);
                          }}
                          className="mt-1 px-3 py-1 text-[11px] font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition"
                        >
                          Match This Receipt
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="pt-2 border-t border-slate-100 flex justify-end shrink-0">
              <button
                onClick={() => {
                  setIsLinkReceiptModalOpen(false);
                  setSelectedTxForMatch(null);
                }}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: Categorize as Other Payment (DEWA, Bank Fees, Chiller, etc.) */}
      {isOtherPaymentModalOpen && selectedTxForMatch && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-sm font-extrabold text-slate-900">
                  Categorize as Other Payment
                </h3>
                <p className="text-[11px] text-slate-500">
                  Debit amount: <strong className="text-rose-600">{formatAED(selectedTxForMatch.amount)}</strong>
                </p>
              </div>
              <button
                onClick={() => {
                  setIsOtherPaymentModalOpen(false);
                  setSelectedTxForMatch(null);
                }}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Payment / Expense Category
                </label>
                <select
                  value={otherCategory}
                  onChange={(e: any) => setOtherCategory(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Maintenance & Repairs">Maintenance & Repairs</option>
                  <option value="DEWA / Electricity & Water">DEWA / Electricity & Water</option>
                  <option value="Chiller & Air Conditioning">Chiller & Air Conditioning (Empower / Tabreed)</option>
                  <option value="Govt & Municipal / Ejari Fees">Govt & Municipal / Ejari Fees</option>
                  <option value="Bank Charges & Commission">Bank Charges & Commission</option>
                  <option value="VAT / FTA Tax Settlement">VAT / FTA Tax Settlement</option>
                  <option value="Mortgage / Loan Installment">Mortgage / Loan Installment</option>
                  <option value="Security Deposit Refund">Security Deposit Refund to Tenant</option>
                  <option value="General Property Expense">General Property Expense</option>
                  <option value="Owner Drawing / Dividend">Owner Drawing / Dividend</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Description / Audit Notes
                </label>
                <textarea
                  rows={2}
                  value={otherNotes}
                  onChange={(e) => setOtherNotes(e.target.value)}
                  placeholder="e.g. DEWA payment for Al Wasl Tower common electricity"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => {
                  setIsOtherPaymentModalOpen(false);
                  setSelectedTxForMatch(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveOtherPayment}
                className="px-4 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-xs"
              >
                Save & Mark Reconciled
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
