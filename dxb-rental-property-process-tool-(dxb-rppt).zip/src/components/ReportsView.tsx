import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  FileText,
  Building2,
  Receipt,
  Percent,
  CheckCircle2,
  Layers,
  ArrowRight,
  Database,
  ExternalLink,
} from 'lucide-react';
import { TenancyContract, RentalReceipt, PurchaseTaxInvoice } from '../types';
import { formatAED, exportToExcel, exportToPDF, exportToCSV } from '../utils/exportUtils';
import { useAuth } from '../context/AuthContext';

interface ReportsViewProps {
  contracts: TenancyContract[];
  receipts: RentalReceipt[];
  invoices: PurchaseTaxInvoice[];
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  contracts,
  receipts,
  invoices,
}) => {
  const { user } = useAuth();
  const [activeExportTab, setActiveExportTab] = useState<'all' | 'zoho' | 'tally'>('all');

  const totalContractAmount = contracts.reduce((acc, c) => acc + (c.contractAmount || 0), 0);
  const totalActualAnnual = contracts.reduce((acc, c) => acc + (c.actualAnnualAmount || 0), 0);
  const totalSecurityDeposit = contracts.reduce((acc, c) => acc + (c.securityDeposit || 0), 0);
  const totalReceipts = receipts.reduce((acc, r) => acc + (r.amount || 0), 0);
  const totalMaintenance = invoices.reduce(
    (acc, i) => acc + (i.netAmount || (i.totalInvoiceAmount - (i.taxAmount || 0)) || 0),
    0
  );
  const totalVAT = invoices.reduce((acc, i) => acc + (i.taxAmount || 0), 0);
  const totalInvoiceAmount = invoices.reduce((acc, i) => acc + (i.totalInvoiceAmount || 0), 0);

  return (
    <div className="space-y-7 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-200/80">
        <div>
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200/60">
            Accounting Integration & Audit
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
            Financial Reports & ERP Export Center
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Export directly formatted spreadsheets for Zoho Books (UAE Edition), Tally Prime (UAE VAT), or comprehensive audit PDFs.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => exportToPDF(contracts, receipts, invoices, user?.displayName || undefined)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            Executive Audit PDF
          </button>
          <button
            onClick={() => exportToExcel(contracts, receipts, invoices, 'consolidated')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            Export Master Workbook (.xlsx)
          </button>
        </div>
      </div>

      {/* Batch Overview Cards */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-6 shadow-xs">
        <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4">
          Entire Batch Financial Aggregation
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3.5">
          <div className="p-3.5 bg-blue-50/60 rounded-2xl border border-blue-100">
            <span className="text-[11px] font-medium text-blue-700">Contract Value</span>
            <div className="text-base font-bold text-slate-900 mt-1">{formatAED(totalContractAmount)}</div>
            <span className="text-[10px] text-slate-500">{contracts.length} Contracts</span>
          </div>

          <div className="p-3.5 bg-emerald-50/60 rounded-2xl border border-emerald-100">
            <span className="text-[11px] font-medium text-emerald-700">Actual Annual Rent</span>
            <div className="text-base font-bold text-slate-900 mt-1">{formatAED(totalActualAnnual)}</div>
            <span className="text-[10px] text-slate-500">Run-Rate</span>
          </div>

          <div className="p-3.5 bg-rose-50/60 rounded-2xl border border-rose-100">
            <span className="text-[11px] font-medium text-rose-700">Maintenance (Net)</span>
            <div className="text-base font-bold text-slate-900 mt-1">{formatAED(totalMaintenance)}</div>
            <span className="text-[10px] text-slate-500">Pre-Tax</span>
          </div>

          <div className="p-3.5 bg-emerald-100/70 rounded-2xl border-2 border-emerald-400">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">Total Net Income</span>
            <div className={`text-base font-extrabold mt-1 ${totalActualAnnual - totalMaintenance >= 0 ? 'text-emerald-950' : 'text-rose-700'}`}>
              {formatAED(totalActualAnnual - totalMaintenance)}
            </div>
            <span className="text-[10px] font-semibold text-emerald-700">Annual Rent − Maint.</span>
          </div>

          <div className="p-3.5 bg-amber-50/60 rounded-2xl border border-amber-100">
            <span className="text-[11px] font-medium text-amber-700">Security Deposits</span>
            <div className="text-base font-bold text-slate-900 mt-1">{formatAED(totalSecurityDeposit)}</div>
            <span className="text-[10px] text-slate-500">Escrow Held</span>
          </div>

          <div className="p-3.5 bg-teal-50/60 rounded-2xl border border-teal-100">
            <span className="text-[11px] font-medium text-teal-700">Receipts Cleared</span>
            <div className="text-base font-bold text-slate-900 mt-1">{formatAED(totalReceipts)}</div>
            <span className="text-[10px] text-slate-500">{receipts.length} Cheques</span>
          </div>

          <div className="p-3.5 bg-indigo-50/60 rounded-2xl border border-indigo-100">
            <span className="text-[11px] font-medium text-indigo-700">5% Input VAT</span>
            <div className="text-base font-bold text-indigo-950 mt-1">{formatAED(totalVAT)}</div>
            <span className="text-[10px] text-indigo-600 font-semibold">FTA Box 9 Ready</span>
          </div>
        </div>
      </div>

      {/* Export Format Profiles */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Zoho Books (UAE) Card */}
        <div className="bg-white rounded-3xl border border-slate-200/90 p-6 shadow-xs flex flex-col justify-between group hover:border-blue-400 transition">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-500 text-white flex items-center justify-center font-black text-sm shadow-xs">
                  ZB
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Zoho Books (UAE Edition)</h3>
                  <p className="text-xs text-slate-500">Direct Vendor Bills & Tenancy Invoices Import</p>
                </div>
              </div>
              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                UAE Ready
              </span>
            </div>

            <p className="text-xs text-slate-600 mt-4 leading-relaxed">
              Generates an Excel import sheet with the exact required header mapping for Zoho Books UAE:
            </p>

            <ul className="mt-3 space-y-1.5 text-xs text-slate-500">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Vendor Bills: Vendor Name, Bill#, Bill Date, Account, Item Price, 5% Tax Name, Total AED, Vendor TRN.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Customer Invoices: Tenant Name, Contract #, Start/Due Date, Rental Income Account, Total AED.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                <span>Customer Payments: Cheque numbers, clearing bank deposit account, installment dates.</span>
              </li>
            </ul>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-400">Template: Zoho Books UAE Multi-Entity</span>
            <button
              onClick={() => exportToExcel(contracts, receipts, invoices, 'zoho')}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-xl transition shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              Download Zoho Books Import (.xlsx)
            </button>
          </div>
        </div>

        {/* Tally Prime (UAE VAT) Card */}
        <div className="bg-white rounded-3xl border border-slate-200/90 p-6 shadow-xs flex flex-col justify-between group hover:border-indigo-400 transition">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-700 text-white flex items-center justify-center font-black text-sm shadow-xs">
                  TP
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">Tally Prime (UAE VAT Release)</h3>
                  <p className="text-xs text-slate-500">Voucher & Ledger Import Format</p>
                </div>
              </div>
              <span className="text-[11px] font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200">
                VAT Certified
              </span>
            </div>

            <p className="text-xs text-slate-600 mt-4 leading-relaxed">
              Formatted voucher structure ready for Tally Prime UAE accounting ledger imports:
            </p>

            <ul className="mt-3 space-y-1.5 text-xs text-slate-500">
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                <span>Purchase Vouchers: Supplier Name, Party TRN, Place of Supply (Dubai), Input VAT @ 5% Ledger.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                <span>Receipt Vouchers: Cheque transaction reference, Bank Ledger, Tenant party mapping.</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                <span>Sales / Lease Vouchers: Tenancy Ejari Contract Narration, Annual Rent recognition.</span>
              </li>
            </ul>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-400">Template: Tally Prime UAE VAT Vouchers</span>
            <button
              onClick={() => exportToExcel(contracts, receipts, invoices, 'tally')}
              className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition shadow-xs"
            >
              <Download className="w-3.5 h-3.5" />
              Download Tally Prime Import (.xlsx)
            </button>
          </div>
        </div>
      </div>

      {/* Quick Individual CSV Downloader */}
      <div className="bg-white rounded-3xl border border-slate-200/90 p-6 shadow-xs">
        <h4 className="text-sm font-bold text-slate-900 mb-2">Individual CSV Dataset Downloads</h4>
        <p className="text-xs text-slate-500 mb-4">
          Download lightweight comma-separated files for custom spreadsheet modeling or third-party database ingestion.
        </p>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => exportToCSV(contracts, 'Tenancy_Contracts_Data')}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition"
          >
            <Building2 className="w-3.5 h-3.5 text-blue-600" />
            Download Tenancy Contracts CSV ({contracts.length})
          </button>
          <button
            onClick={() => exportToCSV(receipts, 'Rental_Receipts_Data')}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition"
          >
            <Receipt className="w-3.5 h-3.5 text-teal-600" />
            Download Receipts CSV ({receipts.length})
          </button>
          <button
            onClick={() => exportToCSV(invoices, 'Purchase_Tax_Invoices_Data')}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-slate-700 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl transition"
          >
            <Percent className="w-3.5 h-3.5 text-indigo-600" />
            Download Purchase Tax Invoices CSV ({invoices.length})
          </button>
        </div>
      </div>
    </div>
  );
};
