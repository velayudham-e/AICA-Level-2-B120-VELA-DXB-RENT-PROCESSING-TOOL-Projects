import React, { useState } from 'react';
import {
  TrendingUp,
  Receipt,
  Building,
  ShieldCheck,
  Wrench,
  Percent,
  Wallet,
  ArrowUpRight,
  ArrowDownRight,
  Scale,
  Sparkles,
  Layers,
  ChevronRight,
  HelpCircle,
} from 'lucide-react';
import { usePropertyData } from '../../context/PropertyDataContext';
import { ActiveTab } from '../../types';

interface DashboardProps {
  onNavigate: (tab: ActiveTab) => void;
  onOpenUpload: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate, onOpenUpload }) => {
  const {
    metrics,
    filteredContracts,
    filteredReceipts,
    filteredInvoices,
    filteredStatements,
    filters,
    setFilters,
    propertiesList,
  } = usePropertyData();

  const [activeTrendMetric, setActiveTrendMetric] = useState<'both' | 'contract' | 'actual'>('both');
  const [hoveredMonth, setHoveredMonth] = useState<number | null>(null);

  const formatAED = (val: number) => {
    return `AED ${val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatShortAED = (val: number) => {
    if (val >= 1000000) return `AED ${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `AED ${(val / 1000).toFixed(0)}k`;
    return `AED ${val.toFixed(0)}`;
  };

  // Find max value for SVG chart scaling
  const maxTrendVal = Math.max(
    ...metrics.monthlyTrends.map((t) => Math.max(t.contractAmount, t.actualAnnualAmount, t.receipts, 10000)),
    50000
  );

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Top Welcome & Quick Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-blue-900 to-indigo-900 rounded-3xl p-6 text-white shadow-xl relative overflow-hidden">
        {/* Subtle decorative circles */}
        <div className="absolute right-0 top-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute right-40 bottom-0 w-60 h-60 bg-cyan-400/10 rounded-full blur-2xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded-full bg-cyan-400/20 text-cyan-200 text-[10px] font-bold uppercase tracking-wider border border-cyan-400/30">
              UAE Real Estate Ledger
            </span>
            <span className="text-blue-200 text-xs">• 100% FTA UAE VAT Compliant</span>
          </div>
          <h2 className="text-2xl font-extrabold tracking-tight">
            Rental Property Operations Overview
          </h2>
          <p className="text-xs text-blue-200/80 max-w-xl mt-1">
            Processed Tenancy Contracts (Ejari), Cheque Receipts, Maintenance Tax Invoices, and Automated Bank Reconciliation.
          </p>
        </div>

        <div className="relative z-10 flex items-center gap-3">
          <button
            onClick={onOpenUpload}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white text-blue-900 font-bold text-xs hover:bg-blue-50 transition-all shadow-md active:scale-95 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-blue-600" />
            <span>Process New Document</span>
          </button>
        </div>
      </div>

      {/* KPI Section: 9 Key Metrics Requested */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
            <span>Primary Financial Indicators (AED)</span>
            <span className="text-xs font-normal text-slate-400">
              ({filters.propertyFilter === 'ALL' ? 'All Properties' : filters.propertyFilter} •{' '}
              {filters.periodFilter === 'ALL' ? 'All Time' : 'Year 2026'})
            </span>
          </h3>
          <span className="text-xs text-blue-600 font-medium cursor-pointer hover:underline" onClick={() => onNavigate('reports')}>
            View Detailed Reports →
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* 1. Total Contract Amount Processed */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all group">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Total Contract Amount</span>
              <div className="p-2 rounded-xl bg-blue-50 text-blue-600 group-hover:scale-110 transition-transform">
                <Building className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono">
              {formatAED(metrics.totalContractAmount)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <span className="font-semibold text-slate-700">{filteredContracts.length}</span> Tenancy Contracts Registered
            </div>
          </div>

          {/* 2. Total Actual Annual Amount */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all group">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Total Actual Annual Amount</span>
              <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600 group-hover:scale-110 transition-transform">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono">
              {formatAED(metrics.totalActualAnnualAmount)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <span>Annualized rental billing baseline</span>
            </div>
          </div>

          {/* 3. Total Security Deposit */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all group">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Total Security Deposit</span>
              <div className="p-2 rounded-xl bg-amber-50 text-amber-600 group-hover:scale-110 transition-transform">
                <ShieldCheck className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono">
              {formatAED(metrics.totalSecurityDeposit)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <span>Held in escrow / security reserve</span>
            </div>
          </div>

          {/* 4. Total Receipts Collected */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all group">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Total Receipts Collected</span>
              <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600 group-hover:scale-110 transition-transform">
                <Receipt className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono">
              {formatAED(metrics.totalReceipts)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <span className="font-semibold text-slate-700">{filteredReceipts.length}</span> Cheque Installments Processed
            </div>
          </div>

          {/* 5. Total Purchase Maintenance Exp */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all group">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Purchase Maintenance Exp</span>
              <div className="p-2 rounded-xl bg-rose-50 text-rose-600 group-hover:scale-110 transition-transform">
                <Wrench className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono text-rose-600">
              {formatAED(metrics.totalPurchaseMaintenanceExp)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <span className="font-semibold text-slate-700">{filteredInvoices.length}</span> Purchase Tax Invoices
            </div>
          </div>

          {/* 6. Total VAT on Purchase Invoice */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-sm hover:shadow-md transition-all group">
            <div className="flex items-center justify-between text-slate-500 mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider">Total VAT on Purchase (5%)</span>
              <div className="p-2 rounded-xl bg-orange-50 text-orange-600 group-hover:scale-110 transition-transform">
                <Percent className="w-4 h-4" />
              </div>
            </div>
            <div className="text-2xl font-extrabold text-slate-900 tracking-tight font-mono">
              {formatAED(metrics.totalVATOnPurchaseInvoice)}
            </div>
            <div className="mt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <span>Input Tax Credit claimable from FTA</span>
            </div>
          </div>
        </div>
      </div>

      {/* Net Income & UAE VAT Reconciliation Highlights */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Net Rent Income Card */}
        <div className="bg-gradient-to-br from-emerald-500 to-teal-700 text-white rounded-3xl p-6 shadow-lg shadow-emerald-500/20 relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 p-6 opacity-10">
            <Wallet className="w-32 h-32" />
          </div>
          <div>
            <div className="flex items-center justify-between text-emerald-100 mb-2">
              <span className="text-xs uppercase font-bold tracking-wider">Formula Metric</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 font-mono">
                Actual Rent - Maintenance
              </span>
            </div>
            <h4 className="text-sm font-medium text-emerald-100">Net Rent Income</h4>
            <div className="text-3xl font-extrabold tracking-tight font-mono mt-1">
              {formatAED(metrics.netRentIncome)}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-emerald-400/30 flex items-center justify-between text-xs text-emerald-100">
            <span>Annual Rent: {formatShortAED(metrics.totalActualAnnualAmount)}</span>
            <span>Maint: {formatShortAED(metrics.totalPurchaseMaintenanceExp)}</span>
          </div>
        </div>

        {/* Total VAT on Actual Rent */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-800 text-white rounded-3xl p-6 shadow-lg shadow-blue-500/20 relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 p-6 opacity-10">
            <Percent className="w-32 h-32" />
          </div>
          <div>
            <div className="flex items-center justify-between text-blue-100 mb-2">
              <span className="text-xs uppercase font-bold tracking-wider">Output Tax</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/20 font-mono">
                UAE Commercial 5%
              </span>
            </div>
            <h4 className="text-sm font-medium text-blue-100">Total VAT on Actual Rent</h4>
            <div className="text-3xl font-extrabold tracking-tight font-mono mt-1">
              {formatAED(metrics.totalVATOnActualRent)}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-blue-400/30 flex items-center justify-between text-xs text-blue-100">
            <span>Commercial lease output tax</span>
            <span>Res: 0% exempt</span>
          </div>
        </div>

        {/* Net VAT (Output - Input) */}
        <div className="bg-gradient-to-br from-slate-900 to-blue-950 text-white rounded-3xl p-6 shadow-lg shadow-slate-900/20 relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-0 right-0 p-6 opacity-10">
            <Scale className="w-32 h-32" />
          </div>
          <div>
            <div className="flex items-center justify-between text-slate-300 mb-2">
              <span className="text-xs uppercase font-bold tracking-wider">FTA Return Box 12</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-400/20 text-cyan-300 font-mono">
                Net Tax Position
              </span>
            </div>
            <h4 className="text-sm font-medium text-slate-200">
              Net VAT = Output VAT - Input VAT
            </h4>
            <div className="text-3xl font-extrabold tracking-tight font-mono mt-1 text-cyan-300">
              {formatAED(metrics.netVAT)}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-300">
            <span>Output: {formatShortAED(metrics.totalVATOnActualRent)}</span>
            <span>Input: {formatShortAED(metrics.totalVATOnPurchaseInvoice)}</span>
          </div>
        </div>
      </div>

      {/* Interactive Monthly Trends Graph */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Monthly Contract Amount vs Actual Annual Amount Trends
            </h3>
            <p className="text-xs text-slate-500">
              Comparison of scheduled contract renewals, baseline rents, and collection activity for 2026.
            </p>
          </div>

          {/* Metric Selector Buttons */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl">
            <button
              onClick={() => setActiveTrendMetric('both')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTrendMetric === 'both' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Both Series
            </button>
            <button
              onClick={() => setActiveTrendMetric('contract')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTrendMetric === 'contract' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Contract Amount
            </button>
            <button
              onClick={() => setActiveTrendMetric('actual')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTrendMetric === 'actual' ? 'bg-white text-emerald-600 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Actual Annual
            </button>
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-6 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-blue-600" />
            <span>Contract Amount (AED)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-500" />
            <span>Actual Annual Amount (AED)</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-indigo-400" />
            <span>Receipts Collected (AED)</span>
          </div>
        </div>

        {/* Interactive SVG Bar & Line Chart */}
        <div className="h-64 w-full relative">
          <div className="absolute inset-0 flex items-end justify-between gap-2 pt-6 pb-8 px-2 border-b border-slate-200">
            {metrics.monthlyTrends.map((trend, idx) => {
              const contractHeight = (trend.contractAmount / maxTrendVal) * 100;
              const actualHeight = (trend.actualAnnualAmount / maxTrendVal) * 100;
              const receiptHeight = (trend.receipts / maxTrendVal) * 100;
              const isHovered = hoveredMonth === idx;

              return (
                <div
                  key={trend.month}
                  className="flex-1 flex flex-col items-center h-full justify-end relative group cursor-pointer"
                  onMouseEnter={() => setHoveredMonth(idx)}
                  onMouseLeave={() => setHoveredMonth(null)}
                >
                  {/* Tooltip on hover */}
                  {isHovered && (
                    <div className="absolute bottom-full mb-2 z-30 bg-slate-900 text-white rounded-xl p-2.5 text-[11px] shadow-xl pointer-events-none min-w-[160px] animate-fade-in">
                      <div className="font-bold border-b border-slate-700 pb-1 mb-1 text-cyan-300">
                        {trend.month} 2026
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span>Contract:</span>
                        <span className="font-mono font-semibold text-white">{formatShortAED(trend.contractAmount)}</span>
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span>Actual Rent:</span>
                        <span className="font-mono font-semibold text-emerald-400">{formatShortAED(trend.actualAnnualAmount)}</span>
                      </div>
                      <div className="flex justify-between text-slate-300">
                        <span>Receipts:</span>
                        <span className="font-mono font-semibold text-indigo-300">{formatShortAED(trend.receipts)}</span>
                      </div>
                    </div>
                  )}

                  {/* Bars Container */}
                  <div className="w-full flex items-end justify-center gap-1 h-full">
                    {/* Contract Amount Bar */}
                    {(activeTrendMetric === 'both' || activeTrendMetric === 'contract') && (
                      <div
                        style={{ height: `${Math.max(contractHeight, 4)}%` }}
                        className={`w-3.5 sm:w-5 rounded-t-md transition-all duration-300 ${
                          trend.contractAmount > 0
                            ? 'bg-blue-600 hover:bg-blue-700'
                            : 'bg-slate-100'
                        }`}
                      />
                    )}

                    {/* Actual Annual Amount Bar */}
                    {(activeTrendMetric === 'both' || activeTrendMetric === 'actual') && (
                      <div
                        style={{ height: `${Math.max(actualHeight, 4)}%` }}
                        className={`w-3.5 sm:w-5 rounded-t-md transition-all duration-300 ${
                          trend.actualAnnualAmount > 0
                            ? 'bg-emerald-500 hover:bg-emerald-600'
                            : 'bg-slate-100'
                        }`}
                      />
                    )}
                  </div>

                  {/* Month Label */}
                  <span className="absolute -bottom-6 text-[11px] font-medium text-slate-500 group-hover:text-blue-600 group-hover:font-bold">
                    {trend.month}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Quick Jump Modules */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div
          onClick={() => onNavigate('contracts')}
          className="bg-white rounded-2xl p-4 border border-slate-200/80 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">Tenancy Contracts</span>
            <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
          </div>
          <div className="mt-2 text-xl font-bold text-slate-900 font-mono">
            {filteredContracts.length}
          </div>
          <span className="text-[11px] text-slate-400">Ejari registry records</span>
        </div>

        <div
          onClick={() => onNavigate('receipts')}
          className="bg-white rounded-2xl p-4 border border-slate-200/80 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">Cheque Receipts</span>
            <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
          </div>
          <div className="mt-2 text-xl font-bold text-slate-900 font-mono">
            {filteredReceipts.length}
          </div>
          <span className="text-[11px] text-slate-400">Installments recorded</span>
        </div>

        <div
          onClick={() => onNavigate('invoices')}
          className="bg-white rounded-2xl p-4 border border-slate-200/80 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">Tax Invoices</span>
            <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
          </div>
          <div className="mt-2 text-xl font-bold text-slate-900 font-mono">
            {filteredInvoices.length}
          </div>
          <span className="text-[11px] text-slate-400">5% UAE VAT maintenance</span>
        </div>

        <div
          onClick={() => onNavigate('reconciliation')}
          className="bg-white rounded-2xl p-4 border border-slate-200/80 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-700">Bank Reconciliation</span>
            <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" />
          </div>
          <div className="mt-2 text-xl font-bold text-slate-900 font-mono">
            {filteredStatements.length}
          </div>
          <span className="text-[11px] text-slate-400">BRS statement items</span>
        </div>
      </div>
    </div>
  );
};
