import React, { useRef, useState, useEffect } from 'react';
import {
  Camera,
  RotateCcw,
  Check,
  X,
  FlipHorizontal,
  AlertCircle,
  Sparkles,
  Zap,
} from 'lucide-react';

interface CameraCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (file: File) => void;
}

export const CameraCaptureModal: React.FC<CameraCaptureModalProps> = ({
  isOpen,
  onClose,
  onCapture,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileFallbackRef = useRef<HTMLInputElement>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [isShutterActive, setIsShutterActive] = useState(false);

  // Initialize Camera
  const startCamera = async (mode: 'environment' | 'user') => {
    setCameraError(null);
    try {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }

      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: mode,
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });

      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.warn('Camera access error:', err);
      setCameraError(
        err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'
          ? 'Camera permission was denied. Please allow camera access in your browser settings or use device capture.'
          : 'Could not connect to camera device. You can still use the direct camera upload fallback below.'
      );
    }
  };

  useEffect(() => {
    if (isOpen) {
      setCapturedImage(null);
      startCamera(facingMode);
    } else {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
        setStream(null);
      }
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [isOpen, facingMode]);

  if (!isOpen) return null;

  const handleCapture = () => {
    if (!videoRef.current || !canvasRef.current) return;
    setIsShutterActive(true);
    setTimeout(() => setIsShutterActive(false), 200);

    const video = videoRef.current;
    const canvas = canvasRef.current;

    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    setCapturedImage(dataUrl);

    // Stop active camera stream while previewing
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      setStream(null);
    }
  };

  const handleRetake = () => {
    setCapturedImage(null);
    startCamera(facingMode);
  };

  const handleConfirm = () => {
    if (!capturedImage) return;

    // Convert data URL to File
    const byteString = atob(capturedImage.split(',')[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    const blob = new Blob([ab], { type: 'image/jpeg' });
    const filename = `Camera_Captured_Invoice_${Date.now()}.jpg`;
    const file = new File([blob], filename, { type: 'image/jpeg' });

    onCapture(file);
    onClose();
  };

  const toggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Fallback for native mobile camera input
  const handleFallbackFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onCapture(e.target.files[0]);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-800 flex flex-col relative animate-in zoom-in-95 duration-200">
        {/* Top Header */}
        <div className="p-4 px-6 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-blue-600/30 text-blue-400 flex items-center justify-center border border-blue-500/30">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight">
                Live Document & Invoice Camera Scanner
              </h3>
              <p className="text-[11px] text-slate-400">
                Position your UAE invoice, receipt, or tenancy contract flat within the frame
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder Viewport */}
        <div className="relative bg-black min-h-[360px] sm:min-h-[440px] flex items-center justify-center overflow-hidden">
          {capturedImage ? (
            /* Captured photo preview */
            <div className="relative w-full h-full flex items-center justify-center">
              <img
                src={capturedImage}
                alt="Captured Document"
                className="max-h-[460px] w-auto object-contain rounded-xl"
              />
              <div className="absolute top-4 left-4 bg-emerald-500/90 text-white text-[11px] font-bold px-3 py-1 rounded-full backdrop-blur-xs flex items-center gap-1.5 shadow-md">
                <Check className="w-3.5 h-3.5" />
                Document Photo Captured
              </div>
            </div>
          ) : cameraError ? (
            /* Error & fallback state */
            <div className="p-8 text-center max-w-md mx-auto space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center mx-auto border border-rose-500/30">
                <AlertCircle className="w-7 h-7" />
              </div>
              <h4 className="text-base font-bold text-white">Camera Access Notice</h4>
              <p className="text-xs text-slate-400 leading-relaxed">{cameraError}</p>

              <div className="pt-2">
                <input
                  ref={fileFallbackRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  className="hidden"
                  onChange={handleFallbackFile}
                />
                <button
                  onClick={() => fileFallbackRef.current?.click()}
                  className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition shadow-sm flex items-center justify-center gap-2 mx-auto"
                >
                  <Camera className="w-4 h-4" />
                  Capture Photo Using Device Camera
                </button>
              </div>
            </div>
          ) : (
            /* Live Camera Stream with UAE Document Alignment Guide */
            <div className="relative w-full h-full flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover max-h-[460px]"
              />

              {/* Shutter flash overlay */}
              {isShutterActive && (
                <div className="absolute inset-0 bg-white z-30 opacity-75 animate-out fade-out duration-150" />
              )}

              {/* Document Alignment Frame */}
              <div className="absolute inset-8 sm:inset-12 border-2 border-dashed border-blue-400/70 rounded-2xl pointer-events-none flex flex-col justify-between p-4 shadow-[0_0_0_9999px_rgba(0,0,0,0.35)]">
                <div className="flex justify-between items-start">
                  <div className="w-6 h-6 border-t-2 border-l-2 border-blue-400 -mt-4 -ml-4 rounded-tl-lg" />
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-200 bg-slate-900/80 px-2.5 py-0.5 rounded-full border border-blue-400/40 backdrop-blur-xs">
                    Ejari / Tax Invoice Alignment Zone
                  </span>
                  <div className="w-6 h-6 border-t-2 border-r-2 border-blue-400 -mt-4 -mr-4 rounded-tr-lg" />
                </div>
                <div className="flex justify-between items-end">
                  <div className="w-6 h-6 border-b-2 border-l-2 border-blue-400 -mb-4 -ml-4 rounded-bl-lg" />
                  <span className="text-[10px] text-slate-300 bg-slate-900/80 px-2 py-0.5 rounded-full backdrop-blur-xs">
                    Hold steady with clear lighting
                  </span>
                  <div className="w-6 h-6 border-b-2 border-r-2 border-blue-400 -mb-4 -mr-4 rounded-br-lg" />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Hidden Canvas for Frame Capture */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Bottom Control Bar */}
        <div className="p-4 px-6 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          {!capturedImage ? (
            <>
              {/* Flip camera */}
              <button
                type="button"
                onClick={toggleFacingMode}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition"
              >
                <FlipHorizontal className="w-4 h-4" />
                <span className="hidden sm:inline">Flip Camera</span>
              </button>

              {/* Shutter Button (Apple styled) */}
              <div className="flex justify-center flex-1">
                <button
                  type="button"
                  onClick={handleCapture}
                  disabled={!!cameraError}
                  className="w-16 h-16 rounded-full border-4 border-white/80 p-1 flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-xl disabled:opacity-30 disabled:pointer-events-none group"
                >
                  <div className="w-full h-full rounded-full bg-white group-hover:bg-blue-400 transition-colors" />
                </button>
              </div>

              {/* Cancel */}
              <button
                type="button"
                onClick={onClose}
                className="px-3.5 py-2 text-xs font-semibold text-slate-400 hover:text-white transition"
              >
                Cancel
              </button>
            </>
          ) : (
            <>
              {/* Retake */}
              <button
                type="button"
                onClick={handleRetake}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Retake Photo
              </button>

              {/* Confirm & Process */}
              <button
                type="button"
                onClick={handleConfirm}
                className="flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition shadow-lg shadow-emerald-600/30"
              >
                <Sparkles className="w-4 h-4" />
                Process Captured Document
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
