import React, { useState, useEffect } from 'react';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  Users,
  Key,
  CheckCircle2,
  Lock,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { UserProfile, UserRole } from '../types';
import { getAllUserProfiles, updateUserRole } from '../services/dbService';
import { useAuth } from '../context/AuthContext';

export const RolesManagement: React.FC = () => {
  const { user, profile, isAdmin, activeRole, setActiveRoleOverride } = useAuth();
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      const list = await getAllUserProfiles();
      setUsersList(list);
    } catch (err) {
      console.error('Error fetching users:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleRoleChange = async (targetUserId: string, newRole: UserRole) => {
    try {
      await updateUserRole(targetUserId, newRole);
      setUsersList((prev) =>
        prev.map((u) => (u.userId === targetUserId ? { ...u, role: newRole } : u))
      );
      setActionMessage(`Updated role to ${newRole.toUpperCase()} successfully.`);
      setTimeout(() => setActionMessage(null), 3000);
    } catch (err: any) {
      alert(`Failed to update role: ${err.message}`);
    }
  };

  const rolesDescription = [
    {
      role: 'admin',
      label: 'Super Admin',
      desc: 'Complete system control. Manage organization members, roles, system parameters, data mutations, and exports.',
      badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
    },
    {
      role: 'manager',
      label: 'Property Manager',
      desc: 'Upload UAE tenancy contracts and invoices, inline edit contract parameters, and generate property summaries.',
      badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
    },
    {
      role: 'accountant',
      label: 'Financial Accountant',
      desc: 'Review 5% VAT calculations, audit supplier TRNs, manage rental payment receipts, and export to Zoho Books & Tally Prime.',
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    },
    {
      role: 'viewer',
      label: 'Auditor / Viewer',
      desc: 'Read-only access to executive dashboard, charts, and summaries. Cannot edit records or modify configurations.',
      badgeColor: 'bg-slate-100 text-slate-700 border-slate-200',
    },
  ];

  return (
    <div className="space-y-7 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-200/80">
        <div>
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200/60">
            Enterprise Governance & Security
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
            Role-Based Access Control (RBAC)
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Manage team access levels, permissions, and security roles across property managers, accountants, and administrators.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchUsers}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition shadow-xs"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh Directory
          </button>
        </div>
      </div>

      {actionMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs rounded-xl font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Role Switcher / Simulator for testing */}
      <div className="bg-gradient-to-r from-blue-900 to-indigo-950 text-white rounded-3xl p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-blue-800">
          <div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-blue-300" />
              <h3 className="text-base font-bold text-white">Current Active Session: {profile?.displayName || user?.email}</h3>
            </div>
            <p className="text-xs text-blue-200 mt-1">
              Database Role: <span className="font-bold text-white uppercase">{profile?.role || 'viewer'}</span>
              {' • '}Effective Session Role: <span className="font-bold text-emerald-300 uppercase">{activeRole}</span>
            </p>
          </div>

          <div className="flex items-center gap-2 bg-blue-950/70 p-1.5 rounded-2xl border border-blue-700/60 text-xs">
            <span className="text-[11px] text-blue-300 px-2 font-medium">Role Switcher:</span>
            {(['admin', 'manager', 'accountant', 'viewer'] as UserRole[]).map((r) => (
              <button
                key={r}
                onClick={() => setActiveRoleOverride(r)}
                className={`px-3 py-1.5 rounded-xl font-semibold capitalize transition ${
                  activeRole === r
                    ? 'bg-blue-500 text-white shadow-xs'
                    : 'text-blue-200 hover:text-white hover:bg-blue-800/50'
                }`}
              >
                {r}
              </button>
            ))}
            <button
              onClick={() => setActiveRoleOverride(null)}
              className="px-2 py-1.5 text-[11px] text-blue-300 hover:text-white transition"
              title="Reset to database profile role"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Permissions Grid */}
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 bg-blue-950/40 rounded-xl border border-blue-800/50">
            <div className="text-[11px] text-blue-300">Document Upload & OCR</div>
            <div className="text-sm font-bold text-white mt-1">
              {['admin', 'manager'].includes(activeRole) ? '✓ Authorized' : '✗ Restricted'}
            </div>
          </div>
          <div className="p-3 bg-blue-950/40 rounded-xl border border-blue-800/50">
            <div className="text-[11px] text-blue-300">Inline Record Editing</div>
            <div className="text-sm font-bold text-white mt-1">
              {['admin', 'manager', 'accountant'].includes(activeRole) ? '✓ Authorized' : '✗ Restricted'}
            </div>
          </div>
          <div className="p-3 bg-blue-950/40 rounded-xl border border-blue-800/50">
            <div className="text-[11px] text-blue-300">Zoho / Tally Export</div>
            <div className="text-sm font-bold text-white mt-1">
              {['admin', 'manager', 'accountant'].includes(activeRole) ? '✓ Authorized' : '✗ Restricted'}
            </div>
          </div>
          <div className="p-3 bg-blue-950/40 rounded-xl border border-blue-800/50">
            <div className="text-[11px] text-blue-300">Role & User Administration</div>
            <div className="text-sm font-bold text-white mt-1">
              {activeRole === 'admin' ? '✓ Authorized' : '✗ Restricted'}
            </div>
          </div>
        </div>
      </div>

      {/* Role Descriptions Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {rolesDescription.map((item) => (
          <div
            key={item.role}
            className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-2">
                <span
                  className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase border ${item.badgeColor}`}
                >
                  {item.label}
                </span>
                <Key className="w-3.5 h-3.5 text-slate-400" />
              </div>
              <p className="text-xs text-slate-600 leading-relaxed mt-2">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Users Directory Table */}
      <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-600" />
            <h3 className="text-sm font-bold text-slate-900">User Directory & Role Assignments</h3>
          </div>
          <span className="text-xs text-slate-400">{usersList.length} registered team members</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-slate-50/90 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-5">User</th>
                <th className="py-3 px-5">Email Address</th>
                <th className="py-3 px-5">Assigned Role</th>
                <th className="py-3 px-5">Member Since</th>
                <th className="py-3 px-5 text-center">Manage Permissions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {usersList.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-10 text-center text-slate-400">
                    No users loaded yet.
                  </td>
                </tr>
              ) : (
                usersList.map((u) => {
                  const isCurrent = u.userId === user?.uid;
                  const isMaster = u.email?.toLowerCase() === 'velayudham.e@gmail.com';

                  return (
                    <tr key={u.userId} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-5">
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
                            {u.displayName?.slice(0, 2).toUpperCase() || 'U'}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900">
                              {u.displayName || 'Team Member'}
                              {isCurrent && (
                                <span className="ml-1.5 text-[10px] bg-blue-50 text-blue-600 font-bold px-1.5 py-0.5 rounded">
                                  You
                                </span>
                              )}
                              {isMaster && (
                                <span className="ml-1.5 text-[10px] bg-purple-50 text-purple-700 font-bold px-1.5 py-0.5 rounded border border-purple-200">
                                  Root Admin
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono">UID: {u.userId.slice(0, 10)}...</div>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-5 font-medium text-slate-700">{u.email}</td>

                      <td className="py-3 px-5">
                        <span
                          className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold uppercase ${
                            u.role === 'admin'
                              ? 'bg-purple-50 text-purple-700 border border-purple-200'
                              : u.role === 'manager'
                              ? 'bg-blue-50 text-blue-700 border border-blue-200'
                              : u.role === 'accountant'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-slate-100 text-slate-700 border border-slate-200'
                          }`}
                        >
                          {u.role}
                        </span>
                      </td>

                      <td className="py-3 px-5 text-slate-500">
                        {u.createdAt ? new Date(u.createdAt).toLocaleDateString() : 'Active'}
                      </td>

                      <td className="py-3 px-5 text-center">
                        {isAdmin && !isMaster ? (
                          <select
                            value={u.role}
                            onChange={(e) => handleRoleChange(u.userId, e.target.value as UserRole)}
                            className="p-1.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold text-slate-700 hover:bg-white focus:outline-hidden"
                          >
                            <option value="admin">Super Admin</option>
                            <option value="manager">Property Manager</option>
                            <option value="accountant">Financial Accountant</option>
                            <option value="viewer">Viewer (Read-Only)</option>
                          </select>
                        ) : (
                          <span className="text-slate-400 text-[11px] italic">
                            {isMaster ? 'Root Protected' : 'Requires Admin Rights'}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
