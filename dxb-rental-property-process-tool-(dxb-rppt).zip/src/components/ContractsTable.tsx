import React, { useState } from 'react';
import {
  Building2,
  Search,
  Filter,
  Download,
  Edit2,
  Trash2,
  Plus,
  Save,
  X,
  FileSpreadsheet,
  CheckCircle,
  Eye,
  Calendar,
  Layers,
  AlertTriangle,
  Percent,
} from 'lucide-react';
import { TenancyContract } from '../types';
import { formatAED, exportToExcel, exportToCSV } from '../utils/exportUtils';
import { updateContract, deleteContract, saveContract } from '../services/dbService';
import { useAuth } from '../context/AuthContext';
import { isCommercialContract, calculateContractVat } from '../utils/vatCalculator';

interface ContractsTableProps {
  contracts: TenancyContract[];
  onRefresh?: () => void;
}

export const ContractsTable: React.FC<ContractsTableProps> = ({ contracts }) => {
  const { user, canEdit } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [propertyTypeFilter, setPropertyTypeFilter] = useState('all');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<TenancyContract>>({});
  const [selectedContract, setSelectedContract] = useState<TenancyContract | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newContractData, setNewContractData] = useState<Partial<TenancyContract>>({
    contractType: 'Residence',
    propertyType: 'Residential',
    subType: 'Apartment',
    contractAmount: 0,
    actualAnnualAmount: 0,
    securityDeposit: 0,
    startDate: new Date().toISOString().slice(0, 10),
    endDate: new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10),
    registrationDate: new Date().toISOString().slice(0, 10),
  });

  const duplicateUnitMatch = newContractData.propertyNo?.trim()
    ? contracts.find(
        (c) =>
          c.propertyNo?.trim().toLowerCase() ===
            newContractData.propertyNo?.trim().toLowerCase() &&
          (!newContractData.buildingName ||
            !c.buildingName ||
            c.buildingName.trim().toLowerCase() ===
              newContractData.buildingName.trim().toLowerCase())
      )
    : null;

  const filteredContracts = contracts.filter((c) => {
    const matchesSearch =
      (c.tenantName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.buildingName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.ownerName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.contractNo || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (c.propertyNo || '').toLowerCase().includes(searchTerm.toLowerCase());

    const isComm = isCommercialContract(c.contractType || c.propertyType);
    let matchesType = true;
    if (propertyTypeFilter === 'all') {
      matchesType = true;
    } else if (propertyTypeFilter === 'commercial') {
      matchesType = isComm;
    } else if (propertyTypeFilter === 'residence' || propertyTypeFilter === 'residential') {
      matchesType = !isComm;
    } else if (propertyTypeFilter === 'industrial') {
      matchesType = (c.propertyType || '').toLowerCase().includes('industrial');
    }

    return matchesSearch && matchesType;
  });

  // Batch Summary Calculations & UAE VAT Analysis
  const totalContractAmount = filteredContracts.reduce((acc, c) => acc + (c.contractAmount || 0), 0);
  const totalActualAnnual = filteredContracts.reduce((acc, c) => acc + (c.actualAnnualAmount || 0), 0);
  const totalSecurityDeposit = filteredContracts.reduce((acc, c) => acc + (c.securityDeposit || 0), 0);
  const avgRent = filteredContracts.length > 0 ? totalContractAmount / filteredContracts.length : 0;

  let commercialCount = 0;
  let residenceCount = 0;
  let commercialAnnualRent = 0;
  let residenceAnnualRent = 0;
  let totalVatOnAnnualRent = 0;

  filteredContracts.forEach((c) => {
    const isComm = isCommercialContract(c.contractType || c.propertyType);
    const rent = c.actualAnnualAmount || c.contractAmount || 0;
    if (isComm) {
      commercialCount++;
      commercialAnnualRent += rent;
      const vat = c.vatAmount != null ? c.vatAmount : Math.round(rent * 0.05 * 100) / 100;
      totalVatOnAnnualRent += vat;
    } else {
      residenceCount++;
      residenceAnnualRent += rent;
    }
  });
  totalVatOnAnnualRent = Math.round(totalVatOnAnnualRent * 100) / 100;

  const startEdit = (contract: TenancyContract) => {
    setEditingId(contract.id);
    const isComm = isCommercialContract(contract.contractType || contract.propertyType);
    setEditFormData({
      ...contract,
      contractType: contract.contractType || (isComm ? 'Commercial' : 'Residence'),
    });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditFormData({});
  };

  const saveEdit = async (id: string) => {
    try {
      const rent = Number(editFormData.actualAnnualAmount) || Number(editFormData.contractAmount) || 0;
      const vatInfo = calculateContractVat(editFormData.contractType || editFormData.propertyType, rent);
      await updateContract(id, {
        ...editFormData,
        contractType: vatInfo.contractType,
        vatRate: vatInfo.vatRate,
        vatAmount: vatInfo.vatAmount,
        totalAmountWithVat: vatInfo.totalAmountWithVat,
      });
      setEditingId(null);
    } catch (err: any) {
      alert(`Error updating contract: ${err.message}`);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this tenancy contract?')) {
      try {
        await deleteContract(id);
      } catch (err: any) {
        alert(`Error deleting contract: ${err.message}`);
      }
    }
  };

  const handleCreateNew = async () => {
    if (!user) return;
    if (!newContractData.tenantName || !newContractData.buildingName) {
      alert('Please fill in at least the Tenant Name and Building Name.');
      return;
    }

    try {
      const now = new Date().toISOString();
      const annualRent = Number(newContractData.actualAnnualAmount) || Number(newContractData.contractAmount) || 0;
      const vatInfo = calculateContractVat(newContractData.contractType || newContractData.propertyType, annualRent);

      const contractDoc: TenancyContract = {
        id: `CNT-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        userId: user.uid,
        contractNo: newContractData.contractNo || `EJARI-${Date.now().toString().slice(-6)}`,
        ownerName: newContractData.ownerName || 'Property Owner',
        lessorName: newContractData.lessorName || '',
        tenantName: newContractData.tenantName || '',
        buildingName: newContractData.buildingName || '',
        propertyNo: newContractData.propertyNo || '',
        contractType: vatInfo.contractType,
        propertyType: newContractData.propertyType || (vatInfo.contractType === 'Commercial' ? 'Commercial' : 'Residential'),
        subType: newContractData.subType || (vatInfo.contractType === 'Commercial' ? 'Office' : 'Apartment'),
        size: newContractData.size || '1,000 Sq.Ft',
        contractAmount: Number(newContractData.contractAmount) || 0,
        actualAnnualAmount: annualRent,
        vatRate: vatInfo.vatRate,
        vatAmount: vatInfo.vatAmount,
        totalAmountWithVat: vatInfo.totalAmountWithVat,
        securityDeposit: Number(newContractData.securityDeposit) || 0,
        startDate: newContractData.startDate || now.slice(0, 10),
        endDate: newContractData.endDate || now.slice(0, 10),
        registrationDate: newContractData.registrationDate || now.slice(0, 10),
        createdAt: now,
        updatedAt: now,
      };
      await saveContract(contractDoc);
      setIsAddingNew(false);
      setNewContractData({
        contractType: 'Residence',
        propertyType: 'Residential',
        subType: 'Apartment',
        contractAmount: 0,
        actualAnnualAmount: 0,
        securityDeposit: 0,
      });
    } catch (err: any) {
      alert(`Error creating contract: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-200/80">
        <div>
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200/60">
            UAE Ejari Unified Records
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
            Tenancy Contracts Directory & Summary
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Full on-screen editable table containing all Ejari parameters, landlord, tenant, rent amounts, and lease timelines.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {canEdit && (
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Tenancy Contract
            </button>
          )}
          <button
            onClick={() => exportToCSV(filteredContracts, 'UAE_Tenancy_Contracts')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            CSV
          </button>
          <button
            onClick={() => exportToExcel(contracts, [], [], 'consolidated')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            Excel
          </button>
        </div>
      </div>

      {/* Tenancy Batch Summary Card */}
      <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-indigo-900 text-white rounded-2xl p-5 shadow-xs">
        <div className="flex flex-wrap items-center justify-between pb-3 border-b border-blue-700/60 mb-3 gap-2">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-blue-200">
              Batch Tenancy & VAT Summary ({filteredContracts.length} Contracts Filtered)
            </span>
            <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full">
              Commercial: 5% VAT • Residence: 0% VAT
            </span>
          </div>
          <span className="text-xs font-mono text-blue-300">UAE Dirhams (AED)</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          <div>
            <div className="text-[11px] text-blue-200">Total Agreed Contract</div>
            <div className="text-base sm:text-lg font-bold text-white mt-0.5">
              {formatAED(totalContractAmount)}
            </div>
            <div className="text-[10px] text-blue-300/80 mt-0.5">{filteredContracts.length} Units Total</div>
          </div>
          <div>
            <div className="text-[11px] text-blue-200">Total Actual Annual Rent</div>
            <div className="text-base sm:text-lg font-bold text-emerald-300 mt-0.5">
              {formatAED(totalActualAnnual)}
            </div>
            <div className="text-[10px] text-emerald-200/80 mt-0.5">Annual Run-Rate</div>
          </div>
          <div>
            <div className="text-[11px] text-purple-200 font-semibold">Total VAT on Annual Rent</div>
            <div className="text-base sm:text-lg font-bold text-purple-200 mt-0.5">
              {formatAED(totalVatOnAnnualRent)}
            </div>
            <div className="text-[10px] text-purple-300 mt-0.5">5% Commercial Output VAT</div>
          </div>
          <div>
            <div className="text-[11px] text-blue-200">Contract Types Breakdown</div>
            <div className="text-xs font-bold text-white mt-1">
              <span className="text-purple-300 font-semibold">{commercialCount} Comm.</span> • <span className="text-slate-300">{residenceCount} Res.</span>
            </div>
            <div className="text-[10px] text-blue-300/80 mt-0.5">
              Comm Rent: {formatAED(commercialAnnualRent)}
            </div>
          </div>
          <div>
            <div className="text-[11px] text-blue-200">Security Deposits</div>
            <div className="text-base sm:text-lg font-bold text-amber-300 mt-0.5">
              {formatAED(totalSecurityDeposit)}
            </div>
            <div className="text-[10px] text-amber-200/80 mt-0.5">Avg: {formatAED(avgRent)}/unit</div>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search tenant, building, owner, unit, ejari..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:border-blue-500 transition"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs text-slate-500 flex items-center gap-1 font-medium">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            Contract Type:
          </span>
          <select
            value={propertyTypeFilter}
            onChange={(e) => setPropertyTypeFilter(e.target.value)}
            className="text-xs p-1.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 font-semibold"
          >
            <option value="all">All Contracts ({contracts.length})</option>
            <option value="commercial">Commercial (5% VAT on Actual Annual Rent)</option>
            <option value="residence">Residence (0% VAT Exempt)</option>
            <option value="industrial">Industrial</option>
          </select>
        </div>
      </div>

      {/* Editable Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-slate-50/90 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-3">Contract / Ejari #</th>
                <th className="py-3 px-3">Tenant Name</th>
                <th className="py-3 px-3">Building & Unit</th>
                <th className="py-3 px-3">Type & UAE VAT</th>
                <th className="py-3 px-3 text-right">Contract Amt (AED)</th>
                <th className="py-3 px-3 text-right">Actual Annual Rent (AED)</th>
                <th className="py-3 px-3 text-right">VAT on Rent (AED)</th>
                <th className="py-3 px-3 text-right">Total with VAT (AED)</th>
                <th className="py-3 px-3 text-right">Security Deposit (AED)</th>
                <th className="py-3 px-3">Lease Period</th>
                <th className="py-3 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredContracts.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center text-slate-400">
                    No tenancy contracts found. Upload contracts via the Upload tab or click "Add Tenancy Contract".
                  </td>
                </tr>
              ) : (
                filteredContracts.map((c) => {
                  const isEditing = editingId === c.id;
                  const isComm = isCommercialContract(c.contractType || c.propertyType);
                  const annualRent = c.actualAnnualAmount || c.contractAmount || 0;
                  const vatAmount = isComm
                    ? (c.vatAmount != null ? c.vatAmount : Math.round(annualRent * 0.05 * 100) / 100)
                    : 0;
                  const totalWithVat = Math.round((annualRent + vatAmount) * 100) / 100;

                  if (isEditing) {
                    const editIsComm = isCommercialContract(editFormData.contractType || editFormData.propertyType);
                    const editAnnualRent = Number(editFormData.actualAnnualAmount) || Number(editFormData.contractAmount) || 0;
                    const editVat = editIsComm ? Math.round(editAnnualRent * 0.05 * 100) / 100 : 0;
                    const editTotalWithVat = Math.round((editAnnualRent + editVat) * 100) / 100;

                    return (
                      <tr key={c.id} className="bg-blue-50/50">
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.contractNo || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, contractNo: e.target.value })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs font-mono"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.tenantName || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, tenantName: e.target.value })
                            }
                            className="w-28 p-1 border rounded bg-white text-xs font-semibold"
                          />
                        </td>
                        <td className="p-2">
                          <div className="flex gap-1">
                            <input
                              type="text"
                              placeholder="Building"
                              value={editFormData.buildingName || ''}
                              onChange={(e) =>
                                setEditFormData({ ...editFormData, buildingName: e.target.value })
                              }
                              className="w-24 p-1 border rounded bg-white text-xs"
                            />
                            <input
                              type="text"
                              placeholder="Unit"
                              value={editFormData.propertyNo || ''}
                              onChange={(e) =>
                                setEditFormData({ ...editFormData, propertyNo: e.target.value })
                              }
                              className="w-16 p-1 border rounded bg-white text-xs"
                            />
                          </div>
                        </td>
                        <td className="p-2">
                          <select
                            value={editFormData.contractType || (editIsComm ? 'Commercial' : 'Residence')}
                            onChange={(e) => {
                              const val = e.target.value as 'Commercial' | 'Residence';
                              setEditFormData({
                                ...editFormData,
                                contractType: val,
                                propertyType: val === 'Commercial' ? 'Commercial' : 'Residential',
                              });
                            }}
                            className="p-1 border rounded bg-white text-xs font-bold text-slate-800"
                          >
                            <option value="Commercial">Commercial (5% VAT)</option>
                            <option value="Residence">Residence (0% VAT)</option>
                          </select>
                        </td>
                        <td className="p-2 text-right">
                          <input
                            type="number"
                            value={editFormData.contractAmount || 0}
                            onChange={(e) =>
                              setEditFormData({
                                ...editFormData,
                                contractAmount: Number(e.target.value),
                              })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs text-right font-medium"
                          />
                        </td>
                        <td className="p-2 text-right">
                          <input
                            type="number"
                            value={editFormData.actualAnnualAmount || 0}
                            onChange={(e) =>
                              setEditFormData({
                                ...editFormData,
                                actualAnnualAmount: Number(e.target.value),
                              })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs text-right font-bold text-emerald-800"
                          />
                        </td>
                        <td className="p-2 text-right font-bold text-xs text-purple-700">
                          {editIsComm ? `+${formatAED(editVat)}` : '0.00 (Exempt)'}
                        </td>
                        <td className="p-2 text-right font-bold text-xs text-slate-900">
                          {formatAED(editTotalWithVat)}
                        </td>
                        <td className="p-2 text-right">
                          <input
                            type="number"
                            value={editFormData.securityDeposit || 0}
                            onChange={(e) =>
                              setEditFormData({
                                ...editFormData,
                                securityDeposit: Number(e.target.value),
                              })
                            }
                            className="w-20 p-1 border rounded bg-white text-xs text-right"
                          />
                        </td>
                        <td className="p-2">
                          <div className="flex flex-col gap-0.5">
                            <input
                              type="date"
                              value={editFormData.startDate || ''}
                              onChange={(e) =>
                                setEditFormData({ ...editFormData, startDate: e.target.value })
                              }
                              className="w-24 p-0.5 border rounded bg-white text-[10px]"
                            />
                            <input
                              type="date"
                              value={editFormData.endDate || ''}
                              onChange={(e) =>
                                setEditFormData({ ...editFormData, endDate: e.target.value })
                              }
                              className="w-24 p-0.5 border rounded bg-white text-[10px]"
                            />
                          </div>
                        </td>
                        <td className="p-2 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => saveEdit(c.id)}
                              className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                              title="Save"
                            >
                              <Save className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={cancelEdit}
                              className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                              title="Cancel"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={c.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-3 font-mono font-medium text-blue-700">
                        {c.contractNo || 'N/A'}
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-semibold text-slate-900">{c.tenantName}</div>
                        <div className="text-[10px] text-slate-400">
                          Owner: {c.ownerName || 'N/A'}
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <div className="font-medium text-slate-800">{c.buildingName}</div>
                        <div className="text-[10px] text-slate-500">
                          {c.propertyNo ? `Unit ${c.propertyNo}` : 'Unit -'} {c.size ? `• ${c.size}` : ''}
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                            isComm
                              ? 'bg-purple-50 text-purple-800 border-purple-200'
                              : 'bg-slate-50 text-slate-700 border-slate-200'
                          }`}
                        >
                          <span
                            className={`w-1.5 h-1.5 rounded-full ${
                              isComm ? 'bg-purple-600' : 'bg-slate-400'
                            }`}
                          />
                          {isComm ? 'Commercial (5% VAT)' : 'Residence (0% VAT)'}
                        </span>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          {c.propertyType} • {c.subType}
                        </div>
                      </td>
                      <td className="py-3 px-3 text-right font-medium text-slate-700">
                        {formatAED(c.contractAmount)}
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-slate-900">
                        {formatAED(c.actualAnnualAmount)}
                      </td>
                      <td className="py-3 px-3 text-right font-bold">
                        {isComm ? (
                          <span className="text-purple-700">+{formatAED(vatAmount)}</span>
                        ) : (
                          <span className="text-slate-400 text-[11px]">AED 0.00 (Exempt)</span>
                        )}
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-emerald-800">
                        {formatAED(totalWithVat)}
                      </td>
                      <td className="py-3 px-3 text-right text-slate-700 font-medium">
                        {formatAED(c.securityDeposit)}
                      </td>
                      <td className="py-3 px-3 text-slate-600 text-[11px]">
                        <div>{c.startDate}</div>
                        <div className="text-slate-400">to {c.endDate}</div>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => setSelectedContract(c)}
                            className="p-1 text-slate-400 hover:text-blue-600 rounded hover:bg-blue-50 transition"
                            title="View Individual Summary & VAT Status"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          {canEdit && (
                            <>
                              <button
                                onClick={() => startEdit(c)}
                                className="p-1 text-slate-400 hover:text-blue-600 rounded hover:bg-blue-50 transition"
                                title="Inline Edit"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDelete(c.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Individual Tenancy Contract Summary Drawer / Modal */}
      {selectedContract && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-600" />
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Tenancy Contract Individual Summary
                  </h3>
                  <p className="text-xs text-slate-500">
                    Ejari Certificate #{selectedContract.contractNo}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedContract(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              <div className="p-3 bg-blue-50/70 rounded-2xl border border-blue-100 grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-500">Contract Rent Value</span>
                  <div className="text-base font-bold text-blue-900 mt-0.5">
                    {formatAED(selectedContract.contractAmount)}
                  </div>
                </div>
                <div>
                  <span className="text-slate-500">Actual Annual Amount</span>
                  <div className="text-base font-bold text-emerald-700 mt-0.5">
                    {formatAED(selectedContract.actualAnnualAmount)}
                  </div>
                </div>
              </div>

              {/* UAE VAT Law Lease Status Card */}
              {(() => {
                const isComm = isCommercialContract(selectedContract.contractType || selectedContract.propertyType);
                const annualRent = selectedContract.actualAnnualAmount || selectedContract.contractAmount || 0;
                const vatAmount = isComm
                  ? (selectedContract.vatAmount != null ? selectedContract.vatAmount : Math.round(annualRent * 0.05 * 100) / 100)
                  : 0;
                const totalWithVat = Math.round((annualRent + vatAmount) * 100) / 100;

                return (
                  <div className="p-3.5 bg-gradient-to-br from-purple-50/90 to-white rounded-2xl border border-purple-200/90 space-y-2">
                    <div className="flex items-center justify-between pb-2 border-b border-purple-100">
                      <div className="flex items-center gap-1.5 font-bold text-purple-950">
                        <Percent className="w-4 h-4 text-purple-600" />
                        <span>UAE VAT Law Lease Classification</span>
                      </div>
                      <span
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                          isComm
                            ? 'bg-purple-100 text-purple-900 border-purple-300'
                            : 'bg-blue-50 text-blue-800 border-blue-200'
                        }`}
                      >
                        {isComm ? 'Commercial (5% Standard Rate)' : 'Residence (0% VAT Exempt)'}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-2 pt-1 text-center sm:text-left">
                      <div>
                        <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                          Actual Annual Rent
                        </span>
                        <div className="font-bold text-slate-900 text-sm mt-0.5">{formatAED(annualRent)}</div>
                      </div>
                      <div>
                        <span className="text-[10px] text-purple-700 uppercase tracking-wider font-semibold">
                          VAT on Rent (5%)
                        </span>
                        <div className="font-extrabold text-purple-700 text-sm mt-0.5">
                          {isComm ? `+${formatAED(vatAmount)}` : 'AED 0.00 (0%)'}
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] text-emerald-800 uppercase tracking-wider font-semibold">
                          Total with VAT
                        </span>
                        <div className="font-extrabold text-emerald-800 text-sm mt-0.5">
                          {formatAED(totalWithVat)}
                        </div>
                      </div>
                    </div>
                    <p className="text-[10px] text-slate-500 pt-1 border-t border-purple-100/70">
                      {isComm
                        ? 'Commercial lease subject to standard 5% VAT pursuant to UAE Federal Decree-Law No. (8) of 2017 on Value Added Tax.'
                        : 'Residential leases are exempt from VAT under Article 46 of UAE VAT Law (0% VAT applied).'}
                    </p>
                  </div>
                );
              })()}

              <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200/70">
                <div>
                  <span className="text-slate-400">Owner Name</span>
                  <div className="font-semibold text-slate-800">{selectedContract.ownerName || '-'}</div>
                </div>
                <div>
                  <span className="text-slate-400">Lessor / Management</span>
                  <div className="font-semibold text-slate-800">{selectedContract.lessorName || '-'}</div>
                </div>
                <div>
                  <span className="text-slate-400">Tenant Name</span>
                  <div className="font-semibold text-slate-900">{selectedContract.tenantName}</div>
                </div>
                <div>
                  <span className="text-slate-400">Security Deposit</span>
                  <div className="font-semibold text-slate-800">{formatAED(selectedContract.securityDeposit)}</div>
                </div>
                <div>
                  <span className="text-slate-400">Building & Property No</span>
                  <div className="font-semibold text-slate-800">
                    {selectedContract.buildingName} • Unit {selectedContract.propertyNo || '-'}
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">Property Type & Size</span>
                  <div className="font-semibold text-slate-800">
                    {selectedContract.propertyType} ({selectedContract.subType}) • {selectedContract.size || '-'}
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">Lease Period</span>
                  <div className="font-semibold text-slate-800">
                    {selectedContract.startDate} to {selectedContract.endDate}
                  </div>
                </div>
                <div>
                  <span className="text-slate-400">Registration Date</span>
                  <div className="font-semibold text-slate-800">{selectedContract.registrationDate || '-'}</div>
                </div>
              </div>

              {selectedContract.fileName && (
                <div className="text-[11px] text-slate-500">
                  Source File: <span className="font-mono">{selectedContract.fileName}</span>
                </div>
              )}
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setSelectedContract(null)}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition"
              >
                Close Summary
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Contract Modal */}
      {isAddingNew && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Add New UAE Tenancy Contract</h3>
              <button
                onClick={() => setIsAddingNew(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 text-xs">
              {/* UAE VAT Law Tenancy Contract Classification Toggle */}
              <div className="col-span-2">
                <label className="text-slate-700 font-bold block mb-1.5">
                  Tenancy Contract Classification (UAE VAT Law) *
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <button
                    type="button"
                    onClick={() =>
                      setNewContractData({
                        ...newContractData,
                        contractType: 'Commercial',
                        propertyType: 'Commercial',
                        subType: 'Office',
                      })
                    }
                    className={`p-3 rounded-2xl border text-left transition ${
                      newContractData.contractType === 'Commercial'
                        ? 'border-purple-600 bg-purple-50 text-purple-950 ring-2 ring-purple-400/40 shadow-xs'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-xs">
                      <span className="w-2.5 h-2.5 rounded-full bg-purple-600"></span>
                      Commercial Tenancy Contract
                    </div>
                    <div className="text-[11px] text-purple-700 font-semibold mt-1">
                      Standard 5% VAT on Actual Annual Rent
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      Offices, retail, shops, commercial warehouses
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      setNewContractData({
                        ...newContractData,
                        contractType: 'Residence',
                        propertyType: 'Residential',
                        subType: 'Apartment',
                      })
                    }
                    className={`p-3 rounded-2xl border text-left transition ${
                      newContractData.contractType === 'Residence'
                        ? 'border-blue-600 bg-blue-50 text-blue-950 ring-2 ring-blue-400/40 shadow-xs'
                        : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold text-xs">
                      <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
                      Residence Tenancy Contract
                    </div>
                    <div className="text-[11px] text-blue-700 font-semibold mt-1">
                      0% VAT (Exempt under UAE VAT Law)
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      Residential apartments, villas, townhouses
                    </div>
                  </button>
                </div>
              </div>

              {/* Live VAT Calculation Preview */}
              {(() => {
                const isComm = newContractData.contractType === 'Commercial';
                const rent = Number(newContractData.actualAnnualAmount) || Number(newContractData.contractAmount) || 0;
                const vat = isComm ? Math.round(rent * 0.05 * 100) / 100 : 0;
                const total = Math.round((rent + vat) * 100) / 100;

                return (
                  <div className="col-span-2 p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
                    <div>
                      <div className="text-[11px] text-slate-500 font-medium">
                        UAE VAT Calculation ({isComm ? 'Commercial 5%' : 'Residence 0% Exempt'}):
                      </div>
                      <div className="text-xs font-bold text-slate-800 mt-0.5">
                        Base Rent: {formatAED(rent)} {isComm ? `• 5% VAT: +${formatAED(vat)}` : '• 0% VAT Exempt'}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-slate-400 uppercase font-semibold">Total with VAT</div>
                      <div className="text-base font-black text-emerald-700">{formatAED(total)}</div>
                    </div>
                  </div>
                );
              })()}

              <div>
                <label className="text-slate-600 font-medium">Contract / Ejari No</label>
                <input
                  type="text"
                  placeholder="e.g. EJARI-2026-9921"
                  value={newContractData.contractNo || ''}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, contractNo: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Tenant Name *</label>
                <input
                  type="text"
                  placeholder="Full Tenant Name"
                  value={newContractData.tenantName || ''}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, tenantName: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Building Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Marina Gate 1"
                  value={newContractData.buildingName || ''}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, buildingName: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <div className="flex items-center justify-between">
                  <label className="text-slate-600 font-medium">Property / Unit No</label>
                  {duplicateUnitMatch && (
                    <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.2 rounded">
                      Duplicate Unit
                    </span>
                  )}
                </div>
                <input
                  type="text"
                  placeholder="e.g. 1402"
                  value={newContractData.propertyNo || ''}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, propertyNo: e.target.value })
                  }
                  className={`mt-1 w-full p-2 border rounded-xl bg-slate-50 ${
                    duplicateUnitMatch ? 'border-amber-400 bg-amber-50/50 ring-2 ring-amber-300/40 text-amber-950 font-semibold' : ''
                  }`}
                />
                {duplicateUnitMatch && (
                  <div className="mt-1 flex items-start gap-1.5 text-[11px] text-amber-900 bg-amber-50 p-2 rounded-lg border border-amber-200">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Duplicate Unit Warning: </span>
                      <span>Unit "{newContractData.propertyNo}" already exists in {duplicateUnitMatch.buildingName || 'database'} (Tenant: {duplicateUnitMatch.tenantName || 'Unknown'})</span>
                    </div>
                  </div>
                )}
              </div>
              <div>
                <label className="text-slate-600 font-medium">Owner Name</label>
                <input
                  type="text"
                  placeholder="Property Owner"
                  value={newContractData.ownerName || ''}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, ownerName: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Lessor Name</label>
                <input
                  type="text"
                  placeholder="Lessor / Property Mgmt"
                  value={newContractData.lessorName || ''}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, lessorName: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Property Type</label>
                <select
                  value={newContractData.propertyType || 'Residential'}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, propertyType: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                >
                  <option value="Residential">Residential</option>
                  <option value="Commercial">Commercial</option>
                  <option value="Industrial">Industrial</option>
                </select>
              </div>
              <div>
                <label className="text-slate-600 font-medium">Sub Type</label>
                <input
                  type="text"
                  placeholder="Apartment, Villa, Office"
                  value={newContractData.subType || 'Apartment'}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, subType: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Size</label>
                <input
                  type="text"
                  placeholder="e.g. 1,250 Sq.Ft"
                  value={newContractData.size || ''}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, size: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Contract Amount (AED) *</label>
                <input
                  type="number"
                  placeholder="AED Amount"
                  value={newContractData.contractAmount || 0}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setNewContractData({
                      ...newContractData,
                      contractAmount: val,
                      actualAnnualAmount: newContractData.actualAnnualAmount || val,
                    });
                  }}
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50 font-bold"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Actual Annual Amount (AED)</label>
                <input
                  type="number"
                  placeholder="Actual Annual Rent"
                  value={newContractData.actualAnnualAmount || 0}
                  onChange={(e) =>
                    setNewContractData({
                      ...newContractData,
                      actualAnnualAmount: Number(e.target.value),
                    })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50 font-bold"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Security Deposit (AED)</label>
                <input
                  type="number"
                  placeholder="Deposit"
                  value={newContractData.securityDeposit || 0}
                  onChange={(e) =>
                    setNewContractData({
                      ...newContractData,
                      securityDeposit: Number(e.target.value),
                    })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Start Date</label>
                <input
                  type="date"
                  value={newContractData.startDate || ''}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, startDate: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">End Date</label>
                <input
                  type="date"
                  value={newContractData.endDate || ''}
                  onChange={(e) =>
                    setNewContractData({ ...newContractData, endDate: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2.5">
              <button
                onClick={() => setIsAddingNew(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateNew}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition shadow-xs"
              >
                Save Contract
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
