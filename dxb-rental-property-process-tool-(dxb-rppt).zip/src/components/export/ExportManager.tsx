import React, { useState } from 'react';
import {
  FileSpreadsheet,
  Download,
  FileText,
  CheckCircle2,
  Building,
  Receipt as ReceiptIcon,
  FileCheck2,
  Landmark,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { usePropertyData } from '../../context/PropertyDataContext';

export const ExportManager: React.FC = () => {
  const {
    filteredContracts,
    filteredReceipts,
    filteredInvoices,
    filteredStatements,
    metrics,
    filters,
  } = usePropertyData();

  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  // 1. Export Excel (.xlsx) with dedicated Zoho Books & Tally Prime sheets
  const handleExportExcel = () => {
    const wb = XLSX.utils.book_new();

    // Sheet 1: Executive KPI & VAT Summary
    const summaryData = [
      ['DXB RENTAL PROPERTY PROCESS TOOL (DXB-RPPT)', 'EXECUTIVE AUDIT SUMMARY'],
      ['Export Date', new Date().toLocaleDateString()],
      ['Property Filter', filters.propertyFilter],
      ['Period Filter', filters.periodFilter],
      ['Currency', 'UAE Dirhams (AED)'],
      [],
      ['Metric Name', 'Amount (AED)', 'Notes'],
      ['Total Contract Amount Processed', metrics.totalContractAmount, `${filteredContracts.length} Contracts`],
      ['Total Actual Annual Amount', metrics.totalActualAnnualAmount, 'Annualized Rent baseline'],
      ['Total Security Deposit', metrics.totalSecurityDeposit, 'Escrow held'],
      ['Total Receipts Collected', metrics.totalReceipts, `${filteredReceipts.length} Cheques`],
      ['Total Purchase Maintenance Exp', metrics.totalPurchaseMaintenanceExp, `${filteredInvoices.length} Invoices`],
      ['Total VAT on Purchase Invoices (5%)', metrics.totalVATOnPurchaseInvoice, 'Input Tax Credit'],
      ['Net Rent Income (Actual - Maint)', metrics.netRentIncome, 'Formula: Annual Rent - Maintenance'],
      ['Total VAT on Actual Rent', metrics.totalVATOnActualRent, 'Commercial 5% Output Tax'],
      ['Net VAT Position', metrics.netVAT, 'Formula: Output VAT - Input VAT'],
    ];
    const wsSummary = XLSX.utils.aoa_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(wb, wsSummary, 'Executive Summary');

    // Sheet 2: Tenancy Contracts (Ejari)
    const contractsData = filteredContracts.map((c) => ({
      'Property No': c.propertyNo,
      'Building Name': c.buildingName,
      'Tenant Name': c.tenantName,
      'Owner Name': c.ownerName,
      'Lessor Name': c.lessorName,
      'Type': c.type,
      'Sub Type': c.subType,
      'Size (Sq Ft)': c.size,
      'Contract Amount (AED)': c.contractAmount,
      'Actual Annual Amount (AED)': c.actualAnnualAmount,
      'Security Deposit (AED)': c.securityDeposit,
      'Start Date': c.startDate,
      'End Date': c.endDate,
      'Registration Date': c.registrationDate,
      'VAT Rate (%)': c.vatRate,
      'VAT Amount (AED)': c.vatAmount,
    }));
    const wsContracts = XLSX.utils.json_to_sheet(contractsData);
    XLSX.utils.book_append_sheet(wb, wsContracts, 'Tenancy Contracts');

    // Sheet 3: Rental Receipts
    const receiptsData = filteredReceipts.map((r) => ({
      'Installment Date': r.installmentDate,
      'Amount (AED)': r.amount,
      'Cheque Number': r.chequeNo,
      'Bank Name': r.bankName,
      'Property No': r.propertyNo,
      'Tenant Name': r.tenantName,
      'Status': r.status,
      'Bank Reconciled': r.matchedBankTxId ? 'YES' : 'NO',
    }));
    const wsReceipts = XLSX.utils.json_to_sheet(receiptsData);
    XLSX.utils.book_append_sheet(wb, wsReceipts, 'Rental Receipts');

    // Sheet 4: Purchase Tax Invoices
    const invoicesData = filteredInvoices.map((i) => ({
      'Invoice Number': i.invoiceNumber,
      'Invoice Date': i.invoiceDate,
      'Supplier Name': i.supplierName,
      'Supplier TRN': i.supplierTRN,
      'Property No': i.propertyNo,
      'Building Name': i.buildingName,
      'Description': i.description,
      'Net Amount (AED)': i.netAmount,
      'VAT 5% Amount (AED)': i.taxAmount,
      'Total Amount (AED)': i.totalInvoiceAmount,
      'Bank Reconciled': i.matchedBankTxId ? 'YES' : 'NO',
    }));
    const wsInvoices = XLSX.utils.json_to_sheet(invoicesData);
    XLSX.utils.book_append_sheet(wb, wsInvoices, 'Purchase Invoices');

    // Sheet 5: Zoho Books (UAE VAT) Format
    const zohoData = filteredInvoices.map((i) => ({
      'Vendor Name': i.supplierName,
      'Invoice#': i.invoiceNumber,
      'Invoice Date': i.invoiceDate,
      'Due Date': i.invoiceDate,
      'Tax Treatment': 'vat_registered',
      'TRN/Tax Registration Number': i.supplierTRN || '',
      'Item Name': 'Property Repairs & Maintenance',
      'Description': `${i.propertyNo ? `[${i.propertyNo}] ` : ''}${i.description}`,
      'Account': 'Repairs and Maintenance',
      'Item Price': i.netAmount,
      'Quantity': 1,
      'Tax Name': 'Standard Rate (5%)',
      'Tax Percentage': 5,
      'Tax Type': 'Tax',
      'Tax Amount': i.taxAmount,
      'Total': i.totalInvoiceAmount,
    }));
    const wsZoho = XLSX.utils.json_to_sheet(zohoData);
    XLSX.utils.book_append_sheet(wb, wsZoho, 'Zoho Books (UAE VAT)');

    // Sheet 6: Tally Prime (UAE VAT) Format
    const tallyData = filteredInvoices.map((i) => ({
      'Date': i.invoiceDate,
      'Voucher Type': 'Purchase',
      'Voucher Number': i.invoiceNumber,
      'Party Ledger Name': i.supplierName,
      'Tax Registration No': i.supplierTRN || '',
      'Expense Ledger': 'Building Maintenance Expenses',
      'Amount Before Tax': i.netAmount,
      'VAT Classification': 'UAE VAT Standard Rated Purchases (5%)',
      'VAT Ledger': 'Input VAT (5%)',
      'VAT Amount': i.taxAmount,
      'Total Voucher Amount': i.totalInvoiceAmount,
      'Narration': `Being maintenance charges for ${i.propertyNo || 'Property'} as per invoice ${i.invoiceNumber}`,
    }));
    const wsTally = XLSX.utils.json_to_sheet(tallyData);
    XLSX.utils.book_append_sheet(wb, wsTally, 'Tally Prime (UAE VAT)');

    // Trigger Download
    XLSX.writeFile(wb, `DXB_RPPT_Accounting_Export_${new Date().toISOString().slice(0, 10)}.xlsx`);
    setDownloadSuccess('Excel workbook with Zoho & Tally sheets generated successfully!');
    setTimeout(() => setDownloadSuccess(null), 4000);
  };

  // 2. Export CSV Format
  const handleExportCSV = () => {
    const rows = [
      ['Type', 'ID/Ref', 'Date', 'Entity/Party', 'Property', 'Amount (AED)', 'VAT (AED)', 'Total (AED)'],
      ...filteredContracts.map((c) => [
        'Contract',
        c.propertyNo,
        c.startDate,
        c.tenantName,
        c.propertyNo,
        c.actualAnnualAmount,
        c.vatAmount,
        c.actualAnnualAmount + c.vatAmount,
      ]),
      ...filteredReceipts.map((r) => [
        'Receipt',
        r.chequeNo,
        r.installmentDate,
        r.tenantName,
        r.propertyNo,
        r.amount,
        0,
        r.amount,
      ]),
      ...filteredInvoices.map((i) => [
        'PurchaseInvoice',
        i.invoiceNumber,
        i.invoiceDate,
        i.supplierName,
        i.propertyNo,
        i.netAmount,
        i.taxAmount,
        i.totalInvoiceAmount,
      ]),
    ];

    const csvContent =
      'data:text/csv;charset=utf-8,' + rows.map((e) => e.map((x) => `"${x}"`).join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `DXB_RPPT_Data_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setDownloadSuccess('CSV export generated successfully!');
    setTimeout(() => setDownloadSuccess(null), 4000);
  };

  // 3. Export PDF using jsPDF and autoTable
  const handleExportPDF = () => {
    const doc = new jsPDF({ orientation: 'landscape', format: 'a4' });

    // Header styling
    doc.setFontSize(18);
    doc.setTextColor(15, 41, 74);
    doc.text('DXB Rental Property Process Tool (DXB-RPPT)', 14, 18);

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text(
      `Official Financial Summary & VAT Audit Report • Currency: UAE Dirham (AED) • Generated: ${new Date().toLocaleDateString()}`,
      14,
      25
    );

    // Summary Metric KPI block
    autoTable(doc, {
      startY: 32,
      head: [['Metric Description', 'Amount (AED)', 'Statistical Notes']],
      body: [
        ['Total Contract Amount Processed', `AED ${metrics.totalContractAmount.toLocaleString()}`, `${filteredContracts.length} Tenancy Contracts Registered`],
        ['Total Actual Annual Amount', `AED ${metrics.totalActualAnnualAmount.toLocaleString()}`, 'Annualized Rent Yield'],
        ['Total Security Deposit Held', `AED ${metrics.totalSecurityDeposit.toLocaleString()}`, 'Escrow / Security Deposit Reserve'],
        ['Total Receipts Collected', `AED ${metrics.totalReceipts.toLocaleString()}`, `${filteredReceipts.length} Cheque Installments`],
        ['Total Purchase Maintenance Expenses', `AED ${metrics.totalPurchaseMaintenanceExp.toLocaleString()}`, `${filteredInvoices.length} Tax Invoices`],
        ['Total VAT on Purchase Invoices (5%)', `AED ${metrics.totalVATOnPurchaseInvoice.toLocaleString()}`, 'Input Tax Credit claimable from FTA'],
        ['Net Rent Income (Actual Rent - Maintenance)', `AED ${metrics.netRentIncome.toLocaleString()}`, 'Net Property Operating Income'],
        ['Total VAT on Actual Rent', `AED ${metrics.totalVATOnActualRent.toLocaleString()}`, 'Output Tax (Commercial 5%)'],
        ['Net VAT Position (Output VAT - Input VAT)', `AED ${metrics.netVAT.toLocaleString()}`, 'FTA Form 201 Net Tax Position'],
      ],
      theme: 'grid',
      headStyles: { fillColor: [15, 41, 74], textColor: 255 },
      styles: { fontSize: 8, cellPadding: 2.5 },
    });

    // Invoices Table
    const lastY = (doc as any).lastAutoTable?.finalY || 120;
    doc.setFontSize(12);
    doc.setTextColor(15, 41, 74);
    doc.text('Purchase Tax Invoices (5% UAE VAT Breakdown)', 14, lastY + 12);

    const invoiceRows = filteredInvoices.map((i) => [
      i.invoiceNumber,
      i.invoiceDate,
      i.supplierName,
      i.supplierTRN || '—',
      i.propertyNo || '—',
      `AED ${i.netAmount.toLocaleString()}`,
      `AED ${i.taxAmount.toLocaleString()}`,
      `AED ${i.totalInvoiceAmount.toLocaleString()}`,
    ]);

    autoTable(doc, {
      startY: lastY + 16,
      head: [['Invoice #', 'Date', 'Supplier', 'TRN', 'Property', 'Net (AED)', 'VAT 5% (AED)', 'Total (AED)']],
      body: invoiceRows.length > 0 ? invoiceRows : [['No invoices recorded', '', '', '', '', '', '', '']],
      theme: 'striped',
      headStyles: { fillColor: [217, 119, 6], textColor: 255 },
      styles: { fontSize: 7, cellPadding: 2 },
    });

    doc.save(`DXB_RPPT_Financial_Audit_${new Date().toISOString().slice(0, 10)}.pdf`);
    setDownloadSuccess('PDF Audit Report exported successfully!');
    setTimeout(() => setDownloadSuccess(null), 4000);
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Title */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
            <span>Accounting & ERP Export Center</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Export ready-to-import data templates for Zoho Books (UAE edition) and Tally Prime (UAE VAT).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
            UAE FTA VAT Form 201 Compatible
          </span>
        </div>
      </div>

      {/* Success Notification */}
      {downloadSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="text-xs font-bold">{downloadSuccess}</span>
        </div>
      )}

      {/* Export Options Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Card 1: Multi-Sheet Excel */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col justify-between hover:shadow-md transition-all">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Excel Workbook (.xlsx)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Includes 6 structured sheets: Executive Summary, Tenancy Contracts, Cheque Receipts, Tax Invoices, Zoho Books UAE, and Tally Prime UAE.
            </p>

            <div className="mt-4 space-y-1.5 text-[11px] text-slate-600">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Zoho Books (UAE VAT) import format</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Tally Prime (UAE VAT) ledger schema</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>All formulas and AED values preserved</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleExportExcel}
            className="mt-6 w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download Excel (.xlsx)</span>
          </button>
        </div>

        {/* Card 2: PDF Audit Report */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col justify-between hover:shadow-md transition-all">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-4">
              <FileText className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Auditor PDF Document (.pdf)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Landscape formatted executive PDF summary including all 9 KPIs, formulas, and 5% UAE VAT input/output tax schedule.
            </p>

            <div className="mt-4 space-y-1.5 text-[11px] text-slate-600">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-rose-600" />
                <span>Print-ready executive summary</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-rose-600" />
                <span>Contractor TRN & Tax breakdown</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-rose-600" />
                <span>Clean Apple typography styling</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleExportPDF}
            className="mt-6 w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-md shadow-rose-600/30 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download Audit PDF</span>
          </button>
        </div>

        {/* Card 3: CSV Data Tables */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col justify-between hover:shadow-md transition-all">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900">
              Raw Comma-Separated (.csv)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Universal UTF-8 CSV containing flat table records for seamless ingestion into PowerBI, Google Sheets, or custom SQL databases.
            </p>

            <div className="mt-4 space-y-1.5 text-[11px] text-slate-600">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                <span>Universal database ingest</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                <span>UTF-8 encoded with currency keys</span>
              </div>
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                <span>Lightweight & fast processing</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleExportCSV}
            className="mt-6 w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/30 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Download CSV (.csv)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
