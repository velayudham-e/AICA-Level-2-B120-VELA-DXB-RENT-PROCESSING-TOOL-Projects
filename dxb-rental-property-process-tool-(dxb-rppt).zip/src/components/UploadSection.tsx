import React, { useState, useRef } from 'react';
import {
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
  AlertTriangle,
  Loader2,
  Trash2,
  Sparkles,
  Layers,
  Save,
  Building,
  Receipt,
  FileSpreadsheet,
  Edit2,
  Eye,
  Plus,
  RefreshCw,
  Camera,
  Filter,
  ShieldAlert,
  Landmark,
} from 'lucide-react';
import { BatchItem, TenancyContract, RentalReceipt, PurchaseTaxInvoice } from '../types';
import { formatAED } from '../utils/exportUtils';
import { saveContract, saveReceipt, saveInvoice } from '../services/dbService';
import { useAuth } from '../context/AuthContext';
import { CameraCaptureModal } from './CameraCaptureModal';
import {
  getItemDuplicationAlerts,
  getBatchDuplicationSummary,
  checkInvoiceDuplication,
  checkUnitDuplication,
  checkReceiptDuplication,
  DuplicationAlert,
} from '../utils/duplicateDetector';
import { calculateContractVat, isCommercialContract } from '../utils/vatCalculator';

interface UploadSectionProps {
  onSuccess: () => void;
  onNavigateTab?: (tab: any) => void;
  existingContracts?: TenancyContract[];
  existingReceipts?: RentalReceipt[];
  existingInvoices?: PurchaseTaxInvoice[];
}

export const UploadSection: React.FC<UploadSectionProps> = ({
  onSuccess,
  onNavigateTab,
  existingContracts = [],
  existingReceipts = [],
  existingInvoices = [],
}) => {
  const { user } = useAuth();
  const [items, setItems] = useState<BatchItem[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedDocType, setSelectedDocType] = useState<'auto' | 'contract' | 'receipt' | 'invoice'>('auto');
  const [saveStatus, setSaveStatus] = useState<string | null>(null);
  const [editingItem, setEditingItem] = useState<BatchItem | null>(null);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [filterOnlyDuplicates, setFilterOnlyDuplicates] = useState(false);
  const [showDuplicateWarningModal, setShowDuplicateWarningModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getNormalizedMimeType = (file: File) => {
    const name = file.name.toLowerCase();
    if (name.endsWith('.pdf')) return 'application/pdf';
    if (name.endsWith('.png')) return 'image/png';
    if (name.endsWith('.jpg') || name.endsWith('.jpeg')) return 'image/jpeg';
    return file.type || 'application/pdf';
  };

  const normalizeDate = (d?: string): string => {
    if (!d) return '';
    const clean = d.trim();
    if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) return clean;
    const parts = clean.split(/[/.-]/);
    if (parts.length === 3) {
      if (parts[2].length === 4) {
        return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
      } else if (parts[0].length === 4) {
        return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
      }
    }
    const parsed = new Date(clean);
    if (!isNaN(parsed.getTime())) {
      return parsed.toISOString().slice(0, 10);
    }
    return clean;
  };

  const processBatchItems = async (itemsToProcess: BatchItem[]) => {
    if (itemsToProcess.length === 0 || isProcessing) return;
    setIsProcessing(true);

    for (const targetItem of itemsToProcess) {
      setItems((prev) =>
        prev.map((i) =>
          i.id === targetItem.id ? { ...i, status: 'processing', progress: 40 } : i
        )
      );

      const processed = await processSingleItem(targetItem);

      setItems((prev) =>
        prev.map((i) => (i.id === targetItem.id ? processed : i))
      );
    }

    setIsProcessing(false);
  };

  const handleCapturedFile = (file: File) => {
    const newItem: BatchItem = {
      id: `batch-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      file,
      fileName: file.name,
      fileSize: file.size,
      mimeType: 'image/jpeg',
      status: 'pending',
      targetType: selectedDocType,
      progress: 0,
    };
    setItems((prev) => [newItem, ...prev]);
    setTimeout(() => {
      processBatchItems([newItem]);
    }, 100);
  };

  const handleFiles = (fileList: FileList | null, autoProcess = true) => {
    if (!fileList || fileList.length === 0) return;

    const newItems: BatchItem[] = Array.from(fileList).map((file) => ({
      id: `batch-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      file,
      fileName: file.name,
      fileSize: file.size,
      mimeType: getNormalizedMimeType(file),
      status: 'pending',
      targetType: selectedDocType,
      progress: 0,
    }));

    setItems((prev) => [...newItems, ...prev]);

    if (autoProcess) {
      setTimeout(() => {
        processBatchItems(newItems);
      }, 100);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files, true);
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  const processSingleItem = async (item: BatchItem): Promise<BatchItem> => {
    try {
      const base64 = await fileToBase64(item.file);
      const res = await fetch('/api/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          base64Data: base64,
          mimeType: item.mimeType,
          fileName: item.fileName,
          targetType: item.targetType,
        }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || `Server extraction failed (${res.status})`);
      }

      const data = await res.json();
      const result = data.result;

      // Normalize all dates extracted
      if (result.contract) {
        if (result.contract.startDate) result.contract.startDate = normalizeDate(result.contract.startDate);
        if (result.contract.endDate) result.contract.endDate = normalizeDate(result.contract.endDate);
        if (result.contract.registrationDate) result.contract.registrationDate = normalizeDate(result.contract.registrationDate);
      }
      if (result.receipt) {
        if (result.receipt.installmentDate) {
          result.receipt.installmentDate = normalizeDate(result.receipt.installmentDate);
        }
      }
      if (result.invoice) {
        if (result.invoice.invoiceDate) {
          result.invoice.invoiceDate = normalizeDate(result.invoice.invoiceDate);
        }
      }

      return {
        ...item,
        status: 'success',
        progress: 100,
        detectedType: result.detectedType || (item.targetType !== 'auto' ? item.targetType : 'contract'),
        extractedData: {
          contract: result.contract,
          receipt: result.receipt,
          invoice: result.invoice,
          summaryNotes: result.summaryNotes,
        },
      };
    } catch (err: any) {
      return {
        ...item,
        status: 'error',
        progress: 100,
        errorMessage: err.message || 'Failed to extract document',
      };
    }
  };

  const processAllBatch = async () => {
    const pendingItems = items.filter((i) => i.status !== 'success');
    if (pendingItems.length === 0) return;
    await processBatchItems(pendingItems);
  };

  const removeItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  // Calculation of batch duplication warnings
  const duplicateSummary = getBatchDuplicationSummary(
    items,
    existingContracts,
    existingReceipts,
    existingInvoices
  );

  const handleSaveClick = () => {
    if (!user) {
      alert('Please sign in to save records to the database.');
      return;
    }

    if (duplicateSummary.totalAlerts > 0) {
      setShowDuplicateWarningModal(true);
    } else {
      saveAllToDatabase();
    }
  };

  const saveAllToDatabase = async () => {
    if (!user) {
      alert('Please sign in to save records to the database.');
      return;
    }

    setShowDuplicateWarningModal(false);
    setSaveStatus('Saving to secure Firestore database...');
    try {
      let savedContracts = 0;
      let savedReceipts = 0;
      let savedInvoices = 0;

      for (const item of items) {
        if (item.status !== 'success' || !item.extractedData) continue;

        const { detectedType, extractedData, fileName } = item;
        const now = new Date().toISOString();

        if (detectedType === 'contract' && extractedData.contract) {
          const c = extractedData.contract;
          const annualRent = Number(c.actualAnnualAmount) || Number(c.contractAmount) || 0;
          const vatInfo = calculateContractVat(c.contractType || c.propertyType, annualRent);

          const contractDoc: TenancyContract = {
            id: `CNT-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            userId: user.uid,
            contractNo: c.contractNo || `EJARI-${Date.now().toString().slice(-6)}`,
            ownerName: c.ownerName || 'Property Owner',
            lessorName: c.lessorName || '',
            tenantName: c.tenantName || 'Tenant Name',
            buildingName: c.buildingName || 'Building / Tower',
            propertyNo: c.propertyNo || '',
            contractType: vatInfo.contractType,
            propertyType: c.propertyType || (vatInfo.contractType === 'Commercial' ? 'Commercial' : 'Residential'),
            subType: c.subType || (vatInfo.contractType === 'Commercial' ? 'Office' : 'Apartment'),
            size: c.size || '1,200 Sq.Ft',
            contractAmount: Number(c.contractAmount) || 0,
            actualAnnualAmount: annualRent,
            vatRate: vatInfo.vatRate,
            vatAmount: vatInfo.vatAmount,
            totalAmountWithVat: vatInfo.totalAmountWithVat,
            securityDeposit: Number(c.securityDeposit) || 0,
            startDate: c.startDate || new Date().toISOString().slice(0, 10),
            endDate: c.endDate || new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10),
            registrationDate: c.registrationDate || new Date().toISOString().slice(0, 10),
            fileName: fileName,
            notes: extractedData.summaryNotes,
            createdAt: now,
            updatedAt: now,
          };
          await saveContract(contractDoc);
          savedContracts++;
        } else if (detectedType === 'receipt' && extractedData.receipt) {
          const r = extractedData.receipt;
          const receiptDoc: RentalReceipt = {
            id: `RCP-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            userId: user.uid,
            receiptNo: r.receiptNo || `VCH-${Date.now().toString().slice(-6)}`,
            installmentDate: r.installmentDate || new Date().toISOString().slice(0, 10),
            amount: Number(r.amount) || 0,
            chequeNo: r.chequeNo || 'N/A',
            bankName: r.bankName || 'UAE Bank',
            tenantName: r.tenantName || '',
            propertyRef: r.propertyRef || '',
            fileName: fileName,
            notes: extractedData.summaryNotes,
            createdAt: now,
            updatedAt: now,
          };
          await saveReceipt(receiptDoc);
          savedReceipts++;
        } else if (detectedType === 'invoice' && extractedData.invoice) {
          const inv = extractedData.invoice;
          const total = Number(inv.totalInvoiceAmount) || 0;
          const tax = Number(inv.taxAmount) || (total > 0 ? +(total - total / 1.05).toFixed(2) : 0);
          const net = Number(inv.netAmount) || +(total - tax).toFixed(2);

          const invoiceDoc: PurchaseTaxInvoice = {
            id: `INV-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            userId: user.uid,
            invoiceNumber: inv.invoiceNumber || `TAX-${Date.now().toString().slice(-6)}`,
            invoiceDate: inv.invoiceDate || new Date().toISOString().slice(0, 10),
            supplierName: inv.supplierName || 'Maintenance Supplier',
            supplierTrn: inv.supplierTrn || '',
            expenseCategory: inv.expenseCategory || 'Maintenance',
            netAmount: net,
            taxAmount: tax,
            totalInvoiceAmount: total,
            buildingRef: inv.buildingRef || '',
            fileName: fileName,
            notes: extractedData.summaryNotes,
            createdAt: now,
            updatedAt: now,
          };
          await saveInvoice(invoiceDoc);
          savedInvoices++;
        }
      }

      setSaveStatus(
        `Successfully saved ${savedContracts} contracts, ${savedReceipts} receipts, and ${savedInvoices} tax invoices!`
      );
      setTimeout(() => {
        setItems([]);
        setSaveStatus(null);
        onSuccess();
      }, 1500);
    } catch (err: any) {
      alert(`Error saving to database: ${err.message}`);
      setSaveStatus(null);
    }
  };

  // Batch summary metrics
  const successfulItems = items.filter((i) => i.status === 'success');
  const batchContracts = successfulItems.filter((i) => i.detectedType === 'contract');
  const batchReceipts = successfulItems.filter((i) => i.detectedType === 'receipt');
  const batchInvoices = successfulItems.filter((i) => i.detectedType === 'invoice');

  const batchTotalRent = batchContracts.reduce(
    (acc, c) => acc + (Number(c.extractedData?.contract?.contractAmount) || 0),
    0
  );
  const batchTotalReceipts = batchReceipts.reduce(
    (acc, r) => acc + (Number(r.extractedData?.receipt?.amount) || 0),
    0
  );
  const batchTotalInvoices = batchInvoices.reduce(
    (acc, i) => acc + (Number(i.extractedData?.invoice?.totalInvoiceAmount) || 0),
    0
  );
  const batchTotalVAT = batchInvoices.reduce(
    (acc, i) => acc + (Number(i.extractedData?.invoice?.taxAmount) || 0),
    0
  );

  // Filter items if user toggled duplicate filter
  const displayedItems = filterOnlyDuplicates
    ? items.filter((item) => {
        const alerts = getItemDuplicationAlerts(
          item,
          items,
          existingContracts,
          existingReceipts,
          existingInvoices
        );
        return alerts.length > 0;
      })
    : items;

  // Alerts for editing item
  const editingItemAlerts = editingItem
    ? getItemDuplicationAlerts(
        editingItem,
        items,
        existingContracts,
        existingReceipts,
        existingInvoices
      )
    : [];

  const editingUnitAlert = editingItem?.detectedType === 'contract'
    ? checkUnitDuplication(
        editingItem.extractedData?.contract?.propertyNo,
        editingItem.extractedData?.contract?.buildingName,
        editingItem.id,
        items,
        existingContracts
      )
    : null;

  const editingReceiptAlert = editingItem?.detectedType === 'receipt'
    ? checkReceiptDuplication(
        editingItem.extractedData?.receipt?.receiptNo,
        editingItem.extractedData?.receipt?.chequeNo,
        editingItem.id,
        items,
        existingReceipts
      )
    : null;

  const editingInvoiceAlert = editingItem?.detectedType === 'invoice'
    ? checkInvoiceDuplication(
        editingItem.extractedData?.invoice?.invoiceNumber,
        editingItem.id,
        items,
        existingInvoices
      )
    : null;

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-200/80">
        <div>
          <span className="text-xs font-semibold tracking-wider uppercase text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200/60">
            Batch AI OCR Engine
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
            Upload & Extract UAE Tenancy, Receipts & Tax Invoices
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Drag and drop multiple PDF documents or JPG/PNG scans. The multimodal model parses Ejari parameters, cheque entries, 5% VAT, and flags duplications.
          </p>
        </div>

        {/* Document Classification Selector & Direct Camera Action */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              setSelectedDocType('invoice');
              setIsCameraOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 transition shadow-xs ring-2 ring-emerald-500/20"
          >
            <Camera className="w-4 h-4" />
            Capture Camera Invoice
          </button>

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200/80 text-xs">
            <button
              onClick={() => setSelectedDocType('auto')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                selectedDocType === 'auto'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Auto-Detect
            </button>
            <button
              onClick={() => setSelectedDocType('contract')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                selectedDocType === 'contract'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Contracts
            </button>
            <button
              onClick={() => setSelectedDocType('receipt')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                selectedDocType === 'receipt'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Receipts
            </button>
            <button
              onClick={() => setSelectedDocType('invoice')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                selectedDocType === 'invoice'
                  ? 'bg-white text-blue-700 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tax Invoices
            </button>
            {onNavigateTab && (
              <button
                onClick={() => onNavigateTab('bank-reconciliation')}
                className="px-3 py-1.5 rounded-lg font-bold transition text-indigo-700 bg-indigo-50 hover:bg-indigo-100 flex items-center gap-1"
                title="Open Bank Reconciliation workspace"
              >
                <Landmark className="w-3.5 h-3.5 text-indigo-600" />
                Bank Statements (BRS)
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Drag & Drop Upload Zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
        className={`relative border-2 border-dashed rounded-3xl p-8 text-center transition-all duration-200 bg-white shadow-xs ${
          isDragging
            ? 'border-blue-500 bg-blue-50/50 scale-[1.005]'
            : 'border-slate-300 hover:border-blue-400'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept=".pdf,image/png,image/jpeg,image/jpg"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />

        <div className="max-w-md mx-auto space-y-3">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 shadow-xs">
            <Upload className="w-8 h-8" />
          </div>

          <div>
            <h3 className="text-base font-bold text-slate-900">
              Drag & Drop UAE Contracts, Receipts, or Invoices Here
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Supports single or batch upload in PDF, JPG, or PNG format. Files are analyzed with Dubai Ejari and UAE FTA VAT guidelines with automated duplicate prevention.
            </p>
          </div>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition shadow-xs flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Browse Local Files
            </button>

            <button
              onClick={() => setIsCameraOpen(true)}
              className="px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 rounded-xl hover:bg-emerald-700 transition shadow-xs flex items-center gap-2 shadow-emerald-600/20"
            >
              <Camera className="w-4 h-4" />
              Capture with Camera
            </button>
          </div>
        </div>
      </div>

      {/* Batch Overview & Actions */}
      {items.length > 0 && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold text-sm">
                {items.length}
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">
                  Batch Processing Queue ({items.length} files selected)
                </h4>
                <p className="text-xs text-slate-500">
                  {successfulItems.length} of {items.length} documents successfully extracted
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => setIsCameraOpen(true)}
                className="px-3 py-2 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition flex items-center gap-1.5"
              >
                <Camera className="w-3.5 h-3.5 text-emerald-600" />
                Capture Photo
              </button>
              <button
                onClick={() => setItems([])}
                className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-rose-600 bg-slate-50 hover:bg-rose-50 border border-slate-200 rounded-xl transition"
              >
                Clear Queue
              </button>
              <button
                disabled={isProcessing || items.every((i) => i.status === 'success')}
                onClick={processAllBatch}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition disabled:opacity-50 flex items-center gap-2 shadow-xs"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    Extracting Batch Data...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-3.5 h-3.5" />
                    Extract All with Gemini AI
                  </>
                )}
              </button>

              {successfulItems.length > 0 && (
                <button
                  onClick={handleSaveClick}
                  className={`px-4 py-2 text-xs font-semibold text-white rounded-xl transition flex items-center gap-2 shadow-xs ${
                    duplicateSummary.totalAlerts > 0
                      ? 'bg-amber-600 hover:bg-amber-700 ring-2 ring-amber-500/30'
                      : 'bg-emerald-600 hover:bg-emerald-700'
                  }`}
                >
                  <Save className="w-3.5 h-3.5" />
                  Save {successfulItems.length} Records to Database
                  {duplicateSummary.totalAlerts > 0 && (
                    <span className="bg-amber-800/80 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                      {duplicateSummary.totalAlerts} Warnings
                    </span>
                  )}
                </button>
              )}
            </div>
          </div>

          {saveStatus && (
            <div className="p-3.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-900 text-xs font-medium flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
              <span>{saveStatus}</span>
            </div>
          )}

          {/* Prominent Duplication Warning Banner */}
          {duplicateSummary.totalAlerts > 0 && (
            <div className="bg-amber-50/90 border-2 border-amber-300 rounded-2xl p-4.5 text-amber-950 shadow-sm transition-all duration-200">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-700 flex items-center justify-center shrink-0 mt-0.5">
                    <AlertTriangle className="w-5 h-5 text-amber-600" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="text-sm font-extrabold text-amber-950">
                        Duplication Warning ({duplicateSummary.totalAlerts} {duplicateSummary.totalAlerts === 1 ? 'record warning' : 'record warnings'})
                      </h4>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 uppercase tracking-wider">
                        Verification Advised
                      </span>
                    </div>
                    <p className="text-xs text-amber-900/90 leading-relaxed">
                      Potential duplicate entries detected in invoice numbers, unit numbers, or receipt numbers against existing recorded database entries or other files in this batch. Review before saving to avoid duplicate billing, duplicate lease bookings, or FTA VAT discrepancies.
                    </p>

                    {/* Breakdown Badges */}
                    <div className="flex flex-wrap items-center gap-2 pt-1.5">
                      {duplicateSummary.byType.invoices > 0 && (
                        <span className="text-[11px] font-bold bg-white text-rose-800 border border-rose-200 px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-2xs">
                          <span className="w-2 h-2 rounded-full bg-rose-500"></span>
                          {duplicateSummary.byType.invoices} Duplicate Invoice {duplicateSummary.byType.invoices === 1 ? 'Number' : 'Numbers'}
                        </span>
                      )}
                      {duplicateSummary.byType.units > 0 && (
                        <span className="text-[11px] font-bold bg-white text-amber-800 border border-amber-200 px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-2xs">
                          <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                          {duplicateSummary.byType.units} Duplicate Unit {duplicateSummary.byType.units === 1 ? 'Number' : 'Numbers'}
                        </span>
                      )}
                      {duplicateSummary.byType.receipts > 0 && (
                        <span className="text-[11px] font-bold bg-white text-blue-800 border border-blue-200 px-2.5 py-1 rounded-lg flex items-center gap-1.5 shadow-2xs">
                          <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                          {duplicateSummary.byType.receipts} Duplicate Receipt {duplicateSummary.byType.receipts === 1 ? 'Number' : 'Numbers'}
                        </span>
                      )}

                      <button
                        onClick={() => setFilterOnlyDuplicates(!filterOnlyDuplicates)}
                        className="text-[11px] font-bold text-amber-950 underline hover:text-amber-800 ml-1 cursor-pointer"
                      >
                        {filterOnlyDuplicates ? 'Show All Queue Items' : 'Filter Table to Duplicates Only'}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Batch Summary Bar if extractions are ready */}
          {successfulItems.length > 0 && (
            <div className="bg-gradient-to-r from-blue-900 to-indigo-950 text-white p-5 rounded-2xl shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-blue-800/60 mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-300">
                  Batch Financial & Extraction Summary
                </span>
                <span className="text-xs text-blue-200 font-mono">
                  {successfulItems.length} Extracted Documents
                </span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <div className="text-[11px] text-blue-200">Total Contract Value</div>
                  <div className="text-base font-bold text-white mt-0.5">
                    {formatAED(batchTotalRent)}
                  </div>
                  <div className="text-[10px] text-blue-300">
                    {batchContracts.length} Tenancy Contracts
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-blue-200">Total Rental Receipts</div>
                  <div className="text-base font-bold text-white mt-0.5">
                    {formatAED(batchTotalReceipts)}
                  </div>
                  <div className="text-[10px] text-blue-300">
                    {batchReceipts.length} Payment Receipts
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-blue-200">Total Purchase Expenses</div>
                  <div className="text-base font-bold text-white mt-0.5">
                    {formatAED(batchTotalInvoices)}
                  </div>
                  <div className="text-[10px] text-blue-300">
                    {batchInvoices.length} Maintenance Invoices
                  </div>
                </div>
                <div>
                  <div className="text-[11px] text-blue-200">Total 5% VAT (Deductible)</div>
                  <div className="text-base font-bold text-emerald-300 mt-0.5">
                    {formatAED(batchTotalVAT)}
                  </div>
                  <div className="text-[10px] text-emerald-200">Input Tax Credit</div>
                </div>
              </div>
            </div>
          )}

          {/* Table of Queue Items */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-4 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Extracted Documents Queue & Details
                </h4>
                {filterOnlyDuplicates && (
                  <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full border border-amber-200">
                    Showing Duplicates Only ({displayedItems.length})
                  </span>
                )}
              </div>
              <div className="flex items-center gap-3">
                {duplicateSummary.totalAlerts > 0 && (
                  <button
                    onClick={() => setFilterOnlyDuplicates(!filterOnlyDuplicates)}
                    className="text-xs font-medium text-amber-800 hover:text-amber-950 flex items-center gap-1"
                  >
                    <Filter className="w-3.5 h-3.5" />
                    {filterOnlyDuplicates ? 'Show All Items' : 'Filter Duplicates'}
                  </button>
                )}
                <span className="text-xs text-slate-400">Click Edit to modify or resolve duplicates</span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50/80 text-slate-500 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Document / File</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Status & Alerts</th>
                    <th className="py-3 px-4">Extracted Key Details & Duplications</th>
                    <th className="py-3 px-4">Collected Dates</th>
                    <th className="py-3 px-4 text-right">Amount (AED)</th>
                    <th className="py-3 px-4 text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {displayedItems.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-400">
                        {filterOnlyDuplicates ? 'No duplicate items match the filter.' : 'No files in queue.'}
                      </td>
                    </tr>
                  ) : (
                    displayedItems.map((item) => {
                      const isSuccess = item.status === 'success';
                      const c = item.extractedData?.contract;
                      const r = item.extractedData?.receipt;
                      const inv = item.extractedData?.invoice;

                      const itemAlerts = getItemDuplicationAlerts(
                        item,
                        items,
                        existingContracts,
                        existingReceipts,
                        existingInvoices
                      );
                      const hasDuplicates = itemAlerts.length > 0;

                      return (
                        <tr
                          key={item.id}
                          className={`transition-colors ${
                            hasDuplicates
                              ? 'bg-amber-50/50 hover:bg-amber-50/80 border-l-4 border-l-amber-500'
                              : 'hover:bg-slate-50/80'
                          }`}
                        >
                          <td className="py-3 px-4">
                            <div className="flex items-center gap-2.5">
                              <FileText
                                className={`w-4 h-4 shrink-0 ${
                                  hasDuplicates ? 'text-amber-500' : 'text-slate-400'
                                }`}
                              />
                              <div>
                                <div className="font-semibold text-slate-900 truncate max-w-[200px]">
                                  {item.fileName}
                                </div>
                                <div className="text-[10px] text-slate-400">
                                  {(item.fileSize / 1024).toFixed(1)} KB
                                </div>
                              </div>
                            </div>
                          </td>

                          <td className="py-3 px-4">
                            <span
                              className={`inline-block px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                                item.detectedType === 'contract'
                                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                                  : item.detectedType === 'receipt'
                                  ? 'bg-teal-50 text-teal-700 border border-teal-200'
                                  : item.detectedType === 'invoice'
                                  ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                                  : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {item.detectedType || item.targetType}
                            </span>
                          </td>

                          <td className="py-3 px-4">
                            <div className="space-y-1">
                              {item.status === 'pending' && (
                                <span className="text-[11px] text-slate-500 font-medium">Pending</span>
                              )}
                              {item.status === 'processing' && (
                                <span className="flex items-center gap-1.5 text-[11px] text-blue-600 font-medium">
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                  Parsing...
                                </span>
                              )}
                              {item.status === 'success' && (
                                <span className="flex items-center gap-1 text-[11px] text-emerald-600 font-semibold">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                  Extracted
                                </span>
                              )}
                              {item.status === 'error' && (
                                <span
                                  className="flex items-center gap-1 text-[11px] text-rose-600 font-medium"
                                  title={item.errorMessage}
                                >
                                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                                  Failed
                                </span>
                              )}

                              {/* Row warning badge */}
                              {hasDuplicates && (
                                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">
                                  <AlertTriangle className="w-2.5 h-2.5 text-amber-600 shrink-0" />
                                  Duplicate Warning
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="py-3 px-4 text-slate-600">
                            {isSuccess && item.detectedType === 'contract' && c && (
                              <div className="text-[11px] leading-relaxed">
                                <span className="font-semibold text-slate-900">{c.buildingName || 'Building'}</span> Unit {c.propertyNo || '-'}
                                <span className="text-slate-400"> | </span>
                                Tenant: <span className="text-slate-800">{c.tenantName || '-'}</span>
                                <span className="text-slate-400"> | </span>
                                Deposit: {formatAED(c.securityDeposit)}
                              </div>
                            )}

                            {isSuccess && item.detectedType === 'receipt' && r && (
                              <div className="text-[11px] leading-relaxed">
                                Voucher: <span className="font-semibold text-slate-900">{r.receiptNo || 'VCH-N/A'}</span>
                                <span className="text-slate-400"> | </span>
                                Bank: <span className="text-slate-800">{r.bankName || '-'}</span>
                                <span className="text-slate-400"> | </span>
                                Cheque #{r.chequeNo || '-'}
                              </div>
                            )}

                            {isSuccess && item.detectedType === 'invoice' && inv && (
                              <div className="text-[11px] leading-relaxed">
                                Supplier: <span className="font-semibold text-slate-900">{inv.supplierName || '-'}</span>
                                <span className="text-slate-400"> | </span>
                                Inv #{inv.invoiceNumber || 'TAX-N/A'}
                                <span className="text-slate-400"> | </span>
                                VAT 5%: {formatAED(inv.taxAmount)}
                              </div>
                            )}

                            {!isSuccess && <span className="text-slate-400">-</span>}

                            {/* Detailed duplicate alerts for this row */}
                            {hasDuplicates && (
                              <div className="mt-1.5 space-y-1">
                                {itemAlerts.map((alert, idx) => (
                                  <div
                                    key={idx}
                                    className="p-1.5 rounded-md bg-amber-100/90 text-amber-900 border border-amber-300 text-[10px] flex items-start gap-1.5"
                                  >
                                    <AlertTriangle className="w-3 h-3 text-amber-600 shrink-0 mt-0.5" />
                                    <div>
                                      <span className="font-bold">Duplicate {alert.label}:</span>{' '}
                                      <span className="font-mono underline">{alert.value}</span>
                                      <span className="text-amber-700 ml-1">({alert.details})</span>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </td>

                          <td className="py-3 px-4 text-slate-700">
                            {isSuccess && item.detectedType === 'contract' && c && (
                              <div className="text-[11px] space-y-1">
                                <div className="flex items-center gap-1">
                                  <span className="text-slate-400 font-normal">Start:</span>
                                  <span className="bg-emerald-50 text-emerald-800 font-bold px-1.5 py-0.5 rounded border border-emerald-200">
                                    {c.startDate || 'Pending'}
                                  </span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <span className="text-slate-400 font-normal">End:</span>
                                  <span className="bg-blue-50 text-blue-800 font-bold px-1.5 py-0.5 rounded border border-blue-200">
                                    {c.endDate || 'Pending'}
                                  </span>
                                </div>
                                {c.registrationDate && (
                                  <div className="text-[10px] text-slate-400">
                                    Reg: {c.registrationDate}
                                  </div>
                                )}
                              </div>
                            )}

                            {isSuccess && item.detectedType === 'receipt' && r && (
                              <div className="text-[11px]">
                                <span className="text-slate-400">Installment: </span>
                                <span className="bg-teal-50 text-teal-800 font-bold px-1.5 py-0.5 rounded border border-teal-200">
                                  {r.installmentDate || 'Pending'}
                                </span>
                              </div>
                            )}

                            {isSuccess && item.detectedType === 'invoice' && inv && (
                              <div className="text-[11px]">
                                <span className="text-slate-400">Invoice Date: </span>
                                <span className="bg-indigo-50 text-indigo-800 font-bold px-1.5 py-0.5 rounded border border-indigo-200">
                                  {inv.invoiceDate || 'Pending'}
                                </span>
                              </div>
                            )}

                            {!isSuccess && <span className="text-slate-400">-</span>}
                          </td>

                          <td className="py-3 px-4 text-right font-bold text-slate-900">
                            {isSuccess && item.detectedType === 'contract' && formatAED(c?.contractAmount)}
                            {isSuccess && item.detectedType === 'receipt' && formatAED(r?.amount)}
                            {isSuccess && item.detectedType === 'invoice' && formatAED(inv?.totalInvoiceAmount)}
                            {!isSuccess && '-'}
                          </td>

                          <td className="py-3 px-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {isSuccess && (
                                <button
                                  onClick={() => setEditingItem(item)}
                                  className="p-1.5 text-slate-500 hover:text-blue-600 rounded-lg hover:bg-blue-50 transition"
                                  title="Inspect & Edit Data"
                                >
                                  <Edit2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                              <button
                                onClick={() => removeItem(item.id)}
                                className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                                title="Remove item"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Item Quick-Edit Modal */}
      {editingItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Inspect & Edit Extracted Data
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">{editingItem.fileName}</p>
              </div>
              <button
                onClick={() => setEditingItem(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            {/* Modal top duplication warning banner if applicable */}
            {editingItemAlerts.length > 0 && (
              <div className="mt-4 p-3 bg-amber-50 border border-amber-300 rounded-2xl text-amber-950 text-xs flex items-start gap-2.5">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <div className="font-bold text-amber-950">Duplication Warning for this Document</div>
                  {editingItemAlerts.map((a, idx) => (
                    <div key={idx} className="text-[11px] text-amber-900 leading-tight">
                      • <span className="font-semibold">{a.label} ({a.value}):</span> {a.details}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-4 space-y-4">
              {/* Type selector */}
              <div>
                <label className="text-xs font-semibold text-slate-700">Document Type</label>
                <select
                  value={editingItem.detectedType}
                  onChange={(e) =>
                    setEditingItem({
                      ...editingItem,
                      detectedType: e.target.value as any,
                    })
                  }
                  className="mt-1 w-full text-xs p-2.5 rounded-xl border border-slate-200 bg-slate-50"
                >
                  <option value="contract">UAE Tenancy Contract (Ejari)</option>
                  <option value="receipt">Rental Receipt / Cheque</option>
                  <option value="invoice">Purchase Tax Invoice (5% VAT)</option>
                </select>
              </div>

              {/* Contract fields */}
              {editingItem.detectedType === 'contract' && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="text-slate-500">Contract / Ejari No</label>
                    <input
                      type="text"
                      value={editingItem.extractedData?.contract?.contractNo || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.contractNo = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Owner Name</label>
                    <input
                      type="text"
                      value={editingItem.extractedData?.contract?.ownerName || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.ownerName = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Building Name</label>
                    <input
                      type="text"
                      value={editingItem.extractedData?.contract?.buildingName || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.buildingName = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>

                  {/* Property / Unit No with Duplication Warning */}
                  <div>
                    <div className="flex items-center justify-between">
                      <label className="text-slate-500">Property / Unit No</label>
                      {editingUnitAlert && (
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded border border-amber-200">
                          Duplicate Unit
                        </span>
                      )}
                    </div>
                    <input
                      type="text"
                      value={editingItem.extractedData?.contract?.propertyNo || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.propertyNo = e.target.value;
                        setEditingItem(updated);
                      }}
                      className={`mt-1 w-full p-2 rounded-lg border ${
                        editingUnitAlert
                          ? 'border-amber-400 bg-amber-50/50 ring-2 ring-amber-300/40 font-semibold text-amber-950'
                          : 'border-slate-200'
                      }`}
                    />
                    {editingUnitAlert && (
                      <div className="mt-1 flex items-start gap-1.5 text-[11px] text-amber-900 bg-amber-50 p-2 rounded-lg border border-amber-200 leading-tight">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-600 mt-0.5" />
                        <div>
                          <span className="font-bold">Unit Duplication: </span>
                          <span>{editingUnitAlert.details}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* UAE VAT Law Contract Classification */}
                  <div className="col-span-2 p-3 bg-purple-50/60 rounded-xl border border-purple-200">
                    <label className="text-xs font-bold text-purple-950 block mb-1">
                      Tenancy Contract Type (UAE VAT Law)
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const updated = { ...editingItem };
                          if (!updated.extractedData) updated.extractedData = {};
                          if (!updated.extractedData.contract) updated.extractedData.contract = {};
                          updated.extractedData.contract.contractType = 'Commercial';
                          updated.extractedData.contract.propertyType = 'Commercial';
                          setEditingItem(updated);
                        }}
                        className={`p-2 rounded-lg border text-left text-xs ${
                          isCommercialContract(editingItem.extractedData?.contract?.contractType || editingItem.extractedData?.contract?.propertyType)
                            ? 'bg-purple-600 text-white border-purple-700 font-bold'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div>Commercial (5% VAT)</div>
                        <div className="text-[10px] opacity-80">Offices, Shops, Retail</div>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const updated = { ...editingItem };
                          if (!updated.extractedData) updated.extractedData = {};
                          if (!updated.extractedData.contract) updated.extractedData.contract = {};
                          updated.extractedData.contract.contractType = 'Residence';
                          updated.extractedData.contract.propertyType = 'Residential';
                          setEditingItem(updated);
                        }}
                        className={`p-2 rounded-lg border text-left text-xs ${
                          !isCommercialContract(editingItem.extractedData?.contract?.contractType || editingItem.extractedData?.contract?.propertyType)
                            ? 'bg-blue-600 text-white border-blue-700 font-bold'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                        }`}
                      >
                        <div>Residence (0% VAT)</div>
                        <div className="text-[10px] opacity-80">Residential Accommodation</div>
                      </button>
                    </div>
                    {/* Live VAT Calculation Preview */}
                    {(() => {
                      const isComm = isCommercialContract(editingItem.extractedData?.contract?.contractType || editingItem.extractedData?.contract?.propertyType);
                      const rent = Number(editingItem.extractedData?.contract?.actualAnnualAmount) || Number(editingItem.extractedData?.contract?.contractAmount) || 0;
                      const vat = isComm ? Math.round(rent * 0.05 * 100) / 100 : 0;
                      const total = Math.round((rent + vat) * 100) / 100;
                      return (
                        <div className="mt-2 pt-2 border-t border-purple-200/80 flex items-center justify-between text-[11px]">
                          <span className="text-purple-900 font-medium">
                            {isComm ? `5% VAT on Actual Rent: +${formatAED(vat)}` : '0% VAT Exempt under UAE VAT Law'}
                          </span>
                          <span className="font-bold text-slate-900">
                            Gross with VAT: {formatAED(total)}
                          </span>
                        </div>
                      );
                    })()}
                  </div>

                  <div>
                    <label className="text-slate-500">Tenant Name</label>
                    <input
                      type="text"
                      value={editingItem.extractedData?.contract?.tenantName || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.tenantName = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Contract Amount (AED)</label>
                    <input
                      type="number"
                      value={editingItem.extractedData?.contract?.contractAmount || 0}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.contractAmount = Number(e.target.value);
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200 font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Actual Annual Amount (AED)</label>
                    <input
                      type="number"
                      value={editingItem.extractedData?.contract?.actualAnnualAmount || 0}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.actualAnnualAmount = Number(e.target.value);
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200 font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Security Deposit (AED)</label>
                    <input
                      type="number"
                      value={editingItem.extractedData?.contract?.securityDeposit || 0}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.securityDeposit = Number(e.target.value);
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Start Date</label>
                    <input
                      type="date"
                      value={editingItem.extractedData?.contract?.startDate || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.startDate = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">End Date</label>
                    <input
                      type="date"
                      value={editingItem.extractedData?.contract?.endDate || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.contract) updated.extractedData.contract = {};
                        updated.extractedData.contract.endDate = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                </div>
              )}

              {/* Receipt fields */}
              {editingItem.detectedType === 'receipt' && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  {/* Receipt Number with Duplication Warning */}
                  <div>
                    <div className="flex items-center justify-between">
                      <label className="text-slate-500">Receipt Voucher / Number</label>
                      {editingReceiptAlert && (
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded border border-amber-200">
                          Duplicate Receipt
                        </span>
                      )}
                    </div>
                    <input
                      type="text"
                      value={editingItem.extractedData?.receipt?.receiptNo || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.receipt) updated.extractedData.receipt = {};
                        updated.extractedData.receipt.receiptNo = e.target.value;
                        setEditingItem(updated);
                      }}
                      className={`mt-1 w-full p-2 rounded-lg border ${
                        editingReceiptAlert
                          ? 'border-amber-400 bg-amber-50/50 ring-2 ring-amber-300/40 font-semibold text-amber-950'
                          : 'border-slate-200'
                      }`}
                      placeholder="e.g. RCP-0012, VCH-2024-01"
                    />
                    {editingReceiptAlert && (
                      <div className="mt-1 flex items-start gap-1.5 text-[11px] text-amber-900 bg-amber-50 p-2 rounded-lg border border-amber-200 leading-tight">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-600 mt-0.5" />
                        <div>
                          <span className="font-bold">Receipt Duplication: </span>
                          <span>{editingReceiptAlert.details}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="text-slate-500">Installment Date</label>
                    <input
                      type="date"
                      value={editingItem.extractedData?.receipt?.installmentDate || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.receipt) updated.extractedData.receipt = {};
                        updated.extractedData.receipt.installmentDate = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Amount (AED)</label>
                    <input
                      type="number"
                      value={editingItem.extractedData?.receipt?.amount || 0}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.receipt) updated.extractedData.receipt = {};
                        updated.extractedData.receipt.amount = Number(e.target.value);
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200 font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Cheque / Ref No</label>
                    <input
                      type="text"
                      value={editingItem.extractedData?.receipt?.chequeNo || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.receipt) updated.extractedData.receipt = {};
                        updated.extractedData.receipt.chequeNo = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="text-slate-500">Bank Name</label>
                    <input
                      type="text"
                      value={editingItem.extractedData?.receipt?.bankName || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.receipt) updated.extractedData.receipt = {};
                        updated.extractedData.receipt.bankName = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                </div>
              )}

              {/* Invoice fields */}
              {editingItem.detectedType === 'invoice' && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  {/* Invoice Number with Duplication Warning */}
                  <div>
                    <div className="flex items-center justify-between">
                      <label className="text-slate-500">Invoice Number</label>
                      {editingInvoiceAlert && (
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded border border-amber-200">
                          Duplicate Invoice
                        </span>
                      )}
                    </div>
                    <input
                      type="text"
                      value={editingItem.extractedData?.invoice?.invoiceNumber || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.invoice) updated.extractedData.invoice = {};
                        updated.extractedData.invoice.invoiceNumber = e.target.value;
                        setEditingItem(updated);
                      }}
                      className={`mt-1 w-full p-2 rounded-lg border ${
                        editingInvoiceAlert
                          ? 'border-amber-400 bg-amber-50/50 ring-2 ring-amber-300/40 font-semibold text-amber-950'
                          : 'border-slate-200'
                      }`}
                    />
                    {editingInvoiceAlert && (
                      <div className="mt-1 flex items-start gap-1.5 text-[11px] text-amber-900 bg-amber-50 p-2 rounded-lg border border-amber-200 leading-tight">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-amber-600 mt-0.5" />
                        <div>
                          <span className="font-bold">Invoice Duplication: </span>
                          <span>{editingInvoiceAlert.details}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="text-slate-500">Invoice Date</label>
                    <input
                      type="date"
                      value={editingItem.extractedData?.invoice?.invoiceDate || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.invoice) updated.extractedData.invoice = {};
                        updated.extractedData.invoice.invoiceDate = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Supplier Name</label>
                    <input
                      type="text"
                      value={editingItem.extractedData?.invoice?.supplierName || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.invoice) updated.extractedData.invoice = {};
                        updated.extractedData.invoice.supplierName = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Supplier TRN (UAE 15-digit)</label>
                    <input
                      type="text"
                      value={editingItem.extractedData?.invoice?.supplierTrn || ''}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.invoice) updated.extractedData.invoice = {};
                        updated.extractedData.invoice.supplierTrn = e.target.value;
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Total Invoice Amount (AED)</label>
                    <input
                      type="number"
                      value={editingItem.extractedData?.invoice?.totalInvoiceAmount || 0}
                      onChange={(e) => {
                        const val = Number(e.target.value);
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.invoice) updated.extractedData.invoice = {};
                        updated.extractedData.invoice.totalInvoiceAmount = val;
                        updated.extractedData.invoice.taxAmount = +(val - val / 1.05).toFixed(2);
                        updated.extractedData.invoice.netAmount = +(val / 1.05).toFixed(2);
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200 font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-slate-500">Tax Amount (5% VAT AED)</label>
                    <input
                      type="number"
                      value={editingItem.extractedData?.invoice?.taxAmount || 0}
                      onChange={(e) => {
                        const updated = { ...editingItem };
                        if (!updated.extractedData) updated.extractedData = {};
                        if (!updated.extractedData.invoice) updated.extractedData.invoice = {};
                        updated.extractedData.invoice.taxAmount = Number(e.target.value);
                        setEditingItem(updated);
                      }}
                      className="mt-1 w-full p-2 rounded-lg border border-slate-200"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="mt-6 flex justify-end gap-2.5">
              <button
                onClick={() => setEditingItem(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setItems((prev) =>
                    prev.map((i) => (i.id === editingItem.id ? editingItem : i))
                  );
                  setEditingItem(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition"
              >
                Save Changes to Item
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Duplication Warning Confirmation Modal Before Saving */}
      {showDuplicateWarningModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-amber-300 animate-in zoom-in-95 duration-200">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">
              Potential Duplicate Records Detected
            </h3>
            <p className="text-xs text-slate-600 mt-1 leading-relaxed">
              We identified <strong className="text-amber-900">{duplicateSummary.totalAlerts} potential duplicate field(s)</strong> matching existing database records or other files in this batch. Saving duplicates may cause double-entry errors in your Zoho Books, Tally Prime, or Ejari lease ledgers.
            </p>

            {/* List duplicate items */}
            <div className="mt-4 max-h-56 overflow-y-auto space-y-2 pr-1">
              {duplicateSummary.duplicateItems.map(({ item, alerts }, i) => (
                <div key={i} className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl text-xs space-y-1.5">
                  <div className="font-bold text-slate-900 flex items-center justify-between">
                    <span className="truncate max-w-[280px]">{item.fileName}</span>
                    <span className="text-[10px] uppercase font-bold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded">
                      {item.detectedType}
                    </span>
                  </div>
                  {alerts.map((a, j) => (
                    <div key={j} className="text-amber-900 text-[11px] flex items-start gap-1 leading-tight">
                      <span className="font-bold shrink-0">{a.label} ({a.value}):</span>
                      <span>{a.details}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>

            <div className="mt-6 flex flex-col sm:flex-row items-center justify-end gap-2.5">
              <button
                onClick={() => setShowDuplicateWarningModal(false)}
                className="w-full sm:w-auto px-4 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Cancel & Review Duplicates
              </button>
              <button
                onClick={saveAllToDatabase}
                className="w-full sm:w-auto px-4 py-2.5 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs"
              >
                <Save className="w-3.5 h-3.5" />
                Proceed & Save Anyway
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Camera Capture Modal */}
      <CameraCaptureModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCapture={handleCapturedFile}
      />
    </div>
  );
};
