import React, { useState, useMemo } from 'react';
import {
  Building2,
  Receipt,
  FileSpreadsheet,
  TrendingUp,
  ShieldCheck,
  Percent,
  Sparkles,
  ChevronRight,
  DollarSign,
  Download,
  Filter,
  X,
  Scale,
  Briefcase,
  Home,
  CheckCircle2,
  AlertCircle,
  Landmark,
} from 'lucide-react';
import { TenancyContract, RentalReceipt, PurchaseTaxInvoice } from '../types';
import { formatAED, exportToExcel, exportToPDF } from '../utils/exportUtils';
import { isCommercialContract } from '../utils/vatCalculator';

interface DashboardProps {
  contracts: TenancyContract[];
  receipts: RentalReceipt[];
  invoices: PurchaseTaxInvoice[];
  onNavigateTab: (tab: any) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  contracts,
  receipts,
  invoices,
  onNavigateTab,
}) => {
  const [selectedProperty, setSelectedProperty] = useState<string>('all');

  // Extract unique properties from contracts, receipts, and invoices
  const propertyOptions = useMemo(() => {
    const propMap = new Map<string, { contracts: number; receipts: number; invoices: number }>();

    contracts.forEach((c) => {
      const name = c.buildingName?.trim();
      if (name) {
        const item = propMap.get(name) || { contracts: 0, receipts: 0, invoices: 0 };
        item.contracts++;
        propMap.set(name, item);
      }
    });

    receipts.forEach((r) => {
      const name = r.propertyRef?.trim();
      if (name) {
        const item = propMap.get(name) || { contracts: 0, receipts: 0, invoices: 0 };
        item.receipts++;
        propMap.set(name, item);
      }
    });

    invoices.forEach((i) => {
      const name = i.buildingRef?.trim();
      if (name) {
        const item = propMap.get(name) || { contracts: 0, receipts: 0, invoices: 0 };
        item.invoices++;
        propMap.set(name, item);
      }
    });

    return Array.from(propMap.entries())
      .map(([name, counts]) => ({ name, ...counts }))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [contracts, receipts, invoices]);

  // Filter datasets based on selected property
  const filteredContracts = useMemo(() => {
    if (selectedProperty === 'all') return contracts;
    const filter = selectedProperty.toLowerCase();
    return contracts.filter(
      (c) =>
        (c.buildingName && c.buildingName.toLowerCase().includes(filter)) ||
        filter.includes((c.buildingName || '').toLowerCase())
    );
  }, [contracts, selectedProperty]);

  const filteredReceipts = useMemo(() => {
    if (selectedProperty === 'all') return receipts;
    const filter = selectedProperty.toLowerCase();
    return receipts.filter(
      (r) =>
        (r.propertyRef && r.propertyRef.toLowerCase().includes(filter)) ||
        filter.includes((r.propertyRef || '').toLowerCase())
    );
  }, [receipts, selectedProperty]);

  const filteredInvoices = useMemo(() => {
    if (selectedProperty === 'all') return invoices;
    const filter = selectedProperty.toLowerCase();
    return invoices.filter(
      (i) =>
        (i.buildingRef && i.buildingRef.toLowerCase().includes(filter)) ||
        filter.includes((i.buildingRef || '').toLowerCase())
    );
  }, [invoices, selectedProperty]);

  // KPI Calculations on filtered data
  const totalContractAmount = filteredContracts.reduce((acc, c) => acc + (c.contractAmount || 0), 0);
  const totalActualAnnual = filteredContracts.reduce((acc, c) => acc + (c.actualAnnualAmount || 0), 0);
  const totalSecurityDeposit = filteredContracts.reduce((acc, c) => acc + (c.securityDeposit || 0), 0);
  const totalReceipts = filteredReceipts.reduce((acc, r) => acc + (r.amount || 0), 0);
  const totalMaintenance = filteredInvoices.reduce(
    (acc, i) => acc + (i.netAmount || (i.totalInvoiceAmount - (i.taxAmount || 0)) || 0),
    0
  );
  const totalGrossInvoices = filteredInvoices.reduce((acc, i) => acc + (i.totalInvoiceAmount || 0), 0);

  // Input VAT on purchase invoices (5% recoverable tax under UAE VAT Law)
  const totalInputVAT = filteredInvoices.reduce((acc, i) => acc + (i.taxAmount || 0), 0);

  // Total Net Income requested: Total Actual Annual Rent - Maintenance Expenses
  const totalNetIncome = totalActualAnnual - totalMaintenance;

  // UAE VAT Tenancy Calculations:
  // - Commercial Tenancy: 5% VAT on the actual annual rent
  // - Residence Tenancy: 0% VAT (Exempt from VAT under UAE VAT Law)
  let totalVatOnActualAnnualRent = 0;
  let commercialActualAnnualRent = 0;
  let residenceActualAnnualRent = 0;
  let commercialContractsCount = 0;
  let residenceContractsCount = 0;

  filteredContracts.forEach((c) => {
    const rent = c.actualAnnualAmount || c.contractAmount || 0;
    const isComm = isCommercialContract(c.contractType || c.propertyType);
    if (isComm) {
      commercialContractsCount++;
      commercialActualAnnualRent += rent;
      const vat = c.vatAmount != null ? c.vatAmount : Math.round(rent * 0.05 * 100) / 100;
      totalVatOnActualAnnualRent += vat;
    } else {
      residenceContractsCount++;
      residenceActualAnnualRent += rent;
    }
  });

  totalVatOnActualAnnualRent = Math.round(totalVatOnActualAnnualRent * 100) / 100;

  // Net FTA Payment = total vat on the actual annual rent - input vat
  const netFtaPayment = Math.round((totalVatOnActualAnnualRent - totalInputVAT) * 100) / 100;

  // Monthly trends calculation (Jan - Dec)
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthlyData = months.map((m, idx) => {
    const monthContracts = filteredContracts.filter((c) => {
      if (!c.startDate) return false;
      const d = new Date(c.startDate);
      return !isNaN(d.getTime()) && d.getMonth() === idx;
    });

    const monthReceipts = filteredReceipts.filter((r) => {
      if (!r.installmentDate) return false;
      const d = new Date(r.installmentDate);
      return !isNaN(d.getTime()) && d.getMonth() === idx;
    });

    const monthInvoices = filteredInvoices.filter((i) => {
      if (!i.invoiceDate) return false;
      const d = new Date(i.invoiceDate);
      return !isNaN(d.getTime()) && d.getMonth() === idx;
    });

    const contractAmt = monthContracts.reduce((acc, c) => acc + (c.contractAmount || 0), 0);
    const annualAmt = monthContracts.reduce((acc, c) => acc + (c.actualAnnualAmount || 0), 0);
    const receiptAmt = monthReceipts.reduce((acc, r) => acc + (r.amount || 0), 0);
    const expAmt = monthInvoices.reduce((acc, i) => acc + (i.totalInvoiceAmount || 0), 0);

    return {
      month: m,
      contractAmt,
      annualAmt,
      receiptAmt,
      expAmt,
    };
  });

  const maxVal = Math.max(
    ...monthlyData.map((d) => Math.max(d.contractAmt, d.annualAmt, d.receiptAmt, 10000))
  );

  const [activeTooltip, setActiveTooltip] = useState<{
    month: string;
    contractAmt: number;
    annualAmt: number;
    receiptAmt: number;
    expAmt: number;
  } | null>(null);

  const hasData = filteredContracts.length > 0 || filteredReceipts.length > 0 || filteredInvoices.length > 0;
  const isFiltered = selectedProperty !== 'all';

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Welcome / Header with Property Filter & Export */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-3 border-b border-slate-200/80">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-semibold tracking-wider uppercase text-blue-700 bg-blue-50 px-2.5 py-0.5 rounded-full border border-blue-200/60">
              Dubai Real Estate Authority (DRE) • Ejari Aligned
            </span>
            <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200/60 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              UAE VAT Law: Commercial 5% • Residence 0%
            </span>
          </div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-slate-900 tracking-tight mt-1.5">
            Executive Property Portfolio Dashboard
          </h1>
          <p className="text-xs md:text-sm text-slate-500 mt-0.5">
            Real-time analytics for UAE tenancy contracts, rental installments, and VAT tax returns (FTA Form 201).
          </p>
        </div>

        {/* Property Filter Dropdown & Export Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Property Wise Dropdown Filter */}
          <div className="relative min-w-[220px]">
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300/90 rounded-xl shadow-xs hover:border-blue-400 transition-colors">
              <Building2 className="w-4 h-4 text-blue-600 shrink-0" />
              <div className="flex-1">
                <div className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">
                  Property Filter
                </div>
                <select
                  value={selectedProperty}
                  onChange={(e) => setSelectedProperty(e.target.value)}
                  className="w-full text-xs font-semibold text-slate-800 bg-transparent border-none outline-hidden cursor-pointer p-0"
                >
                  <option value="all">🏢 All Properties ({propertyOptions.length} Buildings)</option>
                  {propertyOptions.map((p) => (
                    <option key={p.name} value={p.name}>
                      {p.name} ({p.contracts} contracts, {p.invoices} bills)
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <button
            onClick={() => exportToPDF(filteredContracts, filteredReceipts, filteredInvoices)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-600" />
            PDF Report
          </button>
          <button
            onClick={() => exportToExcel(filteredContracts, filteredReceipts, filteredInvoices, 'consolidated')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            Excel Export
          </button>
        </div>
      </div>

      {/* Active Filter Strip if property is selected */}
      {isFiltered && (
        <div className="bg-blue-50/90 border border-blue-200 rounded-xl px-4 py-2.5 flex items-center justify-between text-xs text-blue-900 shadow-xs">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-blue-600" />
            <span>
              Filtered by Property: <strong className="font-bold underline">{selectedProperty}</strong>
            </span>
            <span className="text-blue-600/70 text-[11px]">
              ({filteredContracts.length} Tenancy Contracts • {filteredReceipts.length} Installments • {filteredInvoices.length} Invoices)
            </span>
          </div>
          <button
            onClick={() => setSelectedProperty('all')}
            className="flex items-center gap-1 text-[11px] font-bold text-blue-700 bg-white hover:bg-blue-100/60 px-2.5 py-1 rounded-lg border border-blue-300 transition"
          >
            <X className="w-3.5 h-3.5" />
            Reset to All Properties
          </button>
        </div>
      )}

      {/* DUAL EXECUTIVE BANNERS: Total Net Income & Net FTA Payment */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Banner 1: Total Net Income Formula */}
        <div className="bg-gradient-to-r from-[#0A2540] via-[#0E2F56] to-[#0A2540] text-white rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-800 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 flex items-center justify-center font-bold shrink-0">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-slate-200 uppercase tracking-wider block">
                  Total Net Income
                </span>
                <span className="text-[10px] font-mono text-emerald-300">
                  Total Actual Annual Rent − Maintenance Expenses
                </span>
              </div>
            </div>
            <span className="text-[10px] font-medium bg-white/10 px-2 py-0.5 rounded-full text-slate-300">
              Run-Rate
            </span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <div>
              <div className="text-xs text-slate-300">
                {formatAED(totalActualAnnual)} (Rent) − {formatAED(totalMaintenance)} (Maint.)
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">
                Net property operating yield for {isFiltered ? selectedProperty : 'portfolio'}
              </div>
            </div>
            <div
              className={`text-2xl sm:text-3xl font-black tracking-tight ${
                totalNetIncome >= 0 ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {formatAED(totalNetIncome)}
            </div>
          </div>
        </div>

        {/* Banner 2: UAE Federal Tax Authority (FTA) Net VAT Settlement */}
        <div className="bg-gradient-to-r from-[#1E1B4B] via-[#2E1065] to-[#1E1B4B] text-white rounded-2xl p-4 sm:p-5 shadow-sm border border-purple-900/60 flex flex-col justify-between">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-indigo-500/30 text-indigo-300 border border-indigo-400/30 flex items-center justify-center font-bold shrink-0">
                <Scale className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold text-slate-200 uppercase tracking-wider">
                    Net FTA Payment
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      netFtaPayment > 0
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                        : netFtaPayment < 0
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : 'bg-slate-500/20 text-slate-300 border border-slate-500/30'
                    }`}
                  >
                    {netFtaPayment > 0
                      ? 'Net Payable to FTA'
                      : netFtaPayment < 0
                      ? 'Net FTA Refund / Credit'
                      : 'Balanced Tax Position'}
                  </span>
                </div>
                <span className="text-[10px] font-mono text-purple-200">
                  Total VAT on Actual Annual Rent − Input VAT
                </span>
              </div>
            </div>
            <span className="text-[10px] font-medium bg-purple-500/20 text-purple-200 px-2 py-0.5 rounded-md border border-purple-400/20">
              UAE Form 201
            </span>
          </div>

          <div className="mt-3 flex items-baseline justify-between">
            <div>
              <div className="text-xs text-purple-200">
                {formatAED(totalVatOnActualAnnualRent)} (Output VAT) − {formatAED(totalInputVAT)} (Input VAT)
              </div>
              <div className="text-[10px] text-purple-300/80 mt-0.5">
                {netFtaPayment > 0
                  ? 'Payment due to UAE Federal Tax Authority'
                  : netFtaPayment < 0
                  ? 'Recoverable input tax exceeds output VAT (Refundable)'
                  : 'Zero net VAT balance'}
              </div>
            </div>
            <div
              className={`text-2xl sm:text-3xl font-black tracking-tight ${
                netFtaPayment > 0
                  ? 'text-rose-400'
                  : netFtaPayment < 0
                  ? 'text-emerald-400'
                  : 'text-slate-300'
              }`}
            >
              {formatAED(netFtaPayment)}
            </div>
          </div>
        </div>
      </div>

      {/* Comprehensive KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8 gap-3.5">
        {/* 1. Contract Value */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-blue-300 transition-all group">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-medium text-slate-500">Contract Value</span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600 group-hover:scale-105 transition-transform">
              <Building2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-base font-bold text-slate-900 tracking-tight">
            {formatAED(totalContractAmount)}
          </div>
          <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center justify-between">
            <span>{filteredContracts.length} Contracts</span>
            <span
              className="text-blue-600 font-semibold cursor-pointer hover:underline"
              onClick={() => onNavigateTab('contracts')}
            >
              View &rarr;
            </span>
          </div>
        </div>

        {/* 2. Actual Annual Rent */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-emerald-300 transition-all group">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-medium text-slate-500">Actual Annual Rent</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-600 group-hover:scale-105 transition-transform">
              <TrendingUp className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-base font-bold text-slate-900 tracking-tight">
            {formatAED(totalActualAnnual)}
          </div>
          <div className="text-[10px] font-medium text-emerald-600 mt-1">
            Annual Run-Rate
          </div>
        </div>

        {/* 3. Maintenance Expenses */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-rose-300 transition-all group">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-medium text-slate-500">Maintenance Exp</span>
            <div className="w-7 h-7 rounded-lg bg-rose-50 flex items-center justify-center text-rose-600 group-hover:scale-105 transition-transform">
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-base font-bold text-slate-900 tracking-tight">
            {formatAED(totalMaintenance)}
          </div>
          <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center justify-between">
            <span>Net of VAT</span>
            <span
              className="text-rose-600 font-semibold cursor-pointer hover:underline"
              onClick={() => onNavigateTab('invoices')}
            >
              View &rarr;
            </span>
          </div>
        </div>

        {/* 4. Total Net Income */}
        <div className="bg-gradient-to-br from-emerald-50/80 to-white p-3.5 rounded-2xl border-2 border-emerald-400/80 shadow-xs hover:border-emerald-500 transition-all group">
          <div className="flex items-center justify-between text-emerald-700 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
              Total Net Income
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500 text-white flex items-center justify-center font-bold text-xs shadow-xs group-hover:scale-105 transition-transform">
              =
            </div>
          </div>
          <div
            className={`text-base font-extrabold tracking-tight ${
              totalNetIncome >= 0 ? 'text-emerald-900' : 'text-rose-600'
            }`}
          >
            {formatAED(totalNetIncome)}
          </div>
          <div className="text-[10px] font-semibold text-emerald-700 mt-1 truncate" title="Annual Rent - Maintenance Exp">
            Rent − Maintenance
          </div>
        </div>

        {/* 5. Total VAT on Actual Annual Rent (Commercial Leases 5%) */}
        <div className="bg-gradient-to-br from-purple-50/90 to-white p-3.5 rounded-2xl border border-purple-300 shadow-xs hover:border-purple-400 transition-all group">
          <div className="flex items-center justify-between text-purple-700 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-purple-900 truncate" title="Total VAT on Actual Annual Rent">
              VAT on Annual Rent
            </span>
            <div className="w-7 h-7 rounded-lg bg-purple-100 flex items-center justify-center text-purple-700 group-hover:scale-105 transition-transform font-bold text-xs">
              5%
            </div>
          </div>
          <div className="text-base font-bold text-purple-950 tracking-tight">
            {formatAED(totalVatOnActualAnnualRent)}
          </div>
          <div className="text-[10px] font-medium text-purple-700 mt-1 flex items-center justify-between">
            <span>{commercialContractsCount} Comm. (5%)</span>
            <span className="text-slate-400">{residenceContractsCount} Res. (0%)</span>
          </div>
        </div>

        {/* 6. Input VAT on Invoices */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-indigo-300 transition-all group">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-medium text-slate-500">Input VAT</span>
            <div className="w-7 h-7 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600 group-hover:scale-105 transition-transform">
              <Percent className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-base font-bold text-slate-900 tracking-tight">
            {formatAED(totalInputVAT)}
          </div>
          <div className="text-[10px] font-medium text-indigo-600 mt-1 flex items-center justify-between">
            <span>Box 9 Purchases</span>
            <span
              className="text-indigo-600 font-semibold cursor-pointer hover:underline"
              onClick={() => onNavigateTab('invoices')}
            >
              View &rarr;
            </span>
          </div>
        </div>

        {/* 7. Net FTA Payment Card */}
        <div className="bg-gradient-to-br from-indigo-50/90 to-white p-3.5 rounded-2xl border-2 border-indigo-400/80 shadow-xs hover:border-indigo-500 transition-all group">
          <div className="flex items-center justify-between text-indigo-800 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-900 truncate" title="Net FTA Payment = Total VAT on Rent - Input VAT">
              Net FTA Payment
            </span>
            <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-xs group-hover:scale-105 transition-transform">
              FTA
            </div>
          </div>
          <div
            className={`text-base font-extrabold tracking-tight ${
              netFtaPayment > 0
                ? 'text-rose-600'
                : netFtaPayment < 0
                ? 'text-emerald-700'
                : 'text-slate-900'
            }`}
          >
            {formatAED(netFtaPayment)}
          </div>
          <div className="text-[10px] font-semibold text-indigo-700 mt-1 truncate">
            {netFtaPayment > 0 ? 'Payable to FTA' : netFtaPayment < 0 ? 'FTA Credit / Refund' : 'Settled'}
          </div>
        </div>

        {/* 8. Rental Receipts Cleared */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-xs hover:border-teal-300 transition-all group">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-medium text-slate-500">Receipts Cleared</span>
            <div className="w-7 h-7 rounded-lg bg-teal-50 flex items-center justify-center text-teal-600 group-hover:scale-105 transition-transform">
              <Receipt className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="text-base font-bold text-slate-900 tracking-tight">
            {formatAED(totalReceipts)}
          </div>
          <div className="text-[10px] font-medium text-slate-400 mt-1 flex items-center justify-between">
            <span>{filteredReceipts.length} Cheques</span>
            <span
              className="text-teal-600 font-semibold cursor-pointer hover:underline"
              onClick={() => onNavigateTab('receipts')}
            >
              View &rarr;
            </span>
          </div>
        </div>
      </div>

      {/* UAE Bank Reconciliation Gateway Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-[#0A2540] text-white rounded-2xl p-4 sm:p-5 shadow-xs border border-blue-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-blue-500/20 text-blue-300 border border-blue-400/30 flex items-center justify-center font-bold shrink-0">
            <Landmark className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-extrabold tracking-tight">
                UAE Bank Reconciliation Statement (BRS)
              </span>
              <span className="text-[10px] font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-2 py-0.5 rounded-full">
                Active Audit Tool
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5">
              Upload bank statements (Emirates NBD, ADCB, DIB, FAB, etc.) to reconcile debits with maintenance invoices & payments and credits with rent receipts.
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('bank-reconciliation')}
          className="px-4 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition shadow-xs flex items-center justify-center gap-2 shrink-0"
        >
          Open Bank Reconciliation
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Interactive Trends & Graphs Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Monthly Trend Chart (2 columns) */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Monthly Contract Value & Actual Annual Rent Trends
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Comparison between total agreed contract amounts and actual annual rent distribution
                  {isFiltered ? ` for ${selectedProperty}` : ' across all properties'}.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <span className="w-3 h-3 rounded-sm bg-blue-600 inline-block"></span>
                  <span>Contract Amt</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-slate-600">
                  <span className="w-3 h-3 rounded-sm bg-emerald-500 inline-block"></span>
                  <span>Actual Rent</span>
                </div>
              </div>
            </div>

            {/* Interactive SVG Bar & Trend Chart */}
            <div className="relative mt-6 h-64 w-full">
              {/* Background horizontal grid lines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none text-[10px] text-slate-300">
                <div className="border-b border-slate-100 w-full flex justify-between">
                  <span>{formatAED(maxVal)}</span>
                </div>
                <div className="border-b border-slate-100 w-full flex justify-between">
                  <span>{formatAED(maxVal * 0.75)}</span>
                </div>
                <div className="border-b border-slate-100 w-full flex justify-between">
                  <span>{formatAED(maxVal * 0.5)}</span>
                </div>
                <div className="border-b border-slate-100 w-full flex justify-between">
                  <span>{formatAED(maxVal * 0.25)}</span>
                </div>
                <div className="border-b border-slate-200 w-full flex justify-between">
                  <span>AED 0</span>
                </div>
              </div>

              {/* Bars container */}
              <div className="absolute inset-x-0 bottom-4 top-2 flex items-end justify-between px-2 gap-1 sm:gap-2">
                {monthlyData.map((d) => {
                  const contractHeightPct = maxVal > 0 ? (d.contractAmt / maxVal) * 90 : 0;
                  const annualHeightPct = maxVal > 0 ? (d.annualAmt / maxVal) * 90 : 0;

                  return (
                    <div
                      key={d.month}
                      className="flex-1 flex flex-col items-center h-full justify-end group cursor-pointer"
                      onMouseEnter={() => setActiveTooltip(d)}
                      onMouseLeave={() => setActiveTooltip(null)}
                    >
                      <div className="w-full max-w-[28px] flex items-end justify-center gap-0.5 h-full">
                        {/* Contract Bar */}
                        <div
                          style={{ height: `${Math.max(contractHeightPct, 4)}%` }}
                          className={`w-1/2 rounded-t-sm transition-all duration-300 ${
                            d.contractAmt > 0
                              ? 'bg-blue-600 group-hover:bg-blue-700'
                              : 'bg-slate-100'
                          }`}
                        />
                        {/* Annual Rent Bar */}
                        <div
                          style={{ height: `${Math.max(annualHeightPct, 4)}%` }}
                          className={`w-1/2 rounded-t-sm transition-all duration-300 ${
                            d.annualAmt > 0
                              ? 'bg-emerald-500 group-hover:bg-emerald-600'
                              : 'bg-slate-100'
                          }`}
                        />
                      </div>
                      <span className="text-[11px] font-medium text-slate-500 mt-2">
                        {d.month}
                      </span>
                    </div>
                  );
                })}
              </div>

              {/* Tooltip Overlay */}
              {activeTooltip && (
                <div className="absolute top-2 right-4 bg-slate-900/95 text-white p-3 rounded-xl shadow-xl text-xs z-20 backdrop-blur-sm pointer-events-none border border-slate-700">
                  <div className="font-bold text-slate-200 border-b border-slate-700 pb-1 mb-1.5 flex items-center justify-between gap-4">
                    <span>Month of {activeTooltip.month}</span>
                    <span className="text-[10px] text-blue-400 font-mono">AED</span>
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between gap-4 text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-blue-500"></span> Contract Amt:
                      </span>
                      <span className="font-semibold text-white">
                        {formatAED(activeTooltip.contractAmt)}
                      </span>
                    </div>
                    <div className="flex justify-between gap-4 text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-400"></span> Actual Annual:
                      </span>
                      <span className="font-semibold text-white">
                        {formatAED(activeTooltip.annualAmt)}
                      </span>
                    </div>
                    <div className="flex justify-between gap-4 text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-teal-400"></span> Receipts:
                      </span>
                      <span className="font-semibold text-white">
                        {formatAED(activeTooltip.receiptAmt)}
                      </span>
                    </div>
                    <div className="flex justify-between gap-4 text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-rose-400"></span> Maintenance:
                      </span>
                      <span className="font-semibold text-white">
                        {formatAED(activeTooltip.expAmt)}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Hover over any month to view granular contract and payment details.</span>
            <span className="font-medium text-slate-700">Currency: AED (United Arab Emirates Dirham)</span>
          </div>
        </div>

        {/* Enhanced UAE Federal Tax Authority (FTA) Tax Position Box (1 column) */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center font-extrabold text-xs">
                  FTA
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">UAE Federal Tax Authority</h3>
                  <p className="text-[11px] text-slate-500">VAT Return Form 201 Breakdown</p>
                </div>
              </div>
              <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-2 py-0.5 rounded-md">
                5% UAE VAT Rate
              </span>
            </div>

            <div className="mt-4 space-y-2.5">
              {/* Output VAT on Commercial Tenancy Contracts */}
              <div className="p-3 rounded-xl bg-purple-50/70 border border-purple-200/70">
                <div className="flex justify-between text-xs text-purple-900 font-semibold">
                  <span>Output VAT on Commercial Rent (5%)</span>
                  <span className="font-mono text-purple-950 font-bold">AED</span>
                </div>
                <div className="text-base font-bold text-purple-950 mt-0.5">
                  {formatAED(totalVatOnActualAnnualRent)}
                </div>
                <div className="text-[11px] text-purple-700 mt-1 flex items-center justify-between">
                  <span>Comm. Rent: {formatAED(commercialActualAnnualRent)}</span>
                  <span>{commercialContractsCount} Units</span>
                </div>
              </div>

              {/* Residential Tenancy Contracts (0% Exempt) */}
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/60">
                <div className="flex justify-between text-[11px] text-slate-600">
                  <span>Residence Rent (0% VAT Exempt)</span>
                  <span className="font-bold text-slate-800">{formatAED(residenceActualAnnualRent)}</span>
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {residenceContractsCount} Residential units exempt under UAE VAT Law
                </div>
              </div>

              {/* Recoverable Input Tax on Invoices */}
              <div className="p-3 rounded-xl bg-indigo-50/70 border border-indigo-200/70">
                <div className="flex justify-between text-xs text-indigo-900 font-semibold">
                  <span>Box 9: Recoverable Input Tax (5%)</span>
                  <span className="font-mono text-indigo-950 font-bold">AED</span>
                </div>
                <div className="text-base font-bold text-indigo-950 mt-0.5">
                  {formatAED(totalInputVAT)}
                </div>
                <div className="text-[11px] text-indigo-700 mt-1 flex items-center justify-between">
                  <span>Gross Bills: {formatAED(totalGrossInvoices)}</span>
                  <span>{filteredInvoices.length} Invoices</span>
                </div>
              </div>

              {/* NET FTA PAYMENT RESULT BOX */}
              <div
                className={`p-3.5 rounded-xl border-2 ${
                  netFtaPayment > 0
                    ? 'bg-rose-50/70 border-rose-400/80'
                    : netFtaPayment < 0
                    ? 'bg-emerald-50/70 border-emerald-400/80'
                    : 'bg-slate-50 border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-900">
                    Net FTA Payment
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      netFtaPayment > 0
                        ? 'bg-rose-100 text-rose-800'
                        : netFtaPayment < 0
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {netFtaPayment > 0
                      ? 'Payable to FTA'
                      : netFtaPayment < 0
                      ? 'Refundable Credit'
                      : 'Settled'}
                  </span>
                </div>
                <div
                  className={`text-xl font-black mt-1 ${
                    netFtaPayment > 0
                      ? 'text-rose-700'
                      : netFtaPayment < 0
                      ? 'text-emerald-700'
                      : 'text-slate-800'
                  }`}
                >
                  {formatAED(netFtaPayment)}
                </div>
                <p className="text-[10px] text-slate-500 mt-1 font-mono">
                  = {formatAED(totalVatOnActualAnnualRent)} (Output) − {formatAED(totalInputVAT)} (Input)
                </p>
              </div>
            </div>
          </div>

          <div className="pt-3 mt-3 border-t border-slate-100">
            <button
              onClick={() => onNavigateTab('contracts')}
              className="w-full flex items-center justify-center gap-1.5 py-2 text-xs font-semibold text-blue-600 bg-blue-50/80 rounded-xl hover:bg-blue-100 transition"
            >
              <span>Manage Tenancy Commercial & Residence Types</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Property & Document Zero State OR Quick Lists */}
      {!hasData ? (
        <div className="bg-white rounded-3xl border border-dashed border-slate-300 p-12 text-center max-w-2xl mx-auto shadow-xs">
          <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Building2 className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">
            {isFiltered ? `No records found for ${selectedProperty}` : 'No Tenancy Contracts or Invoices Yet'}
          </h3>
          <p className="text-sm text-slate-500 mt-1 max-w-md mx-auto">
            {isFiltered
              ? 'Try selecting "All Properties" from the dropdown above or upload contracts for this building.'
              : 'Upload your UAE Ejari tenancy contracts, rental installment receipts, or purchase tax invoices. The system will automatically classify commercial vs residential leases and calculate VAT.'}
          </p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            {isFiltered ? (
              <button
                onClick={() => setSelectedProperty('all')}
                className="px-4 py-2 text-xs font-bold text-slate-700 bg-slate-100 rounded-xl hover:bg-slate-200 transition"
              >
                Clear Property Filter
              </button>
            ) : (
              <button
                onClick={() => onNavigateTab('upload')}
                className="px-5 py-2.5 text-xs font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 transition shadow-sm flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Upload UAE Documents Now
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Filtered Tenancy Contracts Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-blue-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  {isFiltered ? `${selectedProperty} Contracts` : 'Recent Tenancy Contracts'}
                </h3>
              </div>
              <button
                onClick={() => onNavigateTab('contracts')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-0.5"
              >
                View All ({filteredContracts.length})
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100 mt-2">
              {filteredContracts.slice(0, 4).map((c) => {
                const isComm = isCommercialContract(c.contractType || c.propertyType);
                const vatAmount = isComm
                  ? c.vatAmount != null
                    ? c.vatAmount
                    : Math.round((c.actualAnnualAmount || c.contractAmount || 0) * 0.05 * 100) / 100
                  : 0;

                return (
                  <div key={c.id} className="py-2.5 flex items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">
                          {c.buildingName || 'Property'} {c.propertyNo ? `• Unit ${c.propertyNo}` : ''}
                        </span>
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${
                            isComm
                              ? 'bg-purple-50 text-purple-700 border-purple-200'
                              : 'bg-slate-100 text-slate-600 border-slate-200'
                          }`}
                        >
                          {isComm ? 'Commercial (5% VAT)' : 'Residence (0%)'}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Tenant: <span className="text-slate-700 font-medium">{c.tenantName || 'N/A'}</span>
                        {c.contractNo && ` • Ejari: ${c.contractNo}`}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-slate-900">
                        {formatAED(c.actualAnnualAmount)}
                      </div>
                      <div className="text-[10px]">
                        {isComm ? (
                          <span className="text-purple-700 font-semibold">
                            +VAT: {formatAED(vatAmount)}
                          </span>
                        ) : (
                          <span className="text-slate-400">0% VAT Exempt</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Filtered Invoices Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-rose-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  {isFiltered ? `${selectedProperty} Tax Invoices` : 'Recent Purchase Tax Invoices'}
                </h3>
              </div>
              <button
                onClick={() => onNavigateTab('invoices')}
                className="text-xs font-semibold text-blue-600 hover:text-blue-700 flex items-center gap-0.5"
              >
                View All ({filteredInvoices.length})
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100 mt-2">
              {filteredInvoices.slice(0, 4).map((i) => (
                <div key={i.id} className="py-2.5 flex items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      {i.supplierName || 'Supplier'}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5">
                      Inv #{i.invoiceNumber} • {i.expenseCategory || 'Maintenance'}
                      {i.buildingRef ? ` • ${i.buildingRef}` : ''}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-bold text-slate-900">
                      {formatAED(i.totalInvoiceAmount)}
                    </div>
                    <div className="text-[10px] text-indigo-600 font-semibold">
                      Input VAT: {formatAED(i.taxAmount)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
