import React, { useState } from 'react';
import {
  Receipt,
  Search,
  Plus,
  Download,
  Edit2,
  Trash2,
  Save,
  X,
  FileSpreadsheet,
  Eye,
  CreditCard,
  Building,
  AlertTriangle,
} from 'lucide-react';
import { RentalReceipt } from '../types';
import { formatAED, exportToExcel, exportToCSV } from '../utils/exportUtils';
import { updateReceipt, deleteReceipt, saveReceipt } from '../services/dbService';
import { useAuth } from '../context/AuthContext';

interface ReceiptsTableProps {
  receipts: RentalReceipt[];
}

export const ReceiptsTable: React.FC<ReceiptsTableProps> = ({ receipts }) => {
  const { user, canEdit } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<RentalReceipt>>({});
  const [selectedReceipt, setSelectedReceipt] = useState<RentalReceipt | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newReceiptData, setNewReceiptData] = useState<Partial<RentalReceipt>>({
    installmentDate: new Date().toISOString().slice(0, 10),
    amount: 0,
    bankName: 'Emirates NBD',
  });

  const duplicateReceiptMatch = newReceiptData.receiptNo?.trim()
    ? receipts.find(
        (r) =>
          r.receiptNo?.trim().toLowerCase() ===
          newReceiptData.receiptNo?.trim().toLowerCase()
      )
    : null;

  const filteredReceipts = receipts.filter((r) => {
    return (
      (r.receiptNo || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.bankName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.chequeNo || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.tenantName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (r.propertyRef || '').toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const totalReceiptsAmount = filteredReceipts.reduce((acc, r) => acc + (r.amount || 0), 0);
  const uniqueBanks = Array.from(new Set(filteredReceipts.map((r) => r.bankName).filter(Boolean)));

  const startEdit = (receipt: RentalReceipt) => {
    setEditingId(receipt.id);
    setEditFormData(receipt);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditFormData({});
  };

  const saveEdit = async (id: string) => {
    try {
      await updateReceipt(id, editFormData);
      setEditingId(null);
    } catch (err: any) {
      alert(`Error updating receipt: ${err.message}`);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this rental receipt?')) {
      try {
        await deleteReceipt(id);
      } catch (err: any) {
        alert(`Error deleting receipt: ${err.message}`);
      }
    }
  };

  const handleCreateNew = async () => {
    if (!user) return;
    if (!newReceiptData.amount || newReceiptData.amount <= 0) {
      alert('Please enter a valid amount.');
      return;
    }

    try {
      const now = new Date().toISOString();
      const receiptDoc: RentalReceipt = {
        id: `RCP-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        userId: user.uid,
        receiptNo: newReceiptData.receiptNo || `RCP-${Date.now().toString().slice(-6)}`,
        installmentDate: newReceiptData.installmentDate || now.slice(0, 10),
        amount: Number(newReceiptData.amount) || 0,
        chequeNo: newReceiptData.chequeNo || 'N/A',
        bankName: newReceiptData.bankName || 'UAE Bank',
        tenantName: newReceiptData.tenantName || '',
        propertyRef: newReceiptData.propertyRef || '',
        createdAt: now,
        updatedAt: now,
      };
      await saveReceipt(receiptDoc);
      setIsAddingNew(false);
      setNewReceiptData({
        installmentDate: now.slice(0, 10),
        amount: 0,
        bankName: 'Emirates NBD',
      });
    } catch (err: any) {
      alert(`Error creating receipt: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-200/80">
        <div>
          <span className="text-xs font-semibold tracking-wider uppercase text-teal-700 bg-teal-50 px-2.5 py-0.5 rounded-full border border-teal-200/60">
            Payment Vouchers & Cheques
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
            Rental Payment Receipts & Installments
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Audit rental receipts with exact installment dates, clearing banks, and cheque transaction serial numbers.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {canEdit && (
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-teal-600 rounded-xl hover:bg-teal-700 transition shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Rental Receipt
            </button>
          )}
          <button
            onClick={() => exportToCSV(filteredReceipts, 'UAE_Rental_Receipts')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            CSV
          </button>
          <button
            onClick={() => exportToExcel([], receipts, [], 'consolidated')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            Excel
          </button>
        </div>
      </div>

      {/* Receipts Summary Card */}
      <div className="bg-gradient-to-r from-teal-900 via-teal-800 to-slate-900 text-white rounded-2xl p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-teal-700/60 mb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-200">
            Rental Receipts Batch Summary ({filteredReceipts.length} Records)
          </span>
          <span className="text-xs font-mono text-teal-300">UAE Dirhams (AED)</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <div className="text-[11px] text-teal-200">Total Rental Receipts Collected</div>
            <div className="text-xl font-bold text-white mt-0.5">
              {formatAED(totalReceiptsAmount)}
            </div>
          </div>
          <div>
            <div className="text-[11px] text-teal-200">Average Installment Amount</div>
            <div className="text-xl font-bold text-teal-300 mt-0.5">
              {formatAED(filteredReceipts.length > 0 ? totalReceiptsAmount / filteredReceipts.length : 0)}
            </div>
          </div>
          <div>
            <div className="text-[11px] text-teal-200">Associated Clearing Banks</div>
            <div className="text-base font-semibold text-white mt-1">
              {uniqueBanks.length > 0 ? uniqueBanks.slice(0, 3).join(', ') : 'None'}
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search cheque #, bank, receipt #, tenant..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:border-teal-500 transition"
          />
        </div>
        <span className="text-xs text-slate-400 font-medium">
          Showing {filteredReceipts.length} of {receipts.length} receipts
        </span>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-slate-50/90 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Receipt / Voucher #</th>
                <th className="py-3 px-4">Installment Date</th>
                <th className="py-3 px-4 text-right">Amount (AED)</th>
                <th className="py-3 px-4">Cheque / Ref No</th>
                <th className="py-3 px-4">Bank Name</th>
                <th className="py-3 px-4">Tenant / Payer</th>
                <th className="py-3 px-4">Property Ref</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredReceipts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    No rental receipts found. Upload receipt vouchers or add manually.
                  </td>
                </tr>
              ) : (
                filteredReceipts.map((r) => {
                  const isEditing = editingId === r.id;

                  if (isEditing) {
                    return (
                      <tr key={r.id} className="bg-teal-50/40">
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.receiptNo || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, receiptNo: e.target.value })
                            }
                            className="w-28 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="date"
                            value={editFormData.installmentDate || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, installmentDate: e.target.value })
                            }
                            className="w-28 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2 text-right">
                          <input
                            type="number"
                            value={editFormData.amount || 0}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, amount: Number(e.target.value) })
                            }
                            className="w-28 p-1 border rounded bg-white text-xs text-right font-bold"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.chequeNo || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, chequeNo: e.target.value })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.bankName || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, bankName: e.target.value })
                            }
                            className="w-28 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.tenantName || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, tenantName: e.target.value })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.propertyRef || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, propertyRef: e.target.value })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => saveEdit(r.id)}
                              className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            >
                              <Save className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={cancelEdit}
                              className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={r.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono font-medium text-teal-700">
                        {r.receiptNo || 'N/A'}
                      </td>
                      <td className="py-3 px-4 text-slate-600">{r.installmentDate}</td>
                      <td className="py-3 px-4 text-right font-bold text-slate-900">
                        {formatAED(r.amount)}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-700">{r.chequeNo || '-'}</td>
                      <td className="py-3 px-4 font-medium text-slate-800">{r.bankName}</td>
                      <td className="py-3 px-4 text-slate-700">{r.tenantName || '-'}</td>
                      <td className="py-3 px-4 text-slate-500">{r.propertyRef || '-'}</td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => setSelectedReceipt(r)}
                            className="p-1 text-slate-400 hover:text-teal-600 rounded hover:bg-teal-50 transition"
                            title="View Individual Summary"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          {canEdit && (
                            <>
                              <button
                                onClick={() => startEdit(r)}
                                className="p-1 text-slate-400 hover:text-teal-600 rounded hover:bg-teal-50 transition"
                                title="Edit"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDelete(r.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Individual Summary Modal for Receipt */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-teal-600" />
                <div>
                  <h3 className="text-base font-bold text-slate-900">Rental Receipt Summary</h3>
                  <p className="text-xs text-slate-500">Voucher #{selectedReceipt.receiptNo}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="p-4 bg-teal-50 rounded-2xl border border-teal-100 text-center">
                <span className="text-teal-600 font-medium">Receipt Cleared Amount</span>
                <div className="text-2xl font-black text-teal-950 mt-1">
                  {formatAED(selectedReceipt.amount)}
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-2xl space-y-2 border border-slate-200/80">
                <div className="flex justify-between">
                  <span className="text-slate-500">Installment Date:</span>
                  <span className="font-semibold text-slate-800">{selectedReceipt.installmentDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Cheque / Ref Number:</span>
                  <span className="font-mono font-semibold text-slate-800">{selectedReceipt.chequeNo || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Bank Name:</span>
                  <span className="font-semibold text-slate-800">{selectedReceipt.bankName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Tenant / Payer:</span>
                  <span className="font-semibold text-slate-800">{selectedReceipt.tenantName || 'N/A'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Property Ref:</span>
                  <span className="font-semibold text-slate-800">{selectedReceipt.propertyRef || 'N/A'}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setSelectedReceipt(null)}
                className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 rounded-xl hover:bg-teal-700 transition"
              >
                Close Summary
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Modal */}
      {isAddingNew && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Add Rental Receipt</h3>
              <button
                onClick={() => setIsAddingNew(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div>
                <div className="flex items-center justify-between">
                  <label className="text-slate-600 font-medium">Receipt / Voucher Number</label>
                  {duplicateReceiptMatch && (
                    <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.2 rounded">
                      Duplicate Receipt
                    </span>
                  )}
                </div>
                <input
                  type="text"
                  placeholder="e.g. RCP-2026-004"
                  value={newReceiptData.receiptNo || ''}
                  onChange={(e) =>
                    setNewReceiptData({ ...newReceiptData, receiptNo: e.target.value })
                  }
                  className={`mt-1 w-full p-2 border rounded-xl bg-slate-50 ${
                    duplicateReceiptMatch ? 'border-amber-400 bg-amber-50/50 ring-2 ring-amber-300/40 text-amber-950 font-semibold' : ''
                  }`}
                />
                {duplicateReceiptMatch && (
                  <div className="mt-1 flex items-start gap-1.5 text-[11px] text-amber-900 bg-amber-50 p-2 rounded-lg border border-amber-200">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Duplicate Receipt Warning: </span>
                      <span>Receipt #{newReceiptData.receiptNo} already exists in database (Bank: {duplicateReceiptMatch.bankName || 'Unknown'}, AED {duplicateReceiptMatch.amount?.toLocaleString()})</span>
                    </div>
                  </div>
                )}
              </div>
              <div>
                <label className="text-slate-600 font-medium">Installment Date *</label>
                <input
                  type="date"
                  value={newReceiptData.installmentDate || ''}
                  onChange={(e) =>
                    setNewReceiptData({ ...newReceiptData, installmentDate: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Amount (AED) *</label>
                <input
                  type="number"
                  placeholder="Receipt Amount"
                  value={newReceiptData.amount || 0}
                  onChange={(e) =>
                    setNewReceiptData({ ...newReceiptData, amount: Number(e.target.value) })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50 font-bold"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Cheque Number *</label>
                <input
                  type="text"
                  placeholder="e.g. 000492"
                  value={newReceiptData.chequeNo || ''}
                  onChange={(e) =>
                    setNewReceiptData({ ...newReceiptData, chequeNo: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Bank Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Emirates NBD, ADCB, FAB"
                  value={newReceiptData.bankName || ''}
                  onChange={(e) =>
                    setNewReceiptData({ ...newReceiptData, bankName: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Tenant Name</label>
                <input
                  type="text"
                  placeholder="Tenant name"
                  value={newReceiptData.tenantName || ''}
                  onChange={(e) =>
                    setNewReceiptData({ ...newReceiptData, tenantName: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2.5">
              <button
                onClick={() => setIsAddingNew(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateNew}
                className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl transition shadow-xs"
              >
                Save Receipt
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
