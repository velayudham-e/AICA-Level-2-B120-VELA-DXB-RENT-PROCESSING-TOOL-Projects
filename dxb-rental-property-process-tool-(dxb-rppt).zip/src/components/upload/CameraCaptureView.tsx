import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  RotateCcw,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  X,
  FlipHorizontal,
  Upload,
  RefreshCw,
  Maximize2,
} from 'lucide-react';

interface CameraCaptureViewProps {
  onPhotoCaptured: (file: File) => void;
  onCancel: () => void;
  documentTypeTitle?: string;
}

export const CameraCaptureView: React.FC<CameraCaptureViewProps> = ({
  onPhotoCaptured,
  onCancel,
  documentTypeTitle = 'Purchase Tax Invoice',
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const nativeCameraInputRef = useRef<HTMLInputElement>(null);

  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [capturedPhotoUrl, setCapturedPhotoUrl] = useState<string | null>(null);
  const [capturedBlob, setCapturedBlob] = useState<Blob | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);
  const [isFlashing, setIsFlashing] = useState<boolean>(false);

  // Start camera stream on mount or when facingMode changes
  useEffect(() => {
    let activeStream: MediaStream | null = null;

    async function initCamera() {
      setIsInitializing(true);
      setCameraError(null);

      // Stop previous stream if active
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }

      try {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          throw new Error('Camera API (getUserMedia) is not supported in this browser environment.');
        }

        // Try environment facing mode first, fall back to true video if not supported
        let mediaStream: MediaStream;
        try {
          mediaStream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: { ideal: facingMode },
              width: { ideal: 1920 },
              height: { ideal: 1080 },
            },
            audio: false,
          });
        } catch (e) {
          // Fallback to basic video constraint
          mediaStream = await navigator.mediaDevices.getUserMedia({
            video: true,
            audio: false,
          });
        }

        activeStream = mediaStream;
        setStream(mediaStream);

        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
          await videoRef.current.play();
        }
      } catch (err: any) {
        console.warn('Camera initialization error:', err);
        setCameraError(
          err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'
            ? 'Camera permission denied. Please allow camera access in your browser or use the native camera option.'
            : err.message || 'Unable to access device camera.'
        );
      } finally {
        setIsInitializing(false);
      }
    }

    if (!capturedPhotoUrl) {
      initCamera();
    }

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [facingMode, capturedPhotoUrl]);

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [stream]);

  // Capture frame from video stream to canvas
  const handleCapture = () => {
    if (!videoRef.current) return;

    // Trigger visual shutter flash
    setIsFlashing(true);
    setTimeout(() => setIsFlashing(false), 150);

    const video = videoRef.current;
    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Draw video frame to canvas
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(
      (blob) => {
        if (blob) {
          setCapturedBlob(blob);
          const dataUrl = URL.createObjectURL(blob);
          setCapturedPhotoUrl(dataUrl);

          // Stop live stream tracks while reviewing photo
          if (stream) {
            stream.getTracks().forEach((t) => t.stop());
            setStream(null);
          }
        }
      },
      'image/jpeg',
      0.95
    );
  };

  // Toggle front/rear camera
  const handleFlipCamera = () => {
    setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
  };

  // Retake photo: discard current snapshot and resume camera
  const handleRetake = () => {
    if (capturedPhotoUrl) {
      URL.revokeObjectURL(capturedPhotoUrl);
    }
    setCapturedPhotoUrl(null);
    setCapturedBlob(null);
  };

  // Confirm photo and send to AI OCR processing
  const handleConfirm = () => {
    if (!capturedBlob) return;
    const file = new File(
      [capturedBlob],
      `invoice_camera_${Date.now()}.jpg`,
      { type: 'image/jpeg' }
    );
    onPhotoCaptured(file);
  };

  // Native mobile camera input fallback
  const handleNativeCameraFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      onPhotoCaptured(file);
    }
  };

  return (
    <div className="relative w-full rounded-3xl bg-slate-950 overflow-hidden text-white shadow-2xl flex flex-col items-center select-none">
      {/* Hidden canvas for high-resolution grabbing */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Hidden file input with capture="environment" for native phone camera */}
      <input
        ref={nativeCameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleNativeCameraFile}
        className="hidden"
      />

      {/* Shutter White Flash Animation Overlay */}
      {isFlashing && (
        <div className="absolute inset-0 bg-white z-50 pointer-events-none transition-opacity duration-150 animate-out fade-out" />
      )}

      {/* Viewport Header */}
      <div className="w-full px-6 py-4 bg-slate-900/80 backdrop-blur-md flex items-center justify-between border-b border-white/10 z-20">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
            <Camera className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold tracking-tight text-white">
              Camera Scanner • {documentTypeTitle}
            </h4>
            <p className="text-[10px] text-slate-400">
              {capturedPhotoUrl ? 'Review captured photo before processing' : 'Align UAE invoice within framing guide'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {!capturedPhotoUrl && !cameraError && (
            <button
              onClick={handleFlipCamera}
              title="Switch Camera (Front/Rear)"
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 transition-colors cursor-pointer"
            >
              <FlipHorizontal className="w-4 h-4" />
            </button>
          )}

          <button
            onClick={onCancel}
            title="Close Camera"
            className="p-2 rounded-xl bg-white/10 hover:bg-rose-500/30 hover:text-rose-200 text-slate-300 transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Video Viewport / Photo Preview Area */}
      <div className="relative w-full aspect-[4/3] max-h-[460px] bg-black flex items-center justify-center overflow-hidden">
        {capturedPhotoUrl ? (
          // Captured Snapshot Preview
          <img
            src={capturedPhotoUrl}
            alt="Captured Invoice"
            className="w-full h-full object-contain"
          />
        ) : cameraError ? (
          // Camera Error / Permission Fallback View
          <div className="p-8 text-center max-w-md space-y-4">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div>
              <h5 className="text-sm font-bold text-white">Live Camera Unavailable</h5>
              <p className="text-xs text-slate-400 mt-1">{cameraError}</p>
            </div>
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-2">
              <button
                onClick={() => nativeCameraInputRef.current?.click()}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                <span>Launch Device Native Camera</span>
              </button>
              <button
                onClick={() => setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'))}
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-semibold transition-all cursor-pointer"
              >
                Retry Camera
              </button>
            </div>
          </div>
        ) : (
          // Live Video Feed & Framing Reticle
          <>
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
            />

            {/* Apple Document Scanner Framing Reticle */}
            <div className="absolute inset-8 sm:inset-12 border-2 border-white/60 border-dashed rounded-3xl pointer-events-none flex flex-col justify-between p-4 shadow-[0_0_0_9999px_rgba(0,0,0,0.45)]">
              {/* Corner brackets */}
              <div className="flex justify-between">
                <div className="w-6 h-6 border-t-4 border-l-4 border-amber-400 rounded-tl-xl" />
                <div className="w-6 h-6 border-t-4 border-r-4 border-amber-400 rounded-tr-xl" />
              </div>

              {/* Center Guidance Badge */}
              <div className="self-center px-3 py-1 rounded-full bg-slate-900/80 backdrop-blur-md border border-white/20 text-[11px] font-semibold text-amber-300 shadow-md">
                Position UAE Tax Invoice within frame
              </div>

              <div className="flex justify-between">
                <div className="w-6 h-6 border-b-4 border-l-4 border-amber-400 rounded-bl-xl" />
                <div className="w-6 h-6 border-b-4 border-r-4 border-amber-400 rounded-br-xl" />
              </div>
            </div>

            {isInitializing && (
              <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center gap-2 text-xs text-slate-300">
                <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
                <span>Starting camera sensor...</span>
              </div>
            )}
          </>
        )}
      </div>

      {/* Control Bar */}
      <div className="w-full px-8 py-5 bg-slate-900/90 backdrop-blur-md border-t border-white/10 flex items-center justify-between z-20">
        {capturedPhotoUrl ? (
          // Controls when photo is taken: Retake or Confirm
          <div className="w-full flex items-center justify-between gap-4">
            <button
              onClick={handleRetake}
              className="flex items-center gap-2 px-5 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-slate-200 font-semibold text-xs transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retake Photo</span>
            </button>

            <button
              onClick={handleConfirm}
              className="flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold text-xs shadow-lg shadow-emerald-500/30 transition-all active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-emerald-100" />
              <span>Use Photo & Process with AI OCR</span>
            </button>
          </div>
        ) : (
          // Controls when camera is live: Shutter button & Native Camera option
          <div className="w-full flex items-center justify-between">
            <button
              type="button"
              onClick={() => nativeCameraInputRef.current?.click()}
              className="text-[11px] text-slate-400 hover:text-amber-300 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Use Native Camera App</span>
            </button>

            {/* Apple-style circular camera shutter trigger */}
            <div className="flex items-center justify-center">
              <button
                type="button"
                disabled={isInitializing || !!cameraError}
                onClick={handleCapture}
                className="w-16 h-16 rounded-full border-4 border-white p-1 flex items-center justify-center transition-all hover:scale-105 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer shadow-lg shadow-black/40"
              >
                <div className="w-full h-full rounded-full bg-white transition-all active:bg-amber-400" />
              </button>
            </div>

            <button
              type="button"
              onClick={onCancel}
              className="text-[11px] text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
