import React, { useState } from 'react';
import {
  FileText,
  Search,
  Plus,
  Download,
  Edit2,
  Trash2,
  Save,
  X,
  FileSpreadsheet,
  Eye,
  Percent,
  CheckCircle2,
  Building,
  AlertTriangle,
} from 'lucide-react';
import { PurchaseTaxInvoice } from '../types';
import { formatAED, exportToExcel, exportToCSV } from '../utils/exportUtils';
import { updateInvoice, deleteInvoice, saveInvoice } from '../services/dbService';
import { useAuth } from '../context/AuthContext';

interface InvoicesTableProps {
  invoices: PurchaseTaxInvoice[];
}

export const InvoicesTable: React.FC<InvoicesTableProps> = ({ invoices }) => {
  const { user, canEdit } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<PurchaseTaxInvoice>>({});
  const [selectedInvoice, setSelectedInvoice] = useState<PurchaseTaxInvoice | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [newInvoiceData, setNewInvoiceData] = useState<Partial<PurchaseTaxInvoice>>({
    invoiceDate: new Date().toISOString().slice(0, 10),
    expenseCategory: 'Maintenance',
    totalInvoiceAmount: 0,
    taxAmount: 0,
    netAmount: 0,
  });

  const duplicateInvoiceMatch = newInvoiceData.invoiceNumber?.trim()
    ? invoices.find(
        (i) =>
          i.invoiceNumber?.trim().toLowerCase() ===
          newInvoiceData.invoiceNumber?.trim().toLowerCase()
      )
    : null;

  const filteredInvoices = invoices.filter((i) => {
    return (
      (i.invoiceNumber || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (i.supplierName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (i.supplierTrn || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (i.expenseCategory || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (i.buildingRef || '').toLowerCase().includes(searchTerm.toLowerCase())
    );
  });

  const totalGrossAmount = filteredInvoices.reduce((acc, i) => acc + (i.totalInvoiceAmount || 0), 0);
  const totalTaxAmount = filteredInvoices.reduce((acc, i) => acc + (i.taxAmount || 0), 0);
  const totalNetAmount = filteredInvoices.reduce((acc, i) => acc + (i.netAmount || 0), 0);

  const startEdit = (invoice: PurchaseTaxInvoice) => {
    setEditingId(invoice.id);
    setEditFormData(invoice);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditFormData({});
  };

  const saveEdit = async (id: string) => {
    try {
      await updateInvoice(id, editFormData);
      setEditingId(null);
    } catch (err: any) {
      alert(`Error updating invoice: ${err.message}`);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this purchase tax invoice?')) {
      try {
        await deleteInvoice(id);
      } catch (err: any) {
        alert(`Error deleting invoice: ${err.message}`);
      }
    }
  };

  const handleCreateNew = async () => {
    if (!user) return;
    if (!newInvoiceData.supplierName || !newInvoiceData.totalInvoiceAmount) {
      alert('Please fill in Supplier Name and Total Amount.');
      return;
    }

    try {
      const now = new Date().toISOString();
      const gross = Number(newInvoiceData.totalInvoiceAmount) || 0;
      const vat = Number(newInvoiceData.taxAmount) || +(gross - gross / 1.05).toFixed(2);
      const net = Number(newInvoiceData.netAmount) || +(gross - vat).toFixed(2);

      const invoiceDoc: PurchaseTaxInvoice = {
        id: `INV-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
        userId: user.uid,
        invoiceNumber: newInvoiceData.invoiceNumber || `TAX-${Date.now().toString().slice(-6)}`,
        invoiceDate: newInvoiceData.invoiceDate || now.slice(0, 10),
        supplierName: newInvoiceData.supplierName || '',
        supplierTrn: newInvoiceData.supplierTrn || '',
        expenseCategory: newInvoiceData.expenseCategory || 'Maintenance',
        netAmount: net,
        taxAmount: vat,
        totalInvoiceAmount: gross,
        buildingRef: newInvoiceData.buildingRef || '',
        createdAt: now,
        updatedAt: now,
      };
      await saveInvoice(invoiceDoc);
      setIsAddingNew(false);
      setNewInvoiceData({
        invoiceDate: now.slice(0, 10),
        expenseCategory: 'Maintenance',
        totalInvoiceAmount: 0,
        taxAmount: 0,
        netAmount: 0,
      });
    } catch (err: any) {
      alert(`Error creating invoice: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-2 border-b border-slate-200/80">
        <div>
          <span className="text-xs font-semibold tracking-wider uppercase text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-full border border-indigo-200/60">
            UAE FTA Tax Compliance
          </span>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-1">
            Purchase Tax Invoices & Maintenance
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Audit supplier invoices, TRNs (Tax Registration Numbers), net expenses, and 5% recoverable VAT.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {canEdit && (
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Tax Invoice
            </button>
          )}
          <button
            onClick={() => exportToCSV(filteredInvoices, 'UAE_Purchase_Tax_Invoices')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            CSV
          </button>
          <button
            onClick={() => exportToExcel([], [], invoices, 'consolidated')}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            Excel
          </button>
        </div>
      </div>

      {/* Invoices Summary Banner */}
      <div className="bg-gradient-to-r from-indigo-950 via-indigo-900 to-slate-900 text-white rounded-2xl p-5 shadow-xs">
        <div className="flex items-center justify-between pb-3 border-b border-indigo-800/60 mb-3">
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-200">
            Purchase Tax Invoices Summary ({filteredInvoices.length} Bills)
          </span>
          <span className="text-xs font-mono text-indigo-300">UAE Dirhams (AED)</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <div className="text-[11px] text-indigo-200">Total Gross Invoiced (Inc. VAT)</div>
            <div className="text-xl font-bold text-white mt-0.5">
              {formatAED(totalGrossAmount)}
            </div>
          </div>
          <div>
            <div className="text-[11px] text-indigo-200">Net Expense (Excl. VAT)</div>
            <div className="text-xl font-bold text-slate-200 mt-0.5">
              {formatAED(totalNetAmount)}
            </div>
          </div>
          <div>
            <div className="text-[11px] text-indigo-200">Total 5% VAT (Recoverable Input Tax)</div>
            <div className="text-xl font-bold text-emerald-300 mt-0.5">
              {formatAED(totalTaxAmount)}
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs flex items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search invoice #, supplier, TRN, category..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:outline-hidden focus:border-indigo-500 transition"
          />
        </div>
        <span className="text-xs text-slate-400 font-medium">
          Showing {filteredInvoices.length} of {invoices.length} invoices
        </span>
      </div>

      {/* Editable Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs whitespace-nowrap">
            <thead className="bg-slate-50/90 text-slate-600 font-semibold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Invoice Number</th>
                <th className="py-3 px-4">Invoice Date</th>
                <th className="py-3 px-4">Supplier Name</th>
                <th className="py-3 px-4">Supplier TRN</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4 text-right">Net Amount (AED)</th>
                <th className="py-3 px-4 text-right">VAT (5% AED)</th>
                <th className="py-3 px-4 text-right">Total Gross (AED)</th>
                <th className="py-3 px-4">Property Ref</th>
                <th className="py-3 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    No purchase tax invoices recorded. Upload supplier invoices or add manually.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((i) => {
                  const isEditing = editingId === i.id;

                  if (isEditing) {
                    return (
                      <tr key={i.id} className="bg-indigo-50/40">
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.invoiceNumber || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, invoiceNumber: e.target.value })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="date"
                            value={editFormData.invoiceDate || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, invoiceDate: e.target.value })
                            }
                            className="w-28 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.supplierName || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, supplierName: e.target.value })
                            }
                            className="w-32 p-1 border rounded bg-white text-xs font-semibold"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.supplierTrn || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, supplierTrn: e.target.value })
                            }
                            className="w-28 p-1 border rounded bg-white text-xs font-mono"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.expenseCategory || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, expenseCategory: e.target.value })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2 text-right">
                          <input
                            type="number"
                            value={editFormData.netAmount || 0}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, netAmount: Number(e.target.value) })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs text-right"
                          />
                        </td>
                        <td className="p-2 text-right">
                          <input
                            type="number"
                            value={editFormData.taxAmount || 0}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, taxAmount: Number(e.target.value) })
                            }
                            className="w-24 p-1 border rounded bg-white text-xs text-right text-emerald-600 font-bold"
                          />
                        </td>
                        <td className="p-2 text-right">
                          <input
                            type="number"
                            value={editFormData.totalInvoiceAmount || 0}
                            onChange={(e) => {
                              const gross = Number(e.target.value);
                              setEditFormData({
                                ...editFormData,
                                totalInvoiceAmount: gross,
                                taxAmount: +(gross - gross / 1.05).toFixed(2),
                                netAmount: +(gross / 1.05).toFixed(2),
                              });
                            }}
                            className="w-24 p-1 border rounded bg-white text-xs text-right font-bold"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={editFormData.buildingRef || ''}
                            onChange={(e) =>
                              setEditFormData({ ...editFormData, buildingRef: e.target.value })
                            }
                            className="w-20 p-1 border rounded bg-white text-xs"
                          />
                        </td>
                        <td className="p-2 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => saveEdit(i.id)}
                              className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            >
                              <Save className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={cancelEdit}
                              className="p-1 text-slate-400 hover:bg-slate-100 rounded"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={i.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono font-medium text-indigo-700">
                        {i.invoiceNumber || 'N/A'}
                      </td>
                      <td className="py-3 px-4 text-slate-600">{i.invoiceDate}</td>
                      <td className="py-3 px-4 font-semibold text-slate-900">{i.supplierName}</td>
                      <td className="py-3 px-4 font-mono text-slate-600 text-[11px]">
                        {i.supplierTrn ? (
                          <span className="flex items-center gap-1 text-slate-700">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                            {i.supplierTrn}
                          </span>
                        ) : (
                          <span className="text-slate-400">Not recorded</span>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span className="inline-block px-2 py-0.5 rounded text-[10px] bg-slate-100 text-slate-700 font-medium">
                          {i.expenseCategory || 'Maintenance'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right text-slate-700 font-medium">
                        {formatAED(i.netAmount)}
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-emerald-600">
                        {formatAED(i.taxAmount)}
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-slate-900">
                        {formatAED(i.totalInvoiceAmount)}
                      </td>
                      <td className="py-3 px-4 text-slate-500">{i.buildingRef || '-'}</td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => setSelectedInvoice(i)}
                            className="p-1 text-slate-400 hover:text-indigo-600 rounded hover:bg-indigo-50 transition"
                            title="View Individual Summary"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          {canEdit && (
                            <>
                              <button
                                onClick={() => startEdit(i)}
                                className="p-1 text-slate-400 hover:text-indigo-600 rounded hover:bg-indigo-50 transition"
                                title="Edit"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDelete(i.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Individual Summary Modal */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                <div>
                  <h3 className="text-base font-bold text-slate-900">Purchase Tax Invoice Summary</h3>
                  <p className="text-xs text-slate-500">Invoice #{selectedInvoice.invoiceNumber}</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedInvoice(null)}
                className="text-slate-400 hover:text-slate-600 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-100 flex items-center justify-between">
                <div>
                  <span className="text-indigo-600 font-medium">Total Gross Invoice</span>
                  <div className="text-xl font-black text-indigo-950 mt-0.5">
                    {formatAED(selectedInvoice.totalInvoiceAmount)}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-emerald-700 font-medium">5% VAT Credit</span>
                  <div className="text-lg font-bold text-emerald-600 mt-0.5">
                    {formatAED(selectedInvoice.taxAmount)}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-2xl space-y-2 border border-slate-200/80">
                <div className="flex justify-between">
                  <span className="text-slate-500">Invoice Date:</span>
                  <span className="font-semibold text-slate-800">{selectedInvoice.invoiceDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Supplier Name:</span>
                  <span className="font-semibold text-slate-800">{selectedInvoice.supplierName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Supplier TRN (UAE):</span>
                  <span className="font-mono font-semibold text-slate-800">
                    {selectedInvoice.supplierTrn || 'N/A'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Expense Category:</span>
                  <span className="font-semibold text-slate-800">{selectedInvoice.expenseCategory}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Net Expense (Excl. VAT):</span>
                  <span className="font-semibold text-slate-800">{formatAED(selectedInvoice.netAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Property / Unit Ref:</span>
                  <span className="font-semibold text-slate-800">{selectedInvoice.buildingRef || 'N/A'}</span>
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button
                onClick={() => setSelectedInvoice(null)}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 rounded-xl hover:bg-indigo-700 transition"
              >
                Close Summary
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Modal */}
      {isAddingNew && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">Add Purchase Tax Invoice</h3>
              <button
                onClick={() => setIsAddingNew(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs">
              <div>
                <div className="flex items-center justify-between">
                  <label className="text-slate-600 font-medium">Invoice Number *</label>
                  {duplicateInvoiceMatch && (
                    <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.2 rounded">
                      Duplicate Invoice
                    </span>
                  )}
                </div>
                <input
                  type="text"
                  placeholder="e.g. INV-99201"
                  value={newInvoiceData.invoiceNumber || ''}
                  onChange={(e) =>
                    setNewInvoiceData({ ...newInvoiceData, invoiceNumber: e.target.value })
                  }
                  className={`mt-1 w-full p-2 border rounded-xl bg-slate-50 ${
                    duplicateInvoiceMatch ? 'border-amber-400 bg-amber-50/50 ring-2 ring-amber-300/40 text-amber-950 font-semibold' : ''
                  }`}
                />
                {duplicateInvoiceMatch && (
                  <div className="mt-1 flex items-start gap-1.5 text-[11px] text-amber-900 bg-amber-50 p-2 rounded-lg border border-amber-200">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Duplicate Invoice Warning: </span>
                      <span>Invoice #{newInvoiceData.invoiceNumber} already exists in database (Supplier: {duplicateInvoiceMatch.supplierName || 'Unknown'}, Date: {duplicateInvoiceMatch.invoiceDate || 'N/A'})</span>
                    </div>
                  </div>
                )}
              </div>
              <div>
                <label className="text-slate-600 font-medium">Invoice Date *</label>
                <input
                  type="date"
                  value={newInvoiceData.invoiceDate || ''}
                  onChange={(e) =>
                    setNewInvoiceData({ ...newInvoiceData, invoiceDate: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Supplier / Vendor Name *</label>
                <input
                  type="text"
                  placeholder="e.g. Al Futtaim Engineering, Emrill, Farnek"
                  value={newInvoiceData.supplierName || ''}
                  onChange={(e) =>
                    setNewInvoiceData({ ...newInvoiceData, supplierName: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Supplier TRN (15 digits)</label>
                <input
                  type="text"
                  placeholder="e.g. 100234567800003"
                  value={newInvoiceData.supplierTrn || ''}
                  onChange={(e) =>
                    setNewInvoiceData({ ...newInvoiceData, supplierTrn: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Expense Category</label>
                <input
                  type="text"
                  placeholder="e.g. Maintenance, HVAC, Plumbing, Electrical"
                  value={newInvoiceData.expenseCategory || 'Maintenance'}
                  onChange={(e) =>
                    setNewInvoiceData({ ...newInvoiceData, expenseCategory: e.target.value })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Total Gross Invoice Amount (AED) *</label>
                <input
                  type="number"
                  placeholder="Total including VAT"
                  value={newInvoiceData.totalInvoiceAmount || 0}
                  onChange={(e) => {
                    const gross = Number(e.target.value);
                    setNewInvoiceData({
                      ...newInvoiceData,
                      totalInvoiceAmount: gross,
                      taxAmount: +(gross - gross / 1.05).toFixed(2),
                      netAmount: +(gross / 1.05).toFixed(2),
                    });
                  }}
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50 font-bold"
                />
              </div>
              <div>
                <label className="text-slate-600 font-medium">Calculated 5% VAT (AED)</label>
                <input
                  type="number"
                  value={newInvoiceData.taxAmount || 0}
                  onChange={(e) =>
                    setNewInvoiceData({ ...newInvoiceData, taxAmount: Number(e.target.value) })
                  }
                  className="mt-1 w-full p-2 border rounded-xl bg-slate-50 font-semibold text-emerald-600"
                />
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-2.5">
              <button
                onClick={() => setIsAddingNew(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateNew}
                className="px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl transition shadow-xs"
              >
                Save Tax Invoice
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
