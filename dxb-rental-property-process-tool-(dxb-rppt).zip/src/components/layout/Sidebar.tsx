import React from 'react';
import {
  LayoutDashboard,
  UploadCloud,
  FileText,
  Receipt as ReceiptIcon,
  FileCheck2,
  Building2,
  Landmark,
  Scale,
  FileSpreadsheet,
  Users2,
  ShieldCheck,
  ChevronRight,
  LogOut,
  Sparkles,
} from 'lucide-react';
import { ActiveTab, UserRole } from '../../types';
import { useAuth } from '../../context/AuthContext';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenUpload: () => void;
  onOpenAuth: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onOpenUpload,
  onOpenAuth,
}) => {
  const { user, profile, role, switchDemoRole, signOut } = useAuth();

  const navItems = [
    { id: 'dashboard' as ActiveTab, label: 'Dashboard', icon: LayoutDashboard, badge: null },
    { id: 'upload' as ActiveTab, label: 'Document Intake', icon: UploadCloud, highlight: true },
    { id: 'contracts' as ActiveTab, label: 'Tenancy Contracts', icon: Building2, countKey: 'contracts' },
    { id: 'receipts' as ActiveTab, label: 'Rental Receipts', icon: ReceiptIcon, countKey: 'receipts' },
    { id: 'invoices' as ActiveTab, label: 'Purchase Tax Invoices', icon: FileCheck2, countKey: 'invoices' },
    { id: 'bank-statements' as ActiveTab, label: 'Bank Statements', icon: Landmark, countKey: 'statements' },
    { id: 'reconciliation' as ActiveTab, label: 'Bank Reconciliation', icon: Scale, badge: 'BRS' },
    { id: 'reports' as ActiveTab, label: 'Summary & Reports', icon: FileText, badge: null },
    { id: 'export' as ActiveTab, label: 'Zoho / Tally Export', icon: FileSpreadsheet, badge: 'UAE VAT' },
    { id: 'users' as ActiveTab, label: 'Team & RBAC', icon: Users2, badge: role.toUpperCase() },
  ];

  return (
    <aside className="w-72 bg-gradient-to-b from-[#0F294A] via-[#10315C] to-[#0D223F] text-white flex flex-col h-screen shrink-0 border-r border-blue-900/40 select-none shadow-xl">
      {/* Brand & App Title Header */}
      <div className="p-6 border-b border-blue-800/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-500 to-cyan-400 p-0.5 shadow-md shadow-blue-500/30 flex items-center justify-center">
            <div className="w-full h-full bg-[#0F294A] rounded-[10px] flex items-center justify-center">
              <span className="font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-cyan-200 to-white text-base">
                DXB
              </span>
            </div>
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <h1 className="text-sm font-bold tracking-tight text-white truncate">
                DXB-RPPT
              </h1>
              <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded-full bg-blue-500/20 text-cyan-300 border border-blue-400/30">
                PRO
              </span>
            </div>
            <p className="text-[11px] text-blue-200/70 truncate">
              UAE Rental Property Process Tool
            </p>
          </div>
        </div>

        {/* Quick Action: New Upload */}
        <button
          onClick={onOpenUpload}
          className="mt-4 w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white text-xs font-semibold shadow-md shadow-blue-600/30 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
          <span>Upload & AI Extract</span>
        </button>
      </div>

      {/* Navigation Links */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1 scrollbar-thin scrollbar-thumb-blue-800/40">
        <div className="px-3 pb-1 text-[10px] font-semibold tracking-wider uppercase text-blue-300/50">
          Core Workflows
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                if (item.id === 'upload') {
                  onOpenUpload();
                } else {
                  setActiveTab(item.id);
                }
              }}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all group cursor-pointer ${
                isActive
                  ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-700/40 translate-x-0.5'
                  : 'text-blue-100/80 hover:bg-white/10 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-white' : 'text-blue-300/70 group-hover:text-blue-200'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge && (
                <span
                  className={`text-[9px] font-semibold px-1.5 py-0.5 rounded tracking-wide ${
                    isActive
                      ? 'bg-white/20 text-white'
                      : 'bg-blue-900/60 text-cyan-300 border border-blue-700/40'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Role & User Footer */}
      <div className="p-4 bg-[#0a1e38] border-t border-blue-900/60">
        <div className="bg-white/5 border border-white/10 rounded-xl p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-cyan-400 to-blue-600 flex items-center justify-center text-white font-bold text-xs ring-2 ring-white/10 shrink-0">
                {profile?.displayName?.charAt(0) || user?.email?.charAt(0)?.toUpperCase() || 'A'}
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-white truncate">
                  {profile?.displayName || 'Finance Director'}
                </p>
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3 h-3 text-cyan-400 shrink-0" />
                  <span className="text-[10px] text-cyan-300 font-mono capitalize">
                    {role} Role
                  </span>
                </div>
              </div>
            </div>

            {user ? (
              <button
                onClick={signOut}
                title="Sign Out"
                className="p-1.5 text-blue-300/70 hover:text-rose-300 hover:bg-white/5 rounded-lg transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                onClick={onOpenAuth}
                className="text-[10px] px-2 py-1 rounded bg-blue-600/80 hover:bg-blue-600 text-white font-medium cursor-pointer"
              >
                Sign In
              </button>
            )}
          </div>

          {/* Quick RBAC Switcher for Reviewing Roles */}
          <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between text-[10px] text-blue-200/70">
            <span>Switch Role:</span>
            <div className="flex gap-1">
              {(['admin', 'accountant', 'manager', 'viewer'] as UserRole[]).map((r) => (
                <button
                  key={r}
                  onClick={() => switchDemoRole(r)}
                  className={`px-1.5 py-0.5 rounded text-[9px] font-mono uppercase transition-all cursor-pointer ${
                    role === r
                      ? 'bg-blue-500 text-white font-bold'
                      : 'bg-white/5 hover:bg-white/10 text-blue-200/80'
                  }`}
                >
                  {r.slice(0, 3)}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
};
