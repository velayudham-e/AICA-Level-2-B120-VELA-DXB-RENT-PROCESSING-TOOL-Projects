import React from 'react';
import {
  Search,
  Filter,
  Calendar,
  Building,
  Download,
  UploadCloud,
  Coins,
  Shield,
} from 'lucide-react';
import { usePropertyData } from '../../context/PropertyDataContext';
import { useAuth } from '../../context/AuthContext';
import { ActiveTab } from '../../types';

interface HeaderProps {
  activeTab: ActiveTab;
  onOpenUpload: () => void;
  onOpenExport: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onOpenUpload,
  onOpenExport,
}) => {
  const { filters, setFilters, propertiesList } = usePropertyData();
  const { role } = useAuth();

  const titles: Record<ActiveTab, { title: string; subtitle: string }> = {
    dashboard: {
      title: 'Executive Financial Dashboard',
      subtitle: 'Real-time UAE rental income, VAT reconciliations, and expense summaries in AED',
    },
    upload: {
      title: 'Document Intake & AI OCR',
      subtitle: 'Extract UAE Ejari contracts, receipts, bank statements & purchase tax invoices',
    },
    contracts: {
      title: 'Tenancy Contracts (Ejari)',
      subtitle: 'Dubai Land Department registered contracts with duplicate property prevention',
    },
    receipts: {
      title: 'Rental Receipts & Cheques',
      subtitle: 'Cheque tracking, installment dates, and bank clearance verification',
    },
    invoices: {
      title: 'Purchase Tax Invoices (5% VAT)',
      subtitle: 'Maintenance expenses, contractor TRNs, input tax credits & duplicate guards',
    },
    'bank-statements': {
      title: 'Bank Statement Transactions',
      subtitle: 'Emirates NBD, ADCB, FAB, DIB statements with debit/credit ledger tracking',
    },
    reconciliation: {
      title: 'Bank Reconciliation Statement (BRS)',
      subtitle: 'Automated 2-way matching between bank statements, rent receipts & expenses',
    },
    reports: {
      title: 'Property & Financial Summaries',
      subtitle: 'Batch and individual performance breakdowns filtered by property & period',
    },
    export: {
      title: 'Accounting Exports',
      subtitle: 'Dedicated export formats for Zoho Books UAE and Tally Prime (UAE VAT)',
    },
    users: {
      title: 'Team & Role-Based Access Control',
      subtitle: 'Manage administrative roles, permissions, and audit privileges',
    },
  };

  const currentMeta = titles[activeTab] || titles.dashboard;

  return (
    <header className="h-20 bg-white/80 backdrop-blur-md border-b border-slate-200/80 px-8 flex items-center justify-between sticky top-0 z-20">
      {/* Title & Section Meta */}
      <div className="min-w-0">
        <div className="flex items-center gap-2.5">
          <h2 className="text-xl font-bold tracking-tight text-slate-900 truncate">
            {currentMeta.title}
          </h2>
          <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-[11px] font-semibold">
            <Coins className="w-3 h-3 text-blue-600" />
            <span>UAE Dirham (AED)</span>
          </div>
        </div>
        <p className="text-xs text-slate-500 truncate mt-0.5">
          {currentMeta.subtitle}
        </p>
      </div>

      {/* Global Filter & Action Controls */}
      <div className="flex items-center gap-3">
        {/* Search Input */}
        <div className="relative w-56">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search records, cheque, unit..."
            value={filters.searchTerm}
            onChange={(e) => setFilters((prev) => ({ ...prev, searchTerm: e.target.value }))}
            className="w-full pl-8 pr-3 py-1.5 bg-slate-100/80 hover:bg-slate-100 focus:bg-white rounded-xl text-xs text-slate-800 placeholder-slate-400 border border-slate-200/80 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 outline-none transition-all"
          />
        </div>

        {/* Property Filter Dropdown */}
        <div className="flex items-center gap-1.5 bg-slate-100/80 px-2.5 py-1.5 rounded-xl border border-slate-200/80 text-xs">
          <Building className="w-3.5 h-3.5 text-slate-500" />
          <select
            value={filters.propertyFilter}
            onChange={(e) => setFilters((prev) => ({ ...prev, propertyFilter: e.target.value }))}
            className="bg-transparent text-xs text-slate-700 font-medium outline-none cursor-pointer pr-1"
          >
            <option value="ALL">All Properties</option>
            {propertiesList.map((p) => (
              <option key={p} value={p}>
                {p}
              </option>
            ))}
          </select>
        </div>

        {/* Period Filter Dropdown */}
        <div className="flex items-center gap-1.5 bg-slate-100/80 px-2.5 py-1.5 rounded-xl border border-slate-200/80 text-xs">
          <Calendar className="w-3.5 h-3.5 text-slate-500" />
          <select
            value={filters.periodFilter}
            onChange={(e) =>
              setFilters((prev) => ({
                ...prev,
                periodFilter: e.target.value as any,
              }))
            }
            className="bg-transparent text-xs text-slate-700 font-medium outline-none cursor-pointer pr-1"
          >
            <option value="ALL">All Periods</option>
            <option value="THIS_YEAR">Year 2026</option>
          </select>
        </div>

        {/* Quick Action: Export */}
        <button
          onClick={onOpenExport}
          className="flex items-center gap-1.5 py-1.5 px-3 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-700 text-xs font-semibold border border-slate-200 transition-all cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-slate-600" />
          <span>Export</span>
        </button>

        {/* Active Role Indicator */}
        <div className="hidden lg:flex items-center gap-1 px-2.5 py-1 rounded-xl bg-blue-50/80 border border-blue-200/70 text-[11px] font-medium text-blue-800">
          <Shield className="w-3 h-3 text-blue-600" />
          <span className="capitalize">{role}</span>
        </div>
      </div>
    </header>
  );
};
