import React, { useState } from 'react';
import {
  FileText,
  Building,
  Receipt as ReceiptIcon,
  FileCheck2,
  Landmark,
  Filter,
  Calendar,
  Layers,
  Sparkles,
  Download,
  Percent,
  CheckCircle2,
  ChevronDown,
} from 'lucide-react';
import { usePropertyData } from '../../context/PropertyDataContext';
import { TenancyContract, Receipt, PurchaseInvoice, BankStatement } from '../../types';

export const ReportsAndSummary: React.FC = () => {
  const {
    filteredContracts,
    filteredReceipts,
    filteredInvoices,
    filteredStatements,
    metrics,
    filters,
    setFilters,
    propertiesList,
  } = usePropertyData();

  const [activeReportTab, setActiveReportTab] = useState<
    'batch' | 'contract' | 'receipt' | 'invoice' | 'statement'
  >('batch');

  const [selectedContractId, setSelectedContractId] = useState<string>('');
  const [selectedReceiptId, setSelectedReceiptId] = useState<string>('');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>('');
  const [selectedStatementId, setSelectedStatementId] = useState<string>('');

  const formatAED = (val: number) => `AED ${val.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;

  const selectedContract = filteredContracts.find((c) => c.id === selectedContractId) || filteredContracts[0];
  const selectedReceipt = filteredReceipts.find((r) => r.id === selectedReceiptId) || filteredReceipts[0];
  const selectedInvoice = filteredInvoices.find((i) => i.id === selectedInvoiceId) || filteredInvoices[0];
  const selectedStatement = filteredStatements.find((s) => s.id === selectedStatementId) || filteredStatements[0];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Title & Filter Bar */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileText className="w-5 h-5 text-blue-600" />
            <span>Audited Summary Reports</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Individual and batch level summaries for UAE Tenancy Contracts, Receipts, Tax Invoices, and Bank Statements.
          </p>
        </div>

        {/* Property & Period Filters */}
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-xl text-xs border border-slate-200">
            <Building className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={filters.propertyFilter}
              onChange={(e) => setFilters((prev) => ({ ...prev, propertyFilter: e.target.value }))}
              className="bg-transparent font-medium text-slate-700 outline-none cursor-pointer"
            >
              <option value="ALL">All Properties</option>
              {propertiesList.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-xl text-xs border border-slate-200">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <select
              value={filters.periodFilter}
              onChange={(e) => setFilters((prev) => ({ ...prev, periodFilter: e.target.value as any }))}
              className="bg-transparent font-medium text-slate-700 outline-none cursor-pointer"
            >
              <option value="ALL">All Periods</option>
              <option value="THIS_YEAR">Year 2026</option>
            </select>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveReportTab('batch')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeReportTab === 'batch'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Batch Executive Summary
        </button>
        <button
          onClick={() => setActiveReportTab('contract')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeReportTab === 'contract'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Individual Contract Summary
        </button>
        <button
          onClick={() => setActiveReportTab('receipt')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeReportTab === 'receipt'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Individual Receipt Summary
        </button>
        <button
          onClick={() => setActiveReportTab('invoice')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeReportTab === 'invoice'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Individual Tax Invoice Summary
        </button>
        <button
          onClick={() => setActiveReportTab('statement')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeReportTab === 'statement'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Individual Bank Statement Summary
        </button>
      </div>

      {/* Tab 1: Batch Executive Summary */}
      {activeReportTab === 'batch' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 pb-4">
            <div>
              <h3 className="text-lg font-extrabold text-slate-900 tracking-tight">
                Batch Portfolio Performance Summary
              </h3>
              <p className="text-xs text-slate-500">
                Consolidated financials for property: <span className="font-semibold text-slate-800">{filters.propertyFilter}</span>
              </p>
            </div>
            <div className="text-right">
              <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold block">
                Official Currency
              </span>
              <span className="text-sm font-bold text-blue-700">United Arab Emirates Dirham (AED)</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-semibold uppercase">Total Contract Amount</span>
              <div className="text-2xl font-bold text-slate-900 font-mono mt-1">
                {formatAED(metrics.totalContractAmount)}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {filteredContracts.length} Tenancy contracts in batch
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-semibold uppercase">Total Actual Annual Amount</span>
              <div className="text-2xl font-bold text-emerald-700 font-mono mt-1">
                {formatAED(metrics.totalActualAnnualAmount)}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Annualized rental yield basis</span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-semibold uppercase">Total Security Deposit</span>
              <div className="text-2xl font-bold text-amber-700 font-mono mt-1">
                {formatAED(metrics.totalSecurityDeposit)}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Held in tenant escrow</span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-semibold uppercase">Total Receipts Collected</span>
              <div className="text-2xl font-bold text-indigo-700 font-mono mt-1">
                {formatAED(metrics.totalReceipts)}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {filteredReceipts.length} Cheque receipts deposited
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-semibold uppercase">Purchase Maintenance Exp</span>
              <div className="text-2xl font-bold text-rose-600 font-mono mt-1">
                {formatAED(metrics.totalPurchaseMaintenanceExp)}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">
                {filteredInvoices.length} Supplier tax invoices
              </span>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
              <span className="text-xs text-slate-500 font-semibold uppercase">Total VAT on Purchase Invoices (5%)</span>
              <div className="text-2xl font-bold text-orange-600 font-mono mt-1">
                {formatAED(metrics.totalVATOnPurchaseInvoice)}
              </div>
              <span className="text-[11px] text-slate-400 mt-1 block">Input tax credit refundable</span>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-blue-50/70 border border-blue-200 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <span className="text-xs font-bold text-blue-900 uppercase tracking-wider block">
                Net Rent Income
              </span>
              <span className="text-[11px] text-blue-600 block">Actual Annual Rent - Maintenance Exp</span>
              <div className="text-2xl font-extrabold text-blue-900 font-mono mt-1">
                {formatAED(metrics.netRentIncome)}
              </div>
            </div>

            <div>
              <span className="text-xs font-bold text-blue-900 uppercase tracking-wider block">
                Total VAT on Actual Rent
              </span>
              <span className="text-[11px] text-blue-600 block">Output Tax (Commercial 5%)</span>
              <div className="text-2xl font-extrabold text-blue-900 font-mono mt-1">
                {formatAED(metrics.totalVATOnActualRent)}
              </div>
            </div>

            <div>
              <span className="text-xs font-bold text-blue-900 uppercase tracking-wider block">
                Net VAT Payable / (Refundable)
              </span>
              <span className="text-[11px] text-blue-600 block">Output VAT - Input VAT</span>
              <div className="text-2xl font-extrabold text-indigo-950 font-mono mt-1">
                {formatAED(metrics.netVAT)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Individual Tenancy Contract Summary */}
      {activeReportTab === 'contract' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Individual Tenancy Contract Ejari Summary
              </h3>
              <p className="text-xs text-slate-500">
                Full legal and financial breakdown as per UAE Land Department standards.
              </p>
            </div>

            {filteredContracts.length > 0 && (
              <div className="flex items-center gap-2">
                <span className="text-xs font-medium text-slate-600">Select Contract:</span>
                <select
                  value={selectedContract?.id}
                  onChange={(e) => setSelectedContractId(e.target.value)}
                  className="p-2 bg-slate-100 rounded-xl text-xs font-semibold border border-slate-200"
                >
                  {filteredContracts.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.propertyNo} — {c.tenantName}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>

          {!selectedContract ? (
            <p className="text-center py-8 text-slate-400 text-xs">No contract selected or available.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border space-y-1">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Property Number</span>
                <p className="font-bold text-slate-900 text-base">{selectedContract.propertyNo}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border space-y-1">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Building / Community</span>
                <p className="font-bold text-slate-900 text-base">{selectedContract.buildingName || '—'}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border space-y-1">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Tenant Name</span>
                <p className="font-bold text-slate-900 text-base">{selectedContract.tenantName}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border space-y-1">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Owner Name</span>
                <p className="font-semibold text-slate-800 text-sm">{selectedContract.ownerName || '—'}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border space-y-1">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Lessor Name</span>
                <p className="font-semibold text-slate-800 text-sm">{selectedContract.lessorName || '—'}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border space-y-1">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Classification & Subtype</span>
                <p className="font-semibold text-slate-800 text-sm">
                  {selectedContract.type} • {selectedContract.subType} ({selectedContract.size ? `${selectedContract.size} sq ft` : '—'})
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 space-y-1">
                <span className="text-blue-600 uppercase font-bold text-[10px]">Contract Amount (AED)</span>
                <p className="font-extrabold text-blue-900 text-lg font-mono">
                  {formatAED(selectedContract.contractAmount)}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-1">
                <span className="text-emerald-600 uppercase font-bold text-[10px]">Actual Annual Amount (AED)</span>
                <p className="font-extrabold text-emerald-900 text-lg font-mono">
                  {formatAED(selectedContract.actualAnnualAmount)}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-1">
                <span className="text-amber-600 uppercase font-bold text-[10px]">Security Deposit (AED)</span>
                <p className="font-extrabold text-amber-900 text-lg font-mono">
                  {formatAED(selectedContract.securityDeposit)}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border space-y-1">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Contract Period</span>
                <p className="font-semibold text-slate-800">
                  {selectedContract.startDate} to {selectedContract.endDate}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border space-y-1">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Ejari Registration Date</span>
                <p className="font-semibold text-slate-800">{selectedContract.registrationDate || '—'}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border space-y-1">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">UAE VAT Rate & Amount</span>
                <p className="font-semibold text-slate-800">
                  {selectedContract.vatRate}% ({formatAED(selectedContract.vatAmount || 0)})
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Individual Receipt Summary */}
      {activeReportTab === 'receipt' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Individual Rental Receipt Summary</h3>
              <p className="text-xs text-slate-500">Installment date, cheque number, and bank clearance details.</p>
            </div>
            {filteredReceipts.length > 0 && (
              <select
                value={selectedReceipt?.id}
                onChange={(e) => setSelectedReceiptId(e.target.value)}
                className="p-2 bg-slate-100 rounded-xl text-xs font-semibold border border-slate-200"
              >
                {filteredReceipts.map((r) => (
                  <option key={r.id} value={r.id}>
                    Chq #{r.chequeNo} — AED {r.amount}
                  </option>
                ))}
              </select>
            )}
          </div>

          {!selectedReceipt ? (
            <p className="text-center py-8 text-slate-400 text-xs">No receipt available.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Installment Date</span>
                <p className="font-bold text-slate-900 text-sm mt-1">{selectedReceipt.installmentDate}</p>
              </div>
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
                <span className="text-emerald-700 uppercase font-bold text-[10px]">Receipt Amount (AED)</span>
                <p className="font-extrabold text-emerald-800 text-base font-mono mt-1">
                  {formatAED(selectedReceipt.amount)}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Cheque Number</span>
                <p className="font-bold text-slate-900 font-mono text-sm mt-1">{selectedReceipt.chequeNo}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Drawee Bank Name</span>
                <p className="font-semibold text-slate-800 text-sm mt-1">{selectedReceipt.bankName}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Individual Purchase Tax Invoice Summary */}
      {activeReportTab === 'invoice' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Purchase Tax Invoice Summary</h3>
              <p className="text-xs text-slate-500">
                Invoice number, date, supplier TRN, taxable amount, and 5% UAE VAT credit.
              </p>
            </div>
            {filteredInvoices.length > 0 && (
              <select
                value={selectedInvoice?.id}
                onChange={(e) => setSelectedInvoiceId(e.target.value)}
                className="p-2 bg-slate-100 rounded-xl text-xs font-semibold border border-slate-200"
              >
                {filteredInvoices.map((inv) => (
                  <option key={inv.id} value={inv.id}>
                    #{inv.invoiceNumber} — {inv.supplierName}
                  </option>
                ))}
              </select>
            )}
          </div>

          {!selectedInvoice ? (
            <p className="text-center py-8 text-slate-400 text-xs">No invoice available.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Invoice Number & Date</span>
                <p className="font-bold text-slate-900 text-sm mt-1">
                  #{selectedInvoice.invoiceNumber} ({selectedInvoice.invoiceDate})
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Supplier & TRN</span>
                <p className="font-bold text-slate-900 text-sm mt-1">{selectedInvoice.supplierName}</p>
                <p className="text-slate-400 font-mono">{selectedInvoice.supplierTRN || 'No TRN'}</p>
              </div>
              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200">
                <span className="text-rose-700 uppercase font-bold text-[10px]">Total Invoice Amount (AED)</span>
                <p className="font-extrabold text-rose-800 text-base font-mono mt-1">
                  {formatAED(selectedInvoice.totalInvoiceAmount)}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200">
                <span className="text-amber-700 uppercase font-bold text-[10px]">VAT 5% Amount (AED)</span>
                <p className="font-extrabold text-amber-800 text-base font-mono mt-1">
                  {formatAED(selectedInvoice.taxAmount)}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Serviced Property</span>
                <p className="font-semibold text-slate-800 text-sm mt-1">
                  {selectedInvoice.propertyNo || 'General'} • {selectedInvoice.buildingName || ''}
                </p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Scope Description</span>
                <p className="text-slate-700 text-xs mt-1">{selectedInvoice.description}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 5: Individual Bank Statement Summary */}
      {activeReportTab === 'statement' && (
        <div className="bg-white rounded-3xl p-8 border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Bank Statement Transaction Summary</h3>
              <p className="text-xs text-slate-500">Transaction name, cheque number, debit, credit, and running balance.</p>
            </div>
            {filteredStatements.length > 0 && (
              <select
                value={selectedStatement?.id}
                onChange={(e) => setSelectedStatementId(e.target.value)}
                className="p-2 bg-slate-100 rounded-xl text-xs font-semibold border border-slate-200"
              >
                {filteredStatements.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.transactionDate} — {s.transactionName}
                  </option>
                ))}
              </select>
            )}
          </div>

          {!selectedStatement ? (
            <p className="text-center py-8 text-slate-400 text-xs">No bank statement line available.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Transaction Date</span>
                <p className="font-bold text-slate-900 text-sm mt-1">{selectedStatement.transactionDate}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Transaction Name</span>
                <p className="font-bold text-slate-900 text-sm mt-1">{selectedStatement.transactionName}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Cheque Number</span>
                <p className="font-mono text-slate-900 text-sm mt-1">{selectedStatement.chequeNumber || '—'}</p>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50 border">
                <span className="text-slate-400 uppercase font-semibold text-[10px]">Debit / Credit</span>
                <p className="font-mono font-bold text-sm mt-1">
                  {selectedStatement.creditAmount > 0
                    ? `+AED ${selectedStatement.creditAmount.toLocaleString()}`
                    : `-AED ${selectedStatement.debitAmount.toLocaleString()}`}
                </p>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
