import React, { useState } from 'react';
import {
  Scale,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Unlink,
  Link as LinkIcon,
  Download,
  Building,
  Receipt as ReceiptIcon,
  FileCheck2,
  ArrowRight,
  RefreshCw,
  Landmark,
  ShieldCheck,
} from 'lucide-react';
import { usePropertyData } from '../../context/PropertyDataContext';
import { useAuth } from '../../context/AuthContext';
import { BankStatement, Receipt, PurchaseInvoice } from '../../types';

export const BankReconciliationWorkbench: React.FC = () => {
  const {
    bankStatements,
    receipts,
    invoices,
    autoReconcile,
    manualMatch,
    unmatchTransaction,
  } = usePropertyData();
  const { canReconcile } = useAuth();

  const [notification, setNotification] = useState<string | null>(null);
  const [selectedBankTx, setSelectedBankTx] = useState<BankStatement | null>(null);
  const [manualMatchModalOpen, setManualMatchModalOpen] = useState<boolean>(false);

  const handleRunAutoMatch = () => {
    const result = autoReconcile();
    setNotification(
      `Auto-Reconciliation Complete: Successfully matched ${result.matchedCount} transactions totaling AED ${result.matchedAmount.toLocaleString()}.`
    );
    setTimeout(() => setNotification(null), 5000);
  };

  // BRS Mathematical Computations
  // 1. Ending bank balance (from latest bank statement or sum of net balances)
  const latestBankBalance =
    bankStatements.length > 0 ? bankStatements[0].netBalance || 0 : 0;

  // 2. Uncredited Receipts (cheques recorded in books but not yet matched to bank statement credit)
  const uncreditedReceipts = receipts.filter((r) => !r.matchedBankTxId);
  const totalUncreditedReceipts = uncreditedReceipts.reduce((sum, r) => sum + (r.amount || 0), 0);

  // 3. Unpresented Debits / Invoices (maintenance expenses recorded but not yet cleared in bank)
  const unpresentedInvoices = invoices.filter((i) => !i.matchedBankTxId);
  const totalUnpresentedInvoices = unpresentedInvoices.reduce(
    (sum, i) => sum + (i.totalInvoiceAmount || 0),
    0
  );

  // Reconciled Book Balance = Bank Balance + Uncredited Receipts - Unpresented Invoices
  const reconciledBookBalance =
    latestBankBalance + totalUncreditedReceipts - totalUnpresentedInvoices;

  const totalMatchedCount = bankStatements.filter((b) => b.reconciliationStatus === 'Matched').length;
  const matchPercentage =
    bankStatements.length > 0
      ? Math.round((totalMatchedCount / bankStatements.length) * 100)
      : 100;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Scale className="w-5 h-5 text-indigo-600" />
            <span>Bank Reconciliation Statement (BRS)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            2-Way Automated Matching: Match rent receipts with bank credit and maintenance expenses with bank debit.
          </p>
        </div>

        {canReconcile && (
          <div className="flex items-center gap-3">
            <button
              onClick={handleRunAutoMatch}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md shadow-indigo-600/30 transition-all active:scale-95 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-cyan-200" />
              <span>Run Smart Auto-Match</span>
            </button>
          </div>
        )}
      </div>

      {/* Notification Banner */}
      {notification && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="text-xs font-bold">{notification}</span>
        </div>
      )}

      {/* BRS Statement Card: Official Accounting Presentation */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-slate-200 pb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 tracking-tight">
              Bank Reconciliation Summary (AED)
            </h3>
            <span className="text-xs text-slate-500">
              Audited statement of difference between Bank Statement balance and General Ledger
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-600">Reconciliation Progress:</span>
            <span className="px-2.5 py-1 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 font-mono font-bold text-xs">
              {matchPercentage}% Cleared
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
              Balance per Bank Statement
            </span>
            <div className="text-xl font-extrabold text-slate-900 font-mono mt-1">
              AED {latestBankBalance.toLocaleString()}
            </div>
            <span className="text-[10px] text-slate-400 mt-1 block">Closing statement balance</span>
          </div>

          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
            <span className="text-[11px] font-semibold text-emerald-700 uppercase tracking-wider block">
              (+) Uncredited Rent Receipts
            </span>
            <div className="text-xl font-extrabold text-emerald-700 font-mono mt-1">
              +AED {totalUncreditedReceipts.toLocaleString()}
            </div>
            <span className="text-[10px] text-emerald-600 mt-1 block">
              {uncreditedReceipts.length} cheques awaiting clearance
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200">
            <span className="text-[11px] font-semibold text-rose-700 uppercase tracking-wider block">
              (-) Unpresented Invoices
            </span>
            <div className="text-xl font-extrabold text-rose-700 font-mono mt-1">
              -AED {totalUnpresentedInvoices.toLocaleString()}
            </div>
            <span className="text-[10px] text-rose-600 mt-1 block">
              {unpresentedInvoices.length} maintenance bills in transit
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-indigo-50 border border-indigo-200">
            <span className="text-[11px] font-semibold text-indigo-700 uppercase tracking-wider block">
              (=) Reconciled Book Balance
            </span>
            <div className="text-xl font-extrabold text-indigo-900 font-mono mt-1">
              AED {reconciledBookBalance.toLocaleString()}
            </div>
            <span className="text-[10px] text-indigo-600 mt-1 block">Adjusted General Ledger value</span>
          </div>
        </div>
      </div>

      {/* 2-Column Matching Workbench */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left Column: Bank Statement Transactions */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2">
              <Landmark className="w-4 h-4 text-indigo-600" />
              <h4 className="text-sm font-bold text-slate-900">
                Bank Statement Transactions ({bankStatements.length})
              </h4>
            </div>
            <span className="text-[11px] text-slate-400">Click to link manually</span>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {bankStatements.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                No bank statements loaded. Upload statement or add lines.
              </div>
            ) : (
              bankStatements.map((b) => {
                const isMatched = b.reconciliationStatus === 'Matched';
                const isCredit = b.creditAmount > 0;

                return (
                  <div
                    key={b.id}
                    className={`p-3 rounded-2xl border transition-all ${
                      isMatched
                        ? 'border-emerald-200 bg-emerald-50/30'
                        : 'border-slate-200 hover:border-indigo-400 bg-white'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-400 font-mono">
                            {b.transactionDate}
                          </span>
                          {b.chequeNumber && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-100 font-mono font-semibold text-slate-700">
                              Chq #{b.chequeNumber}
                            </span>
                          )}
                        </div>
                        <p className="text-xs font-semibold text-slate-900 truncate mt-0.5">
                          {b.transactionName}
                        </p>
                      </div>

                      <div className="text-right shrink-0">
                        <div
                          className={`text-xs font-bold font-mono ${
                            isCredit ? 'text-emerald-600' : 'text-rose-600'
                          }`}
                        >
                          {isCredit ? `+AED ${b.creditAmount.toLocaleString()}` : `-AED ${b.debitAmount.toLocaleString()}`}
                        </div>
                        <div className="flex items-center justify-end gap-1 mt-1">
                          {isMatched ? (
                            <div className="flex items-center gap-1">
                              <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-0.5">
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                <span>Matched</span>
                              </span>
                              {canReconcile && (
                                <button
                                  onClick={() => unmatchTransaction(b.id)}
                                  className="text-[10px] text-slate-400 hover:text-rose-600 ml-1 underline cursor-pointer"
                                >
                                  Unlink
                                </button>
                              )}
                            </div>
                          ) : (
                            canReconcile && (
                              <button
                                onClick={() => {
                                  setSelectedBankTx(b);
                                  setManualMatchModalOpen(true);
                                }}
                                className="text-[10px] px-2 py-0.5 rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold border border-indigo-200 cursor-pointer"
                              >
                                Match With...
                              </button>
                            )
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Internal Book Records (Receipts & Tax Invoices) */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <h4 className="text-sm font-bold text-slate-900">
                Book Records (Rent Receipts & Maintenance Bills)
              </h4>
            </div>
            <span className="text-[11px] text-slate-400">
              Receipts: {receipts.length} • Bills: {invoices.length}
            </span>
          </div>

          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
            {/* Receipts Category */}
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Rental Receipts (Target Credit Matches)
              </span>
              <div className="space-y-1.5">
                {receipts.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No receipts recorded.</p>
                ) : (
                  receipts.map((r) => (
                    <div
                      key={r.id}
                      className={`p-2.5 rounded-xl border text-xs flex items-center justify-between ${
                        r.matchedBankTxId
                          ? 'border-emerald-200 bg-emerald-50/30'
                          : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div>
                        <div className="font-semibold text-slate-800">
                          {r.tenantName || 'Tenant'} • Chq #{r.chequeNo}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {r.installmentDate} • {r.bankName}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-emerald-700">
                          AED {r.amount.toLocaleString()}
                        </div>
                        <span
                          className={`text-[9px] font-semibold ${
                            r.matchedBankTxId ? 'text-emerald-600' : 'text-amber-600'
                          }`}
                        >
                          {r.matchedBankTxId ? 'Cleared in Bank' : 'Unpresented'}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Invoices Category */}
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Purchase Maintenance Bills (Target Debit Matches)
              </span>
              <div className="space-y-1.5">
                {invoices.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No purchase invoices recorded.</p>
                ) : (
                  invoices.map((inv) => (
                    <div
                      key={inv.id}
                      className={`p-2.5 rounded-xl border text-xs flex items-center justify-between ${
                        inv.matchedBankTxId
                          ? 'border-emerald-200 bg-emerald-50/30'
                          : 'border-slate-200 bg-white'
                      }`}
                    >
                      <div>
                        <div className="font-semibold text-slate-800">
                          {inv.supplierName} • #{inv.invoiceNumber}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {inv.invoiceDate} • {inv.propertyNo || 'Property'}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="font-mono font-bold text-rose-600">
                          AED {inv.totalInvoiceAmount.toLocaleString()}
                        </div>
                        <span
                          className={`text-[9px] font-semibold ${
                            inv.matchedBankTxId ? 'text-emerald-600' : 'text-amber-600'
                          }`}
                        >
                          {inv.matchedBankTxId ? 'Paid in Bank' : 'Pending Debit'}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Manual Link Modal */}
      {manualMatchModalOpen && selectedBankTx && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl border border-slate-200 p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="border-b border-slate-200 pb-3">
              <h3 className="text-sm font-bold text-slate-900">
                Match Bank Statement Transaction
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Selected Transaction: <span className="font-semibold">{selectedBankTx.transactionName}</span> (
                {selectedBankTx.creditAmount > 0
                  ? `Credit AED ${selectedBankTx.creditAmount}`
                  : `Debit AED ${selectedBankTx.debitAmount}`}
                )
              </p>
            </div>

            <div className="space-y-3">
              <span className="text-xs font-semibold text-slate-700 block">
                Choose corresponding internal book item:
              </span>

              {selectedBankTx.creditAmount > 0 ? (
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {receipts
                    .filter((r) => !r.matchedBankTxId)
                    .map((r) => (
                      <button
                        key={r.id}
                        onClick={() => {
                          manualMatch(selectedBankTx.id, 'Receipt', r.id);
                          setManualMatchModalOpen(false);
                          setSelectedBankTx(null);
                        }}
                        className="w-full text-left p-3 rounded-xl border border-slate-200 hover:border-emerald-500 hover:bg-emerald-50/50 flex items-center justify-between text-xs cursor-pointer"
                      >
                        <div>
                          <div className="font-semibold text-slate-800">
                            Receipt: {r.tenantName} (Chq #{r.chequeNo})
                          </div>
                          <div className="text-[11px] text-slate-400">{r.installmentDate}</div>
                        </div>
                        <div className="font-mono font-bold text-emerald-700">
                          AED {r.amount.toLocaleString()}
                        </div>
                      </button>
                    ))}
                </div>
              ) : (
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {invoices
                    .filter((inv) => !inv.matchedBankTxId)
                    .map((inv) => (
                      <button
                        key={inv.id}
                        onClick={() => {
                          manualMatch(selectedBankTx.id, 'PurchaseInvoice', inv.id);
                          setManualMatchModalOpen(false);
                          setSelectedBankTx(null);
                        }}
                        className="w-full text-left p-3 rounded-xl border border-slate-200 hover:border-amber-500 hover:bg-amber-50/50 flex items-center justify-between text-xs cursor-pointer"
                      >
                        <div>
                          <div className="font-semibold text-slate-800">
                            Invoice: {inv.supplierName} (#{inv.invoiceNumber})
                          </div>
                          <div className="text-[11px] text-slate-400">{inv.invoiceDate}</div>
                        </div>
                        <div className="font-mono font-bold text-rose-600">
                          AED {inv.totalInvoiceAmount.toLocaleString()}
                        </div>
                      </button>
                    ))}
                </div>
              )}
            </div>

            <div className="flex justify-end pt-3 border-t border-slate-200">
              <button
                onClick={() => {
                  setManualMatchModalOpen(false);
                  setSelectedBankTx(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
