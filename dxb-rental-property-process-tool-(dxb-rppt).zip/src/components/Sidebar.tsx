import React from 'react';
import {
  LayoutDashboard,
  UploadCloud,
  FileText,
  Receipt,
  FileSpreadsheet,
  PieChart,
  Shield,
  LogOut,
  LogIn,
  Building2,
  ChevronRight,
  Sparkles,
  Layers,
  CreditCard,
  UserCheck,
  Landmark,
} from 'lucide-react';
import { ActiveTab, UserRole } from '../types';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  onOpenAuth: () => void;
  counts: {
    contracts: number;
    receipts: number;
    invoices: number;
  };
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  onOpenAuth,
  counts,
}) => {
  const { user, profile, activeRole, logout, isAdmin } = useAuth();

  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Executive Dashboard',
      icon: LayoutDashboard,
      badge: null,
    },
    {
      id: 'upload' as ActiveTab,
      label: 'Upload & Process',
      icon: UploadCloud,
      badge: 'AI OCR',
    },
    {
      id: 'contracts' as ActiveTab,
      label: 'Tenancy Contracts',
      icon: Building2,
      badge: counts.contracts > 0 ? String(counts.contracts) : null,
    },
    {
      id: 'receipts' as ActiveTab,
      label: 'Rental Receipts',
      icon: Receipt,
      badge: counts.receipts > 0 ? String(counts.receipts) : null,
    },
    {
      id: 'invoices' as ActiveTab,
      label: 'Purchase Tax Invoices',
      icon: CreditCard,
      badge: counts.invoices > 0 ? String(counts.invoices) : null,
    },
    {
      id: 'bank-reconciliation' as ActiveTab,
      label: 'Bank Reconciliation',
      icon: Landmark,
      badge: 'BRS',
    },
    {
      id: 'reports' as ActiveTab,
      label: 'Reports & Export',
      icon: FileSpreadsheet,
      badge: 'Zoho / Tally',
    },
    {
      id: 'roles' as ActiveTab,
      label: 'Team & Roles',
      icon: Shield,
      badge: 'RBAC',
    },
  ];

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case 'admin':
        return 'bg-purple-500/20 text-purple-300 border-purple-400/40';
      case 'manager':
        return 'bg-blue-500/20 text-blue-300 border-blue-400/40';
      case 'accountant':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40';
      default:
        return 'bg-slate-500/20 text-slate-300 border-slate-400/40';
    }
  };

  return (
    <aside className="w-64 md:w-72 bg-gradient-to-b from-[#0A2540] via-[#0E2F56] to-[#081B30] text-white flex flex-col justify-between shrink-0 h-screen sticky top-0 border-r border-[#1E3E62]/40 shadow-xl select-none">
      {/* Brand & Top Header */}
      <div>
        <div className="p-6 pb-4 border-b border-[#1E3E62]/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20 ring-1 ring-white/20">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base font-extrabold tracking-tight text-white">
                  DXB-RPPT
                </span>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-blue-500/30 text-blue-300 border border-blue-400/30 px-1.5 py-0.2 rounded-md">
                  UAE
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Rental Process Tool</p>
            </div>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="p-3 space-y-1.5">
          <div className="px-3 pt-2 pb-1 text-[10px] font-bold uppercase tracking-widest text-slate-400">
            Workspaces
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all duration-150 group ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isActive ? 'text-white' : 'text-slate-400 group-hover:text-blue-300'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge && (
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isActive
                        ? 'bg-white/20 text-white'
                        : 'bg-white/10 text-slate-300 group-hover:bg-white/15'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* User Session & Role Card at bottom */}
      <div className="p-3 border-t border-[#1E3E62]/60 bg-[#081B30]/70">
        {user ? (
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 overflow-hidden">
                <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs ring-1 ring-white/30 shrink-0">
                  {profile?.displayName?.slice(0, 2).toUpperCase() ||
                    user.email?.slice(0, 2).toUpperCase() ||
                    'U'}
                </div>
                <div className="truncate">
                  <div className="text-xs font-bold text-white truncate">
                    {profile?.displayName || user.displayName || 'Authorized User'}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate">{user.email}</div>
                </div>
              </div>

              <button
                onClick={logout}
                title="Sign out"
                className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-white/5 rounded-lg transition"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between pt-1 border-t border-white/10 text-[11px]">
              <span className="text-slate-400">Access Level:</span>
              <span
                className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border ${getRoleBadgeColor(
                  activeRole
                )}`}
              >
                {activeRole}
              </span>
            </div>
          </div>
        ) : (
          <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-center space-y-2">
            <div className="text-xs font-semibold text-slate-300">Guest Session (Viewer)</div>
            <p className="text-[10px] text-slate-400">
              Sign in with your Google or work account to access database sync & role permissions.
            </p>
            <button
              onClick={onOpenAuth}
              className="w-full py-2 px-3 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition shadow-xs flex items-center justify-center gap-1.5"
            >
              <LogIn className="w-3.5 h-3.5" />
              Sign In / Sign Up
            </button>
          </div>
        )}

        <div className="mt-2 text-center text-[10px] text-slate-400">
          DXB-RPPT • v2.6.0 Apple Edition
        </div>
      </div>
    </aside>
  );
};
