import React from 'react';
import {
  Users2,
  ShieldCheck,
  ShieldAlert,
  UserCheck,
  Check,
  KeyRound,
  Lock,
  Building,
  Scale,
  FileSpreadsheet,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';

export const UserRoleManager: React.FC = () => {
  const { profile, role, switchDemoRole, canManageUsers } = useAuth();

  const roleDefinitions: {
    role: UserRole;
    title: string;
    description: string;
    permissions: string[];
    color: string;
  }[] = [
    {
      role: 'admin',
      title: 'Administrator',
      description: 'Full supervisory authority. Manages system users, security rules, all documents, and financial audits.',
      permissions: [
        'Upload & extract all documents',
        'Create, edit, & delete Tenancy Contracts',
        'Approve & delete Purchase Tax Invoices',
        'Execute automated & manual Bank Reconciliation',
        'Manage User Roles & Access Rights',
        'Export to Zoho Books & Tally Prime',
      ],
      color: 'blue',
    },
    {
      role: 'manager',
      title: 'Property Asset Manager',
      description: 'Operations manager managing leasing portfolios, contract terms, and maintenance oversight.',
      permissions: [
        'Upload & extract all documents',
        'Create and edit Tenancy Contracts',
        'Record & verify Cheque Receipts',
        'View purchase invoices & expenses',
        'View Bank Statements & Reconciliation',
        'Export reports in PDF/Excel',
      ],
      color: 'emerald',
    },
    {
      role: 'accountant',
      title: 'Financial Accountant',
      description: 'Dedicated financial officer focused on VAT calculations, general ledger sync, and bank reconciliations.',
      permissions: [
        'Upload & extract Receipts, Invoices & Statements',
        'Execute Bank Reconciliation Statements (BRS)',
        'Inspect 5% UAE VAT calculations',
        'Link bank credits to receipts and debits to expenses',
        'Export dedicated Zoho Books & Tally Prime ledgers',
      ],
      color: 'amber',
    },
    {
      role: 'viewer',
      title: 'Auditor / Viewer',
      description: 'Read-only access to view dashboards, contract details, and export audit sheets without edit privileges.',
      permissions: [
        'View Executive Financial Dashboard',
        'View Tenancy Contracts & Receipts',
        'View Bank Statements & BRS Summary',
        'Download PDF Audit Reports',
      ],
      color: 'slate',
    },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      {/* Title */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Users2 className="w-5 h-5 text-blue-600" />
            <span>Role-Based Access Control (RBAC) & Team Management</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Enterprise privilege boundaries separating Financial Accountants, Property Managers, and Executive Administrators.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-600">Current Active Role:</span>
          <span className="px-3 py-1 rounded-full bg-blue-600 text-white font-mono font-bold text-xs uppercase tracking-wide">
            {role}
          </span>
        </div>
      </div>

      {/* Current User Role Status Card */}
      <div className="bg-gradient-to-r from-slate-900 to-blue-950 rounded-3xl p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-400 to-blue-600 flex items-center justify-center text-white text-xl font-bold ring-4 ring-white/10 shrink-0">
            {profile?.displayName?.charAt(0) || 'A'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold">{profile?.displayName || 'Finance Director'}</h3>
              <span className="px-2 py-0.5 rounded-full bg-cyan-400/20 text-cyan-300 text-[10px] font-mono font-bold uppercase border border-cyan-400/30">
                {role}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              {profile?.email || 'aelogan81@gmail.com'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 bg-white/10 p-2 rounded-2xl border border-white/10">
          <span className="text-xs font-semibold text-slate-300 pl-2">Live Test Role:</span>
          {(['admin', 'manager', 'accountant', 'viewer'] as UserRole[]).map((r) => (
            <button
              key={r}
              onClick={() => switchDemoRole(r)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold uppercase font-mono transition-all cursor-pointer ${
                role === r
                  ? 'bg-blue-500 text-white shadow-md'
                  : 'text-slate-300 hover:bg-white/10'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Role Tiers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {roleDefinitions.map((item) => {
          const isCurrent = role === item.role;
          return (
            <div
              key={item.role}
              className={`bg-white rounded-3xl p-6 border transition-all flex flex-col justify-between ${
                isCurrent
                  ? 'border-blue-600 ring-2 ring-blue-600/20 shadow-md'
                  : 'border-slate-200/80 shadow-sm hover:border-slate-300'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase font-mono tracking-wider text-slate-500">
                    Tier: {item.role}
                  </span>
                  {isCurrent && (
                    <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[10px] font-bold">
                      Active
                    </span>
                  )}
                </div>

                <h4 className="text-base font-bold text-slate-900 tracking-tight">
                  {item.title}
                </h4>
                <p className="text-xs text-slate-500 mt-1 min-h-[48px]">
                  {item.description}
                </p>

                <div className="mt-4 pt-4 border-t border-slate-100 space-y-2">
                  <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">
                    Granted Permissions
                  </span>
                  {item.permissions.map((p, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 text-xs text-slate-700">
                      <Check className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
                      <span className="text-[11px] leading-tight">{p}</span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => switchDemoRole(item.role)}
                className={`mt-6 w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  isCurrent
                    ? 'bg-blue-50 text-blue-700 border border-blue-200'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {isCurrent ? 'Current Role' : `Switch to ${item.title}`}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
