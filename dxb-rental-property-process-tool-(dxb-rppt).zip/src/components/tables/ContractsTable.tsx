import React, { useState } from 'react';
import {
  Building2,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  AlertCircle,
  FileSpreadsheet,
  Download,
  Calendar,
  Layers,
} from 'lucide-react';
import { usePropertyData } from '../../context/PropertyDataContext';
import { useAuth } from '../../context/AuthContext';
import { TenancyContract } from '../../types';

interface ContractsTableProps {
  onOpenUpload: () => void;
}

export const ContractsTable: React.FC<ContractsTableProps> = ({ onOpenUpload }) => {
  const { filteredContracts, updateContract, deleteContract, addContract } = usePropertyData();
  const { canEdit, canDelete } = useAuth();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<TenancyContract>>({});
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Manual Add Modal State
  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);
  const [newFormData, setNewFormData] = useState({
    ownerName: '',
    buildingName: '',
    propertyNo: '',
    type: 'Residential',
    subType: 'Apartment',
    size: 1000,
    tenantName: '',
    contractAmount: 0,
    actualAnnualAmount: 0,
    startDate: '2026-01-01',
    endDate: '2026-12-31',
    securityDeposit: 0,
    lessorName: '',
    registrationDate: '',
    vatRate: 0,
    vatAmount: 0,
  });

  const handleStartEdit = (contract: TenancyContract) => {
    setEditingId(contract.id);
    setEditFormData({ ...contract });
    setErrorMessage(null);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditFormData({});
    setErrorMessage(null);
  };

  const handleSaveEdit = async (id: string) => {
    setErrorMessage(null);
    const res = await updateContract(id, editFormData);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to update contract');
    } else {
      setEditingId(null);
    }
  };

  const handleSaveNew = async () => {
    setErrorMessage(null);
    if (!newFormData.propertyNo.trim() || !newFormData.tenantName.trim()) {
      setErrorMessage('Property No and Tenant Name are required.');
      return;
    }
    const res = await addContract({
      ...newFormData,
      contractAmount: Number(newFormData.contractAmount),
      actualAnnualAmount: Number(newFormData.actualAnnualAmount) || Number(newFormData.contractAmount),
      size: Number(newFormData.size),
      securityDeposit: Number(newFormData.securityDeposit),
      vatRate: newFormData.type === 'Commercial' ? 5 : 0,
      vatAmount: newFormData.type === 'Commercial' ? Number(newFormData.contractAmount) * 0.05 : 0,
    });

    if (!res.success) {
      setErrorMessage(res.error || 'Duplicate detected or failed to save.');
    } else {
      setIsAddingNew(false);
      setNewFormData({
        ownerName: '',
        buildingName: '',
        propertyNo: '',
        type: 'Residential',
        subType: 'Apartment',
        size: 1000,
        tenantName: '',
        contractAmount: 0,
        actualAnnualAmount: 0,
        startDate: '2026-01-01',
        endDate: '2026-12-31',
        securityDeposit: 0,
        lessorName: '',
        registrationDate: '',
        vatRate: 0,
        vatAmount: 0,
      });
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Title & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Building2 className="w-5 h-5 text-blue-600" />
            <span>UAE Tenancy Contracts (Ejari)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Registered Dubai Land Department tenancy agreements. Duplicate property entries within overlapping dates are strictly barred.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {canEdit && (
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Manual Contract</span>
            </button>
          )}

          <button
            onClick={onOpenUpload}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-all cursor-pointer"
          >
            <span>Upload Ejari PDF</span>
          </button>
        </div>
      </div>

      {/* Error / Duplicate Warning Banner */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 flex items-start justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span className="text-xs font-bold">{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-rose-500 hover:text-rose-700">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Manual Add Card Drawer */}
      {isAddingNew && (
        <div className="bg-white rounded-3xl p-6 border-2 border-blue-500 shadow-xl space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h3 className="text-sm font-bold text-slate-900">Add New UAE Tenancy Contract</h3>
            <button onClick={() => setIsAddingNew(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3 text-xs">
            <div>
              <label className="text-slate-500 font-medium block mb-1">Property No *</label>
              <input
                type="text"
                placeholder="e.g. Unit 1402"
                value={newFormData.propertyNo}
                onChange={(e) => setNewFormData({ ...newFormData, propertyNo: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-semibold"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Building Name</label>
              <input
                type="text"
                placeholder="e.g. Downtown Heights"
                value={newFormData.buildingName}
                onChange={(e) => setNewFormData({ ...newFormData, buildingName: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Tenant Name *</label>
              <input
                type="text"
                placeholder="Full tenant name"
                value={newFormData.tenantName}
                onChange={(e) => setNewFormData({ ...newFormData, tenantName: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Owner Name</label>
              <input
                type="text"
                placeholder="Landlord name"
                value={newFormData.ownerName}
                onChange={(e) => setNewFormData({ ...newFormData, ownerName: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Contract Amount (AED)</label>
              <input
                type="number"
                value={newFormData.contractAmount}
                onChange={(e) => setNewFormData({ ...newFormData, contractAmount: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold text-blue-700"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Actual Annual Amount (AED)</label>
              <input
                type="number"
                value={newFormData.actualAnnualAmount}
                onChange={(e) => setNewFormData({ ...newFormData, actualAnnualAmount: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold text-emerald-700"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Start Date</label>
              <input
                type="date"
                value={newFormData.startDate}
                onChange={(e) => setNewFormData({ ...newFormData, startDate: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">End Date</label>
              <input
                type="date"
                value={newFormData.endDate}
                onChange={(e) => setNewFormData({ ...newFormData, endDate: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Security Deposit (AED)</label>
              <input
                type="number"
                value={newFormData.securityDeposit}
                onChange={(e) => setNewFormData({ ...newFormData, securityDeposit: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Size (Sq Ft)</label>
              <input
                type="number"
                value={newFormData.size}
                onChange={(e) => setNewFormData({ ...newFormData, size: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Type</label>
              <select
                value={newFormData.type}
                onChange={(e) => setNewFormData({ ...newFormData, type: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              >
                <option value="Residential">Residential</option>
                <option value="Commercial">Commercial (5% VAT)</option>
              </select>
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Ejari Registration Date</label>
              <input
                type="date"
                value={newFormData.registrationDate}
                onChange={(e) => setNewFormData({ ...newFormData, registrationDate: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setIsAddingNew(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveNew}
              className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md cursor-pointer"
            >
              Save Tenancy Contract
            </button>
          </div>
        </div>
      )}

      {/* Contracts Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[10px]">
                <th className="p-3.5 pl-6">Property / Building</th>
                <th className="p-3.5">Tenant & Owner</th>
                <th className="p-3.5">Type & Size</th>
                <th className="p-3.5 text-right font-mono">Contract Amt (AED)</th>
                <th className="p-3.5 text-right font-mono">Actual Annual (AED)</th>
                <th className="p-3.5 text-right font-mono">Deposit (AED)</th>
                <th className="p-3.5">Contract Term</th>
                <th className="p-3.5">Ejari Reg. Date</th>
                {canEdit && <th className="p-3.5 pr-6 text-center">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredContracts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <Building2 className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-600">No Tenancy Contracts Found</p>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      Use the Upload button to extract UAE Ejari contracts from PDF/images or click Add Manual Contract.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredContracts.map((c) => {
                  const isEditing = editingId === c.id;

                  if (isEditing) {
                    return (
                      <tr key={c.id} className="bg-blue-50/40">
                        <td className="p-3 pl-6">
                          <input
                            type="text"
                            value={editFormData.propertyNo || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, propertyNo: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-semibold mb-1"
                          />
                          <input
                            type="text"
                            value={editFormData.buildingName || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, buildingName: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={editFormData.tenantName || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, tenantName: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs mb-1 font-medium"
                          />
                          <input
                            type="text"
                            value={editFormData.ownerName || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, ownerName: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs text-slate-500"
                          />
                        </td>
                        <td className="p-3">
                          <select
                            value={editFormData.type || 'Residential'}
                            onChange={(e) => setEditFormData({ ...editFormData, type: e.target.value as any })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs mb-1"
                          >
                            <option value="Residential">Residential</option>
                            <option value="Commercial">Commercial</option>
                          </select>
                          <input
                            type="number"
                            value={editFormData.size || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, size: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.contractAmount || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, contractAmount: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono font-bold text-right"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.actualAnnualAmount || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, actualAnnualAmount: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono font-bold text-right text-emerald-700"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.securityDeposit || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, securityDeposit: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono text-right"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="date"
                            value={editFormData.startDate || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, startDate: e.target.value })}
                            className="w-full p-1 bg-white rounded border text-[11px] mb-1"
                          />
                          <input
                            type="date"
                            value={editFormData.endDate || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, endDate: e.target.value })}
                            className="w-full p-1 bg-white rounded border text-[11px]"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="date"
                            value={editFormData.registrationDate || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, registrationDate: e.target.value })}
                            className="w-full p-1 bg-white rounded border text-[11px]"
                          />
                        </td>
                        <td className="p-3 pr-6 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => handleSaveEdit(c.id)}
                              className="p-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
                              title="Save"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={handleCancelEdit}
                              className="p-1.5 rounded-lg bg-slate-300 text-slate-700 hover:bg-slate-400"
                              title="Cancel"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={c.id} className="hover:bg-slate-50/70 transition-colors group">
                      <td className="p-3.5 pl-6">
                        <div className="font-bold text-slate-900">{c.propertyNo}</div>
                        <div className="text-[11px] text-slate-500">{c.buildingName || '—'}</div>
                      </td>
                      <td className="p-3.5">
                        <div className="font-semibold text-slate-800">{c.tenantName}</div>
                        <div className="text-[11px] text-slate-400 truncate max-w-[150px]">
                          Owner: {c.ownerName || '—'}
                        </div>
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                            c.type === 'Commercial'
                              ? 'bg-purple-100 text-purple-700'
                              : 'bg-blue-100 text-blue-700'
                          }`}
                        >
                          {c.type}
                        </span>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {c.subType} • {c.size ? `${c.size.toLocaleString()} sq ft` : '—'}
                        </div>
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-blue-700">
                        AED {(c.contractAmount || 0).toLocaleString()}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-emerald-700">
                        AED {(c.actualAnnualAmount || 0).toLocaleString()}
                      </td>
                      <td className="p-3.5 text-right font-mono text-slate-600">
                        AED {(c.securityDeposit || 0).toLocaleString()}
                      </td>
                      <td className="p-3.5 text-[11px] text-slate-600">
                        <div>From: {c.startDate}</div>
                        <div>To: {c.endDate}</div>
                      </td>
                      <td className="p-3.5 text-[11px] text-slate-500 font-mono">
                        {c.registrationDate || '—'}
                      </td>
                      {canEdit && (
                        <td className="p-3.5 pr-6 text-center">
                          <div className="flex items-center justify-center gap-1.5 opacity-80 group-hover:opacity-100">
                            <button
                              onClick={() => handleStartEdit(c)}
                              className="p-1 text-slate-400 hover:text-blue-600 rounded hover:bg-blue-50 transition-colors"
                              title="Edit contract"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {canDelete && (
                              <button
                                onClick={() => deleteContract(c.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
                                title="Delete contract"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
