import React, { useState } from 'react';
import {
  Landmark,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Scale,
  CheckCircle2,
  Clock,
  ArrowDownLeft,
  ArrowUpRight,
} from 'lucide-react';
import { usePropertyData } from '../../context/PropertyDataContext';
import { useAuth } from '../../context/AuthContext';
import { BankStatement, ActiveTab } from '../../types';

interface BankStatementsTableProps {
  onOpenUpload: () => void;
  onNavigateToReconcile: () => void;
}

export const BankStatementsTable: React.FC<BankStatementsTableProps> = ({
  onOpenUpload,
  onNavigateToReconcile,
}) => {
  const { filteredStatements, updateBankStatement, deleteBankStatement, addBankStatement } = usePropertyData();
  const { canEdit, canDelete } = useAuth();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<BankStatement>>({});

  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);
  const [newFormData, setNewFormData] = useState({
    bankName: 'Emirates NBD',
    accountNumber: '101-5582910-01',
    statementPeriod: 'October 2026',
    transactionDate: new Date().toISOString().split('T')[0],
    transactionName: '',
    chequeNumber: '',
    debitAmount: 0,
    creditAmount: 0,
    netBalance: 150000,
    reconciliationStatus: 'Unmatched' as const,
  });

  const handleStartEdit = (stmt: BankStatement) => {
    setEditingId(stmt.id);
    setEditFormData({ ...stmt });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditFormData({});
  };

  const handleSaveEdit = async (id: string) => {
    await updateBankStatement(id, editFormData);
    setEditingId(null);
  };

  const handleSaveNew = async () => {
    if (!newFormData.transactionName.trim()) return;
    await addBankStatement({
      ...newFormData,
      debitAmount: Number(newFormData.debitAmount),
      creditAmount: Number(newFormData.creditAmount),
      netBalance: Number(newFormData.netBalance),
    });
    setIsAddingNew(false);
    setNewFormData({
      bankName: 'Emirates NBD',
      accountNumber: '101-5582910-01',
      statementPeriod: 'October 2026',
      transactionDate: new Date().toISOString().split('T')[0],
      transactionName: '',
      chequeNumber: '',
      debitAmount: 0,
      creditAmount: 0,
      netBalance: 150000,
      reconciliationStatus: 'Unmatched',
    });
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Title & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <Landmark className="w-5 h-5 text-indigo-600" />
            <span>Bank Statement Ledger</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Emirates NBD, ADCB, FAB, and DIB transaction lines with automated debit and credit classification.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onNavigateToReconcile}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold shadow-sm transition-all cursor-pointer"
          >
            <Scale className="w-4 h-4" />
            <span>Open BRS Workbench</span>
          </button>

          {canEdit && (
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Transaction</span>
            </button>
          )}

          <button
            onClick={onOpenUpload}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-all cursor-pointer"
          >
            <span>Scan Statement PDF</span>
          </button>
        </div>
      </div>

      {/* Manual Add Card */}
      {isAddingNew && (
        <div className="bg-white rounded-3xl p-6 border-2 border-indigo-500 shadow-xl space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h3 className="text-sm font-bold text-slate-900">Add Bank Statement Entry</h3>
            <button onClick={() => setIsAddingNew(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="text-slate-500 font-medium block mb-1">Transaction Date *</label>
              <input
                type="date"
                value={newFormData.transactionDate}
                onChange={(e) => setNewFormData({ ...newFormData, transactionDate: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Bank Name</label>
              <input
                type="text"
                value={newFormData.bankName}
                onChange={(e) => setNewFormData({ ...newFormData, bankName: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-semibold"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Cheque Number</label>
              <input
                type="text"
                placeholder="Optional cheque #"
                value={newFormData.chequeNumber}
                onChange={(e) => setNewFormData({ ...newFormData, chequeNumber: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono"
              />
            </div>
            <div className="sm:col-span-3">
              <label className="text-slate-500 font-medium block mb-1">Transaction Name / Memo *</label>
              <input
                type="text"
                placeholder="e.g. Cheque Deposit - Rashid Al Nuaimi / Wire to Al Shirawi Facilities"
                value={newFormData.transactionName}
                onChange={(e) => setNewFormData({ ...newFormData, transactionName: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-medium"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Credit Amount (AED - Deposit/Receipt)</label>
              <input
                type="number"
                value={newFormData.creditAmount}
                onChange={(e) => setNewFormData({ ...newFormData, creditAmount: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold text-emerald-700"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Debit Amount (AED - Expense/Payment)</label>
              <input
                type="number"
                value={newFormData.debitAmount}
                onChange={(e) => setNewFormData({ ...newFormData, debitAmount: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold text-rose-600"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Net Running Balance (AED)</label>
              <input
                type="number"
                value={newFormData.netBalance}
                onChange={(e) => setNewFormData({ ...newFormData, netBalance: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold text-slate-800"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setIsAddingNew(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveNew}
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-md cursor-pointer"
            >
              Save Bank Line
            </button>
          </div>
        </div>
      )}

      {/* Statements Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[10px]">
                <th className="p-3.5 pl-6">Transaction Date</th>
                <th className="p-3.5">Transaction Name / Payee</th>
                <th className="p-3.5">Cheque #</th>
                <th className="p-3.5 text-right font-mono">Debit (AED)</th>
                <th className="p-3.5 text-right font-mono">Credit (AED)</th>
                <th className="p-3.5 text-right font-mono">Net Balance (AED)</th>
                <th className="p-3.5 text-center">BRS Status</th>
                {canEdit && <th className="p-3.5 pr-6 text-center">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStatements.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <Landmark className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-600">No Bank Statement Transactions</p>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      Upload bank statements or add lines to start matching with rent receipts and maintenance bills.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredStatements.map((stmt) => {
                  const isEditing = editingId === stmt.id;

                  if (isEditing) {
                    return (
                      <tr key={stmt.id} className="bg-indigo-50/40">
                        <td className="p-3 pl-6">
                          <input
                            type="date"
                            value={editFormData.transactionDate || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, transactionDate: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={editFormData.transactionName || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, transactionName: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-medium"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={editFormData.chequeNumber || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, chequeNumber: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.debitAmount || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, debitAmount: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono font-bold text-right text-rose-600"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.creditAmount || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, creditAmount: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono font-bold text-right text-emerald-600"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.netBalance || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, netBalance: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono text-right"
                          />
                        </td>
                        <td className="p-3 text-center text-xs">
                          {stmt.reconciliationStatus}
                        </td>
                        <td className="p-3 pr-6 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => handleSaveEdit(stmt.id)}
                              className="p-1.5 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={handleCancelEdit}
                              className="p-1.5 rounded-lg bg-slate-300 text-slate-700 hover:bg-slate-400"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={stmt.id} className="hover:bg-slate-50/70 transition-colors group">
                      <td className="p-3.5 pl-6 font-medium text-slate-800">
                        {stmt.transactionDate}
                      </td>
                      <td className="p-3.5">
                        <div className="font-semibold text-slate-800">{stmt.transactionName}</div>
                        <div className="text-[11px] text-slate-400">{stmt.bankName}</div>
                      </td>
                      <td className="p-3.5 font-mono text-slate-600">
                        {stmt.chequeNumber || '—'}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold">
                        {stmt.debitAmount > 0 ? (
                          <span className="text-rose-600">-AED {stmt.debitAmount.toLocaleString()}</span>
                        ) : (
                          <span className="text-slate-300">—</span>
                        )}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold">
                        {stmt.creditAmount > 0 ? (
                          <span className="text-emerald-600">+AED {stmt.creditAmount.toLocaleString()}</span>
                        ) : (
                          <span className="text-slate-300">—</span>
                        )}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-slate-900">
                        AED {(stmt.netBalance || 0).toLocaleString()}
                      </td>
                      <td className="p-3.5 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${
                            stmt.reconciliationStatus === 'Matched'
                              ? 'bg-emerald-100 text-emerald-700'
                              : 'bg-amber-100 text-amber-700'
                          }`}
                        >
                          {stmt.reconciliationStatus === 'Matched' ? (
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <Clock className="w-3 h-3 text-amber-600" />
                          )}
                          <span>{stmt.reconciliationStatus}</span>
                        </span>
                      </td>
                      {canEdit && (
                        <td className="p-3.5 pr-6 text-center">
                          <div className="flex items-center justify-center gap-1.5 opacity-80 group-hover:opacity-100">
                            <button
                              onClick={() => handleStartEdit(stmt)}
                              className="p-1 text-slate-400 hover:text-indigo-600 rounded hover:bg-indigo-50 transition-colors"
                              title="Edit statement line"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {canDelete && (
                              <button
                                onClick={() => deleteBankStatement(stmt.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
                                title="Delete statement line"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
