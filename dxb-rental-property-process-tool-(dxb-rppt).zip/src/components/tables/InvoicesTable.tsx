import React, { useState } from 'react';
import {
  FileCheck2,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  AlertCircle,
  Percent,
  Receipt,
  Building,
  Camera,
} from 'lucide-react';
import { usePropertyData } from '../../context/PropertyDataContext';
import { useAuth } from '../../context/AuthContext';
import { PurchaseInvoice } from '../../types';

interface InvoicesTableProps {
  onOpenUpload: (options?: { type?: 'contract' | 'receipt' | 'invoice' | 'statement'; mode?: 'upload' | 'camera' }) => void;
}

export const InvoicesTable: React.FC<InvoicesTableProps> = ({ onOpenUpload }) => {
  const { filteredInvoices, updateInvoice, deleteInvoice, addInvoice } = usePropertyData();
  const { canEdit, canDelete } = useAuth();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<PurchaseInvoice>>({});
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);
  const [newFormData, setNewFormData] = useState({
    invoiceNumber: '',
    invoiceDate: new Date().toISOString().split('T')[0],
    supplierName: '',
    supplierTRN: '',
    propertyNo: '',
    buildingName: '',
    description: '',
    totalInvoiceAmount: 0,
    netAmount: 0,
    taxAmount: 0,
  });

  const handleStartEdit = (inv: PurchaseInvoice) => {
    setEditingId(inv.id);
    setEditFormData({ ...inv });
    setErrorMessage(null);
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditFormData({});
    setErrorMessage(null);
  };

  const handleSaveEdit = async (id: string) => {
    setErrorMessage(null);
    const res = await updateInvoice(id, editFormData);
    if (!res.success) {
      setErrorMessage(res.error || 'Failed to update invoice');
    } else {
      setEditingId(null);
    }
  };

  const handleSaveNew = async () => {
    setErrorMessage(null);
    if (!newFormData.invoiceNumber.trim() || !newFormData.supplierName.trim()) {
      setErrorMessage('Invoice Number and Supplier Name are mandatory.');
      return;
    }

    const total = Number(newFormData.totalInvoiceAmount);
    const tax = Number(newFormData.taxAmount) || Math.round(total * (5 / 105) * 100) / 100;
    const net = total - tax;

    const res = await addInvoice({
      ...newFormData,
      totalInvoiceAmount: total,
      taxAmount: tax,
      netAmount: Math.round(net * 100) / 100,
    });

    if (!res.success) {
      setErrorMessage(res.error || 'Duplicate detected or failed to save.');
    } else {
      setIsAddingNew(false);
      setNewFormData({
        invoiceNumber: '',
        invoiceDate: new Date().toISOString().split('T')[0],
        supplierName: '',
        supplierTRN: '',
        propertyNo: '',
        buildingName: '',
        description: '',
        totalInvoiceAmount: 0,
        netAmount: 0,
        taxAmount: 0,
      });
    }
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Title & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <FileCheck2 className="w-5 h-5 text-amber-600" />
            <span>Purchase Tax Invoices (UAE 5% VAT)</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Maintenance, chiller, plumbing, and property repair invoices. Duplicates on invoice number within same date are blocked.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {canEdit && (
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Record Tax Invoice</span>
            </button>
          )}

          {/* Dedicated Capture Camera Option */}
          <button
            onClick={() => onOpenUpload({ type: 'invoice', mode: 'camera' })}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 text-xs font-bold shadow-md shadow-amber-500/20 transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
          >
            <Camera className="w-4 h-4 text-slate-950" />
            <span>Capture Camera Invoice</span>
          </button>

          <button
            onClick={() => onOpenUpload({ type: 'invoice', mode: 'upload' })}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-all cursor-pointer"
          >
            <span>Scan Tax Invoice PDF</span>
          </button>
        </div>
      </div>

      {/* Duplicate Warning / Error Banner */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 flex items-start justify-between gap-3 animate-fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span className="text-xs font-bold">{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-rose-500 hover:text-rose-700">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Manual Add Drawer */}
      {isAddingNew && (
        <div className="bg-white rounded-3xl p-6 border-2 border-amber-500 shadow-xl space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h3 className="text-sm font-bold text-slate-900">Add Purchase Tax Invoice</h3>
            <button onClick={() => setIsAddingNew(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="text-slate-500 font-medium block mb-1">Invoice Number *</label>
              <input
                type="text"
                placeholder="e.g. INV-2026-901"
                value={newFormData.invoiceNumber}
                onChange={(e) => setNewFormData({ ...newFormData, invoiceNumber: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Invoice Date *</label>
              <input
                type="date"
                value={newFormData.invoiceDate}
                onChange={(e) => setNewFormData({ ...newFormData, invoiceDate: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Supplier / Contractor Name *</label>
              <input
                type="text"
                placeholder="Contractor LLC"
                value={newFormData.supplierName}
                onChange={(e) => setNewFormData({ ...newFormData, supplierName: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-semibold"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Supplier 15-digit TRN</label>
              <input
                type="text"
                placeholder="100XXXXXXXX0003"
                value={newFormData.supplierTRN}
                onChange={(e) => setNewFormData({ ...newFormData, supplierTRN: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Total Invoice Amount (AED) *</label>
              <input
                type="number"
                placeholder="3150"
                value={newFormData.totalInvoiceAmount}
                onChange={(e) => {
                  const tot = Number(e.target.value);
                  const tax = Math.round(tot * (5 / 105) * 100) / 100;
                  setNewFormData({
                    ...newFormData,
                    totalInvoiceAmount: tot,
                    taxAmount: tax,
                    netAmount: tot - tax,
                  });
                }}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold text-rose-600"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Tax Amount (5% VAT AED)</label>
              <input
                type="number"
                value={newFormData.taxAmount}
                onChange={(e) => setNewFormData({ ...newFormData, taxAmount: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold text-amber-600"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Property No</label>
              <input
                type="text"
                placeholder="e.g. Unit 1402"
                value={newFormData.propertyNo}
                onChange={(e) => setNewFormData({ ...newFormData, propertyNo: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Building Name</label>
              <input
                type="text"
                placeholder="e.g. Downtown Heights"
                value={newFormData.buildingName}
                onChange={(e) => setNewFormData({ ...newFormData, buildingName: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Description of Works</label>
              <input
                type="text"
                placeholder="AC maintenance, repair, electrical..."
                value={newFormData.description}
                onChange={(e) => setNewFormData({ ...newFormData, description: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setIsAddingNew(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveNew}
              className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-md cursor-pointer"
            >
              Save Purchase Invoice
            </button>
          </div>
        </div>
      )}

      {/* Invoices Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[10px]">
                <th className="p-3.5 pl-6">Invoice # & Date</th>
                <th className="p-3.5">Supplier & TRN</th>
                <th className="p-3.5">Property / Unit</th>
                <th className="p-3.5">Work Description</th>
                <th className="p-3.5 text-right font-mono">Net (AED)</th>
                <th className="p-3.5 text-right font-mono">VAT 5% (AED)</th>
                <th className="p-3.5 text-right font-mono">Total (AED)</th>
                <th className="p-3.5">Bank Match</th>
                {canEdit && <th className="p-3.5 pr-6 text-center">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-400">
                    <FileCheck2 className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-600">No Purchase Tax Invoices Found</p>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      Capture with your device camera or upload maintenance contractor tax invoices in PDF/image format.
                    </p>
                    <div className="mt-4 flex flex-wrap items-center justify-center gap-2.5">
                      <button
                        onClick={() => onOpenUpload({ type: 'invoice', mode: 'camera' })}
                        className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold text-xs inline-flex items-center gap-1.5 shadow-md shadow-amber-500/20 transition-all cursor-pointer"
                      >
                        <Camera className="w-4 h-4 text-slate-950" />
                        <span>Take Invoice Photo with Camera</span>
                      </button>
                      <button
                        onClick={() => onOpenUpload({ type: 'invoice', mode: 'upload' })}
                        className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition-all cursor-pointer"
                      >
                        Browse or Drop File
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => {
                  const isEditing = editingId === inv.id;

                  if (isEditing) {
                    return (
                      <tr key={inv.id} className="bg-amber-50/40">
                        <td className="p-3 pl-6">
                          <input
                            type="text"
                            value={editFormData.invoiceNumber || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, invoiceNumber: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono font-bold mb-1"
                          />
                          <input
                            type="date"
                            value={editFormData.invoiceDate || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, invoiceDate: e.target.value })}
                            className="w-full p-1 bg-white rounded border text-[11px]"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={editFormData.supplierName || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, supplierName: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-semibold mb-1"
                          />
                          <input
                            type="text"
                            placeholder="TRN"
                            value={editFormData.supplierTRN || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, supplierTRN: e.target.value })}
                            className="w-full p-1 bg-white rounded border text-[11px] font-mono"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={editFormData.propertyNo || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, propertyNo: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs mb-1"
                          />
                          <input
                            type="text"
                            placeholder="Building"
                            value={editFormData.buildingName || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, buildingName: e.target.value })}
                            className="w-full p-1 bg-white rounded border text-[11px]"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={editFormData.description || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, description: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.netAmount || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, netAmount: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono text-right"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.taxAmount || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, taxAmount: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono text-right font-bold text-amber-700"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.totalInvoiceAmount || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, totalInvoiceAmount: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono text-right font-bold text-rose-700"
                          />
                        </td>
                        <td className="p-3 text-xs text-slate-400">
                          {inv.matchedBankTxId ? 'Matched' : 'Unmatched'}
                        </td>
                        <td className="p-3 pr-6 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => handleSaveEdit(inv.id)}
                              className="p-1.5 rounded-lg bg-amber-600 text-white hover:bg-amber-700"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={handleCancelEdit}
                              className="p-1.5 rounded-lg bg-slate-300 text-slate-700 hover:bg-slate-400"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/70 transition-colors group">
                      <td className="p-3.5 pl-6">
                        <div className="font-mono font-bold text-slate-900">{inv.invoiceNumber}</div>
                        <div className="text-[11px] text-slate-400">{inv.invoiceDate}</div>
                      </td>
                      <td className="p-3.5">
                        <div className="font-semibold text-slate-800">{inv.supplierName}</div>
                        <div className="text-[11px] text-slate-400 font-mono">
                          {inv.supplierTRN ? `TRN: ${inv.supplierTRN}` : '—'}
                        </div>
                      </td>
                      <td className="p-3.5">
                        <div className="font-medium text-slate-800">{inv.propertyNo || '—'}</div>
                        <div className="text-[11px] text-slate-400">{inv.buildingName || ''}</div>
                      </td>
                      <td className="p-3.5 max-w-[200px] truncate text-slate-600">
                        {inv.description}
                      </td>
                      <td className="p-3.5 text-right font-mono text-slate-600">
                        AED {(inv.netAmount || 0).toLocaleString()}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-amber-700">
                        AED {(inv.taxAmount || 0).toLocaleString()}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-rose-700">
                        AED {(inv.totalInvoiceAmount || 0).toLocaleString()}
                      </td>
                      <td className="p-3.5">
                        {inv.matchedBankTxId ? (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                            Reconciled
                          </span>
                        ) : (
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-500">
                            Unmatched
                          </span>
                        )}
                      </td>
                      {canEdit && (
                        <td className="p-3.5 pr-6 text-center">
                          <div className="flex items-center justify-center gap-1.5 opacity-80 group-hover:opacity-100">
                            <button
                              onClick={() => handleStartEdit(inv)}
                              className="p-1 text-slate-400 hover:text-amber-600 rounded hover:bg-amber-50 transition-colors"
                              title="Edit invoice"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {canDelete && (
                              <button
                                onClick={() => deleteInvoice(inv.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
                                title="Delete invoice"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
