import React, { useState } from 'react';
import {
  Receipt as ReceiptIcon,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  CreditCard,
  Building,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { usePropertyData } from '../../context/PropertyDataContext';
import { useAuth } from '../../context/AuthContext';
import { Receipt } from '../../types';

interface ReceiptsTableProps {
  onOpenUpload: () => void;
}

export const ReceiptsTable: React.FC<ReceiptsTableProps> = ({ onOpenUpload }) => {
  const { filteredReceipts, updateReceipt, deleteReceipt, addReceipt } = usePropertyData();
  const { canEdit, canDelete } = useAuth();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<Receipt>>({});

  const [isAddingNew, setIsAddingNew] = useState<boolean>(false);
  const [newFormData, setNewFormData] = useState({
    propertyNo: '',
    tenantName: '',
    installmentDate: new Date().toISOString().split('T')[0],
    amount: 0,
    chequeNo: '',
    bankName: 'Emirates NBD',
    status: 'Cleared' as const,
  });

  const handleStartEdit = (receipt: Receipt) => {
    setEditingId(receipt.id);
    setEditFormData({ ...receipt });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditFormData({});
  };

  const handleSaveEdit = async (id: string) => {
    await updateReceipt(id, editFormData);
    setEditingId(null);
  };

  const handleSaveNew = async () => {
    if (!newFormData.chequeNo || !newFormData.amount) return;
    await addReceipt({
      ...newFormData,
      amount: Number(newFormData.amount),
    });
    setIsAddingNew(false);
    setNewFormData({
      propertyNo: '',
      tenantName: '',
      installmentDate: new Date().toISOString().split('T')[0],
      amount: 0,
      chequeNo: '',
      bankName: 'Emirates NBD',
      status: 'Cleared',
    });
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* Title & Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
            <ReceiptIcon className="w-5 h-5 text-emerald-600" />
            <span>Rental Receipts & Cheques Ledger</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Installment dates, cheque numbers, drawee banks, and automated bank statement clearance matching.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {canEdit && (
            <button
              onClick={() => setIsAddingNew(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Record Cheque Receipt</span>
            </button>
          )}

          <button
            onClick={onOpenUpload}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold border border-slate-200 transition-all cursor-pointer"
          >
            <span>Scan Receipt / Cheque</span>
          </button>
        </div>
      </div>

      {/* Manual Add Card */}
      {isAddingNew && (
        <div className="bg-white rounded-3xl p-6 border-2 border-emerald-500 shadow-xl space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <h3 className="text-sm font-bold text-slate-900">Record Rental Cheque / Installment Receipt</h3>
            <button onClick={() => setIsAddingNew(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="text-slate-500 font-medium block mb-1">Installment Date *</label>
              <input
                type="date"
                value={newFormData.installmentDate}
                onChange={(e) => setNewFormData({ ...newFormData, installmentDate: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Amount (AED) *</label>
              <input
                type="number"
                placeholder="25000"
                value={newFormData.amount}
                onChange={(e) => setNewFormData({ ...newFormData, amount: Number(e.target.value) })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold text-emerald-700"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Cheque Number *</label>
              <input
                type="text"
                placeholder="e.g. CHQ-882910"
                value={newFormData.chequeNo}
                onChange={(e) => setNewFormData({ ...newFormData, chequeNo: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300 font-mono font-bold"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Drawee Bank Name *</label>
              <input
                type="text"
                placeholder="Emirates NBD, ADCB, FAB..."
                value={newFormData.bankName}
                onChange={(e) => setNewFormData({ ...newFormData, bankName: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Property No</label>
              <input
                type="text"
                placeholder="e.g. Unit 1402"
                value={newFormData.propertyNo}
                onChange={(e) => setNewFormData({ ...newFormData, propertyNo: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
            <div>
              <label className="text-slate-500 font-medium block mb-1">Tenant Name</label>
              <input
                type="text"
                placeholder="Tenant full name"
                value={newFormData.tenantName}
                onChange={(e) => setNewFormData({ ...newFormData, tenantName: e.target.value })}
                className="w-full p-2 bg-slate-50 rounded-xl border border-slate-300"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              onClick={() => setIsAddingNew(false)}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100"
            >
              Cancel
            </button>
            <button
              onClick={handleSaveNew}
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md cursor-pointer"
            >
              Save Receipt Record
            </button>
          </div>
        </div>
      )}

      {/* Receipts Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-semibold text-[10px]">
                <th className="p-3.5 pl-6">Installment Date</th>
                <th className="p-3.5">Cheque Number</th>
                <th className="p-3.5">Drawee Bank</th>
                <th className="p-3.5 text-right font-mono">Amount (AED)</th>
                <th className="p-3.5">Property / Tenant</th>
                <th className="p-3.5">Cheque Status</th>
                <th className="p-3.5">Bank Match</th>
                {canEdit && <th className="p-3.5 pr-6 text-center">Actions</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredReceipts.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-400">
                    <ReceiptIcon className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-semibold text-slate-600">No Rental Receipts Found</p>
                    <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                      Scan or upload rental receipts/cheques, or click Record Cheque Receipt.
                    </p>
                  </td>
                </tr>
              ) : (
                filteredReceipts.map((r) => {
                  const isEditing = editingId === r.id;

                  if (isEditing) {
                    return (
                      <tr key={r.id} className="bg-emerald-50/40">
                        <td className="p-3 pl-6">
                          <input
                            type="date"
                            value={editFormData.installmentDate || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, installmentDate: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={editFormData.chequeNo || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, chequeNo: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono font-bold"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            value={editFormData.bankName || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, bankName: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs"
                          />
                        </td>
                        <td className="p-3 text-right">
                          <input
                            type="number"
                            value={editFormData.amount || 0}
                            onChange={(e) => setEditFormData({ ...editFormData, amount: Number(e.target.value) })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-mono font-bold text-right text-emerald-700"
                          />
                        </td>
                        <td className="p-3">
                          <input
                            type="text"
                            placeholder="Property"
                            value={editFormData.propertyNo || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, propertyNo: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs mb-1"
                          />
                          <input
                            type="text"
                            placeholder="Tenant"
                            value={editFormData.tenantName || ''}
                            onChange={(e) => setEditFormData({ ...editFormData, tenantName: e.target.value })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs"
                          />
                        </td>
                        <td className="p-3">
                          <select
                            value={editFormData.status || 'Cleared'}
                            onChange={(e) => setEditFormData({ ...editFormData, status: e.target.value as any })}
                            className="w-full p-1.5 bg-white rounded-lg border text-xs font-medium"
                          >
                            <option value="Cleared">Cleared</option>
                            <option value="Deposited">Deposited</option>
                            <option value="Pending">Pending</option>
                            <option value="Bounced">Bounced</option>
                          </select>
                        </td>
                        <td className="p-3 text-slate-400 text-xs">
                          {r.matchedBankTxId ? 'Matched' : 'Unmatched'}
                        </td>
                        <td className="p-3 pr-6 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => handleSaveEdit(r.id)}
                              className="p-1.5 rounded-lg bg-emerald-600 text-white hover:bg-emerald-700"
                            >
                              <Check className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={handleCancelEdit}
                              className="p-1.5 rounded-lg bg-slate-300 text-slate-700 hover:bg-slate-400"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  }

                  return (
                    <tr key={r.id} className="hover:bg-slate-50/70 transition-colors group">
                      <td className="p-3.5 pl-6 font-medium text-slate-800">
                        {r.installmentDate}
                      </td>
                      <td className="p-3.5 font-mono font-bold text-slate-900">
                        {r.chequeNo}
                      </td>
                      <td className="p-3.5 text-slate-600 font-medium">
                        {r.bankName}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-emerald-700">
                        AED {(r.amount || 0).toLocaleString()}
                      </td>
                      <td className="p-3.5">
                        <div className="font-semibold text-slate-800">{r.propertyNo || '—'}</div>
                        <div className="text-[11px] text-slate-400">{r.tenantName || '—'}</div>
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${
                            r.status === 'Cleared'
                              ? 'bg-emerald-100 text-emerald-700'
                              : r.status === 'Deposited'
                              ? 'bg-blue-100 text-blue-700'
                              : r.status === 'Bounced'
                              ? 'bg-rose-100 text-rose-700'
                              : 'bg-amber-100 text-amber-700'
                          }`}
                        >
                          {r.status === 'Cleared' ? (
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <Clock className="w-3 h-3 text-amber-600" />
                          )}
                          <span>{r.status}</span>
                        </span>
                      </td>
                      <td className="p-3.5">
                        {r.matchedBankTxId ? (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                            Reconciled
                          </span>
                        ) : (
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded bg-slate-100 text-slate-500">
                            Unmatched
                          </span>
                        )}
                      </td>
                      {canEdit && (
                        <td className="p-3.5 pr-6 text-center">
                          <div className="flex items-center justify-center gap-1.5 opacity-80 group-hover:opacity-100">
                            <button
                              onClick={() => handleStartEdit(r)}
                              className="p-1 text-slate-400 hover:text-emerald-600 rounded hover:bg-emerald-50 transition-colors"
                              title="Edit receipt"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            {canDelete && (
                              <button
                                onClick={() => deleteReceipt(r.id)}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
                                title="Delete receipt"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
