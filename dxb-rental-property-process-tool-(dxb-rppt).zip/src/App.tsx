import React, { useState, useEffect } from 'react';
import {
  Building2,
  Upload,
  Download,
  Shield,
  FileSpreadsheet,
  LogIn,
  Layers,
  Sparkles,
  Menu,
  X,
  CreditCard,
  User,
} from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { UploadSection } from './components/UploadSection';
import { ContractsTable } from './components/ContractsTable';
import { ReceiptsTable } from './components/ReceiptsTable';
import { InvoicesTable } from './components/InvoicesTable';
import { BankReconciliationView } from './components/BankReconciliationView';
import { ReportsView } from './components/ReportsView';
import { RolesManagement } from './components/RolesManagement';
import { AuthModal } from './components/AuthModal';
import { ActiveTab, TenancyContract, RentalReceipt, PurchaseTaxInvoice, BankStatement, BankTransaction } from './types';
import {
  subscribeContracts,
  subscribeReceipts,
  subscribeInvoices,
  subscribeBankStatements,
  subscribeBankTransactions,
} from './services/dbService';
import { exportToExcel, exportToPDF } from './utils/exportUtils';

function MainApp() {
  const { user, profile, activeRole, isAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Clean state: NO dummy or test tenancy contracts added!
  const [contracts, setContracts] = useState<TenancyContract[]>([]);
  const [receipts, setReceipts] = useState<RentalReceipt[]>([]);
  const [invoices, setInvoices] = useState<PurchaseTaxInvoice[]>([]);
  const [bankStatements, setBankStatements] = useState<BankStatement[]>([]);
  const [bankTransactions, setBankTransactions] = useState<BankTransaction[]>([]);

  useEffect(() => {
    if (!user) {
      setContracts([]);
      setReceipts([]);
      setInvoices([]);
      setBankStatements([]);
      setBankTransactions([]);
      return;
    }

    const unsubContracts = subscribeContracts(user.uid, isAdmin, (items) => {
      setContracts(items);
    });

    const unsubReceipts = subscribeReceipts(user.uid, isAdmin, (items) => {
      setReceipts(items);
    });

    const unsubInvoices = subscribeInvoices(user.uid, isAdmin, (items) => {
      setInvoices(items);
    });

    const unsubBankStatements = subscribeBankStatements(user.uid, isAdmin, (items) => {
      setBankStatements(items);
    });

    const unsubBankTransactions = subscribeBankTransactions(user.uid, isAdmin, (items) => {
      setBankTransactions(items);
    });

    return () => {
      unsubContracts();
      unsubReceipts();
      unsubInvoices();
      unsubBankStatements();
      unsubBankTransactions();
    };
  }, [user, isAdmin]);

  return (
    <div className="min-h-screen bg-[#F5F7FA] font-sans text-slate-800 flex antialiased selection:bg-blue-500 selection:text-white">
      {/* Desktop Left-Side Panel */}
      <div className="hidden lg:block">
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          onOpenAuth={() => setIsAuthOpen(true)}
          counts={{
            contracts: contracts.length,
            receipts: receipts.length,
            invoices: invoices.length,
          }}
        />
      </div>

      {/* Mobile Drawer Overlay */}
      {isMobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs"
            onClick={() => setIsMobileSidebarOpen(false)}
          />
          <div className="relative z-10 w-72">
            <Sidebar
              activeTab={activeTab}
              onSelectTab={(tab) => {
                setActiveTab(tab);
                setIsMobileSidebarOpen(false);
              }}
              onOpenAuth={() => {
                setIsAuthOpen(true);
                setIsMobileSidebarOpen(false);
              }}
              counts={{
                contracts: contracts.length,
                receipts: receipts.length,
                invoices: invoices.length,
              }}
            />
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-y-auto">
        {/* Apple-style Top Navigation Bar */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-8 py-3.5 flex items-center justify-between transition shadow-xs">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsMobileSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-xl hover:bg-slate-100"
            >
              <Menu className="w-5 h-5" />
            </button>

            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  DXB-RPPT
                </span>
                <span className="text-slate-300">/</span>
                <span className="text-xs font-bold text-slate-900 capitalize">
                  {activeTab.replace('-', ' ')}
                </span>
              </div>
            </div>
          </div>

          {/* Right Header Utilities */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('upload')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200/60 rounded-xl transition shadow-xs"
            >
              <Upload className="w-3.5 h-3.5" />
              Upload UAE Docs
            </button>

            <button
              onClick={() => exportToExcel(contracts, receipts, invoices, 'consolidated')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-xl transition shadow-xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
              Export Excel
            </button>

            {user ? (
              <div
                onClick={() => setActiveTab('roles')}
                className="flex items-center gap-2 pl-2 cursor-pointer group"
                title="Manage Roles & Account"
              >
                <div className="text-right hidden sm:block">
                  <div className="text-xs font-bold text-slate-900 leading-tight">
                    {profile?.displayName || user.email?.split('@')[0]}
                  </div>
                  <div className="text-[10px] font-semibold text-blue-600 uppercase">
                    {activeRole}
                  </div>
                </div>
                <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs ring-2 ring-white shadow-xs group-hover:scale-105 transition-transform">
                  {profile?.displayName?.slice(0, 2).toUpperCase() ||
                    user.email?.slice(0, 2).toUpperCase() ||
                    'U'}
                </div>
              </div>
            ) : (
              <button
                onClick={() => setIsAuthOpen(true)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition shadow-xs"
              >
                <LogIn className="w-3.5 h-3.5" />
                Sign In
              </button>
            )}
          </div>
        </header>

        {/* Content Container */}
        <main className="flex-1 p-4 sm:p-8 max-w-7xl w-full mx-auto">
          {activeTab === 'dashboard' && (
            <Dashboard
              contracts={contracts}
              receipts={receipts}
              invoices={invoices}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'upload' && (
            <UploadSection
              onSuccess={() => setActiveTab('dashboard')}
              onNavigateTab={setActiveTab}
              existingContracts={contracts}
              existingReceipts={receipts}
              existingInvoices={invoices}
            />
          )}

          {activeTab === 'contracts' && (
            <ContractsTable contracts={contracts} />
          )}

          {activeTab === 'receipts' && (
            <ReceiptsTable receipts={receipts} />
          )}

          {activeTab === 'invoices' && (
            <InvoicesTable invoices={invoices} />
          )}

          {activeTab === 'bank-reconciliation' && (
            <BankReconciliationView
              receipts={receipts}
              invoices={invoices}
              bankStatements={bankStatements}
              bankTransactions={bankTransactions}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'reports' && (
            <ReportsView
              contracts={contracts}
              receipts={receipts}
              invoices={invoices}
            />
          )}

          {activeTab === 'roles' && <RolesManagement />}
        </main>
      </div>

      {/* Auth Modal */}
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
