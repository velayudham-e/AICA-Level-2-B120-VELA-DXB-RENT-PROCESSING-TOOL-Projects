import React, { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { PropertyDataProvider } from './context/PropertyDataContext';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { Dashboard } from './components/dashboard/Dashboard';
import { ContractsTable } from './components/tables/ContractsTable';
import { ReceiptsTable } from './components/tables/ReceiptsTable';
import { InvoicesTable } from './components/tables/InvoicesTable';
import { BankStatementsTable } from './components/tables/BankStatementsTable';
import { BankReconciliationWorkbench } from './components/reconciliation/BankReconciliationWorkbench';
import { ReportsAndSummary } from './components/reports/ReportsAndSummary';
import { ExportManager } from './components/export/ExportManager';
import { UserRoleManager } from './components/admin/UserRoleManager';
import { DocumentUploadModal } from './components/upload/DocumentUploadModal';
import { AuthModal } from './components/auth/AuthModal';
import { ActiveTab } from './types';

export function AppContent() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [uploadConfig, setUploadConfig] = useState<{
    isOpen: boolean;
    defaultType: 'contract' | 'receipt' | 'invoice' | 'statement';
    initialMode: 'upload' | 'camera';
  }>({
    isOpen: false,
    defaultType: 'contract',
    initialMode: 'upload',
  });
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);

  const handleOpenUpload = (options?: {
    type?: 'contract' | 'receipt' | 'invoice' | 'statement';
    mode?: 'upload' | 'camera';
  }) => {
    setUploadConfig({
      isOpen: true,
      defaultType: options?.type || (activeTab === 'invoices' ? 'invoice' : activeTab === 'receipts' ? 'receipt' : activeTab === 'contracts' ? 'contract' : 'contract'),
      initialMode: options?.mode || 'upload',
    });
  };

  return (
    <div className="flex h-screen bg-[#F8FAFC] text-slate-900 font-sans overflow-hidden">
      {/* Left Blue & White Side Panel */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenUpload={() => handleOpenUpload()}
        onOpenAuth={() => setAuthModalOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header with Global Filters */}
        <Header
          activeTab={activeTab}
          onOpenUpload={() => handleOpenUpload()}
          onOpenExport={() => setActiveTab('export')}
        />

        {/* Scrollable Viewport */}
        <main className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-300">
          {activeTab === 'dashboard' && (
            <Dashboard
              onNavigate={(tab) => setActiveTab(tab)}
              onOpenUpload={() => handleOpenUpload()}
            />
          )}

          {activeTab === 'contracts' && (
            <ContractsTable onOpenUpload={() => handleOpenUpload({ type: 'contract' })} />
          )}

          {activeTab === 'receipts' && (
            <ReceiptsTable onOpenUpload={() => handleOpenUpload({ type: 'receipt' })} />
          )}

          {activeTab === 'invoices' && (
            <InvoicesTable onOpenUpload={(opts) => handleOpenUpload({ type: 'invoice', mode: opts?.mode || 'upload' })} />
          )}

          {activeTab === 'bank-statements' && (
            <BankStatementsTable
              onOpenUpload={() => handleOpenUpload({ type: 'statement' })}
              onNavigateToReconcile={() => setActiveTab('reconciliation')}
            />
          )}

          {activeTab === 'reconciliation' && <BankReconciliationWorkbench />}

          {activeTab === 'reports' && <ReportsAndSummary />}

          {activeTab === 'export' && <ExportManager />}

          {activeTab === 'users' && <UserRoleManager />}
        </main>
      </div>

      {/* Document Intake & AI OCR Modal with Camera Support */}
      <DocumentUploadModal
        isOpen={uploadConfig.isOpen}
        onClose={() => setUploadConfig((prev) => ({ ...prev, isOpen: false }))}
        defaultType={uploadConfig.defaultType}
        initialMode={uploadConfig.initialMode}
      />

      {/* Sign In & Sign Up Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <PropertyDataProvider>
        <AppContent />
      </PropertyDataProvider>
    </AuthProvider>
  );
}
