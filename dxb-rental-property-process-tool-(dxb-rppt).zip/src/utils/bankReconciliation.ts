import * as XLSX from 'xlsx';
import {
  BankStatement,
  BankTransaction,
  BankReconciliationSummary,
  RentalReceipt,
  PurchaseTaxInvoice,
  OtherPaymentCategory,
} from '../types';

export interface ParseResult {
  statement: Omit<BankStatement, 'id' | 'userId' | 'createdAt' | 'updatedAt'>;
  transactions: Omit<BankTransaction, 'id' | 'statementId' | 'userId' | 'createdAt' | 'updatedAt'>[];
  errors: string[];
}

/**
 * Normalizes text for fuzzy keyword matching
 */
export function normalizeText(text?: string | null): string {
  if (!text) return '';
  return text
    .toLowerCase()
    .replace(/[^a-z0-9]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Parses numeric currency strings like "AED 12,500.50", "(500.00)", "1,200.00"
 */
export function parseCurrencyAmount(val: any): number {
  if (val === null || val === undefined) return 0;
  if (typeof val === 'number') return isNaN(val) ? 0 : Math.abs(val);

  const str = String(val).trim();
  if (!str) return 0;

  // Handle negative enclosed in parentheses e.g. (1,500.00)
  const isNegative = str.startsWith('(') && str.endsWith(')');
  const clean = str.replace(/[^\d.-]/g, '');
  const parsed = parseFloat(clean);
  if (isNaN(parsed)) return 0;
  return isNegative ? -Math.abs(parsed) : Math.abs(parsed);
}

/**
 * Formats date into standard YYYY-MM-DD
 */
export function normalizeDate(dateVal: any): string {
  if (!dateVal) return new Date().toISOString().slice(0, 10);
  if (dateVal instanceof Date && !isNaN(dateVal.getTime())) {
    return dateVal.toISOString().slice(0, 10);
  }

  const str = String(dateVal).trim();
  // Already YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) return str;

  // DD/MM/YYYY or DD-MM-YYYY
  const dmyMatch = str.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/);
  if (dmyMatch) {
    const [, day, month, year] = dmyMatch;
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
  }

  // MM/DD/YYYY
  const parsed = new Date(str);
  if (!isNaN(parsed.getTime())) {
    return parsed.toISOString().slice(0, 10);
  }

  return new Date().toISOString().slice(0, 10);
}

/**
 * Parses CSV text into Bank Statement & Transactions
 */
export function parseCSVBankStatement(csvText: string, fileName?: string): ParseResult {
  const lines = csvText
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  const errors: string[] = [];
  const transactions: Omit<BankTransaction, 'id' | 'statementId' | 'userId' | 'createdAt' | 'updatedAt'>[] = [];

  if (lines.length < 2) {
    return {
      statement: {
        bankName: detectBankName(fileName || '', csvText),
        accountNumber: 'AE' + Math.floor(1000000000000000000 + Math.random() * 9000000000000000000),
        statementPeriodStart: new Date().toISOString().slice(0, 10),
        statementPeriodEnd: new Date().toISOString().slice(0, 10),
        openingBalance: 0,
        closingBalance: 0,
        currency: 'AED',
        fileName,
        totalDebits: 0,
        totalCredits: 0,
        transactionsCount: 0,
        reconciledCount: 0,
        unreconciledCount: 0,
        status: 'draft',
      },
      transactions: [],
      errors: ['Bank statement file is empty or missing headers.'],
    };
  }

  // Locate the header line
  let headerIndex = -1;
  let headers: string[] = [];

  for (let i = 0; i < Math.min(lines.length, 15); i++) {
    const cols = parseCSVRow(lines[i]).map((c) => c.toLowerCase().trim());
    if (
      cols.some((c) => c.includes('date')) &&
      (cols.some((c) => c.includes('debit') || c.includes('withdrawal') || c.includes('paid out')) ||
        cols.some((c) => c.includes('amount')))
    ) {
      headerIndex = i;
      headers = cols;
      break;
    }
  }

  if (headerIndex === -1) {
    headerIndex = 0;
    headers = parseCSVRow(lines[0]).map((c) => c.toLowerCase().trim());
  }

  const dateIdx = headers.findIndex((h) => h.includes('date') && !h.includes('value'));
  const valueDateIdx = headers.findIndex((h) => h.includes('value date'));
  const descIdx = headers.findIndex((h) => h.includes('desc') || h.includes('particular') || h.includes('narrative') || h.includes('detail'));
  const refIdx = headers.findIndex((h) => h.includes('ref') || h.includes('cheque') || h.includes('chq') || h.includes('txn'));
  const debitIdx = headers.findIndex((h) => h.includes('debit') || h.includes('withdrawal') || h.includes('paid out') || h.includes('dr'));
  const creditIdx = headers.findIndex((h) => h.includes('credit') || h.includes('deposit') || h.includes('paid in') || h.includes('cr'));
  const amountIdx = headers.findIndex((h) => h === 'amount' || h.includes('net amount') || h.includes('trans amount'));
  const balanceIdx = headers.findIndex((h) => h.includes('balance') || h.includes('running'));

  let totalDebits = 0;
  let totalCredits = 0;
  const dates: string[] = [];

  for (let i = headerIndex + 1; i < lines.length; i++) {
    const row = parseCSVRow(lines[i]);
    if (row.length === 0 || row.every((c) => !c.trim())) continue;

    const rawDate = dateIdx >= 0 ? row[dateIdx] : row[0];
    const date = normalizeDate(rawDate);
    const valueDate = valueDateIdx >= 0 ? normalizeDate(row[valueDateIdx]) : undefined;
    const description = descIdx >= 0 ? row[descIdx] : (row[1] || 'Bank Transaction');
    const referenceNo = refIdx >= 0 ? row[refIdx] : '';

    let debit = 0;
    let credit = 0;

    if (debitIdx >= 0 && creditIdx >= 0) {
      debit = parseCurrencyAmount(row[debitIdx]);
      credit = parseCurrencyAmount(row[creditIdx]);
    } else if (amountIdx >= 0) {
      const rawAmt = row[amountIdx];
      const parsed = parseCurrencyAmount(rawAmt);
      if (rawAmt && (rawAmt.includes('-') || rawAmt.includes('('))) {
        debit = Math.abs(parsed);
      } else {
        credit = Math.abs(parsed);
      }
    } else {
      // Fallback
      credit = parseCurrencyAmount(row[row.length - 1]);
    }

    const balance = balanceIdx >= 0 ? parseCurrencyAmount(row[balanceIdx]) : undefined;

    if (debit > 0) {
      totalDebits += debit;
      dates.push(date);
      transactions.push({
        date,
        valueDate,
        description: description || 'Bank Debit',
        referenceNo: referenceNo || extractReference(description),
        type: 'debit',
        amount: Number(debit.toFixed(2)),
        balance,
        reconciliationStatus: 'unreconciled',
      });
    } else if (credit > 0) {
      totalCredits += credit;
      dates.push(date);
      transactions.push({
        date,
        valueDate,
        description: description || 'Bank Credit',
        referenceNo: referenceNo || extractReference(description),
        type: 'credit',
        amount: Number(credit.toFixed(2)),
        balance,
        reconciliationStatus: 'unreconciled',
      });
    }
  }

  dates.sort();
  const periodStart = dates[0] || new Date().toISOString().slice(0, 10);
  const periodEnd = dates[dates.length - 1] || new Date().toISOString().slice(0, 10);

  const lastTxBalance = transactions.length > 0 ? transactions[transactions.length - 1].balance : undefined;
  const firstTxBalance = transactions.length > 0 ? transactions[0].balance : undefined;

  const closingBalance = lastTxBalance !== undefined ? lastTxBalance : Number((totalCredits - totalDebits).toFixed(2));
  const openingBalance = firstTxBalance !== undefined
    ? Number((firstTxBalance - (transactions[0]?.type === 'credit' ? transactions[0].amount : -transactions[0].amount)).toFixed(2))
    : 0;

  return {
    statement: {
      bankName: detectBankName(fileName || '', csvText),
      accountNumber: extractAccountNumber(csvText) || 'AE290330' + Math.floor(1000000000000 + Math.random() * 9000000000000),
      accountTitle: 'DXB Real Estate Portfolio Account',
      statementPeriodStart: periodStart,
      statementPeriodEnd: periodEnd,
      openingBalance,
      closingBalance,
      currency: 'AED',
      fileName,
      totalDebits: Number(totalDebits.toFixed(2)),
      totalCredits: Number(totalCredits.toFixed(2)),
      transactionsCount: transactions.length,
      reconciledCount: 0,
      unreconciledCount: transactions.length,
      status: 'draft',
    },
    transactions,
    errors,
  };
}

/**
 * Parses XLSX / XLS buffer into Bank Statement & Transactions
 */
export function parseExcelBankStatement(data: ArrayBuffer | Uint8Array, fileName?: string): ParseResult {
  const workbook = XLSX.read(data, { type: 'array' });
  const firstSheetName = workbook.SheetNames[0];
  const worksheet = workbook.Sheets[firstSheetName];
  const csvText = XLSX.utils.sheet_to_csv(worksheet);
  return parseCSVBankStatement(csvText, fileName);
}

function parseCSVRow(text: string): string[] {
  const result: string[] = [];
  let cur = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (ch === '"') {
      if (inQuotes && text[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (ch === ',' && !inQuotes) {
      result.push(cur.trim());
      cur = '';
    } else {
      cur += ch;
    }
  }
  result.push(cur.trim());
  return result;
}

function detectBankName(fileName: string, text: string): string {
  const combined = (fileName + ' ' + text.slice(0, 2000)).toLowerCase();
  if (combined.includes('emirates nbd') || combined.includes('enbd')) return 'Emirates NBD';
  if (combined.includes('adcb') || combined.includes('abu dhabi commercial')) return 'Abu Dhabi Commercial Bank (ADCB)';
  if (combined.includes('dubai islamic bank') || combined.includes('dib')) return 'Dubai Islamic Bank (DIB)';
  if (combined.includes('first abu dhabi') || combined.includes('fab')) return 'First Abu Dhabi Bank (FAB)';
  if (combined.includes('mashreq')) return 'Mashreq Bank';
  if (combined.includes('rakbank') || combined.includes('ras al khaimah')) return 'RAKBANK';
  if (combined.includes('cbd') || combined.includes('commercial bank of dubai')) return 'Commercial Bank of Dubai (CBD)';
  return 'Emirates NBD (Dubai Branch)';
}

function extractAccountNumber(text: string): string | null {
  const ibanMatch = text.match(/AE\d{2}[A-Z0-9]{19}/i);
  if (ibanMatch) return ibanMatch[0].toUpperCase();
  const accMatch = text.match(/Account\s*(?:No|Number|#)?\s*[:.-]?\s*([0-9]{8,16})/i);
  if (accMatch) return accMatch[1];
  return null;
}

function extractReference(description?: string): string {
  if (!description) return '';
  const chqMatch = description.match(/(?:chq|cheque|ref|ft|txn|trn|no)[#.:\s]*([0-9a-zA-Z-]{4,16})/i);
  if (chqMatch) return chqMatch[1].toUpperCase();
  return '';
}

/**
 * Intelligent Auto-Reconciliation Engine:
 * - Debits matched with Maintenance Invoices / Bills / Payments
 * - Credits matched with Rental Receipts / Deposits
 */
export function autoReconcileTransactions(
  transactions: BankTransaction[],
  invoices: PurchaseTaxInvoice[],
  receipts: RentalReceipt[]
): {
  reconciledTransactions: BankTransaction[];
  matchedCount: number;
  suggestedCount: number;
} {
  let matchedCount = 0;
  let suggestedCount = 0;

  // Track already-matched IDs so an invoice or receipt is not matched twice
  const matchedInvoiceIds = new Set<string>();
  const matchedReceiptIds = new Set<string>();

  // Pre-seed already matched entities from transactions that are already locked
  transactions.forEach((tx) => {
    if (tx.reconciliationStatus === 'matched' && tx.matchedEntityId) {
      if (tx.type === 'debit') matchedInvoiceIds.add(tx.matchedEntityId);
      if (tx.type === 'credit') matchedReceiptIds.add(tx.matchedEntityId);
    }
  });

  const updatedTransactions = transactions.map((tx) => {
    // Preserve already manually matched transactions
    if (tx.reconciliationStatus === 'matched' || tx.reconciliationStatus === 'manual_other') {
      return tx;
    }

    const txDate = new Date(tx.date).getTime();
    const txDesc = normalizeText(tx.description);
    const txRef = normalizeText(tx.referenceNo || '');

    // 1. CREDIT SIDE -> Match with RentalReceipts
    if (tx.type === 'credit') {
      let bestReceipt: RentalReceipt | null = null;
      let matchConfidence = 0; // 0 to 100

      for (const r of receipts) {
        if (matchedReceiptIds.has(r.id)) continue;

        const rAmount = Number(r.amount);
        const amountExact = Math.abs(rAmount - tx.amount) < 0.05;
        const rDate = new Date(r.installmentDate).getTime();
        const daysDiff = Math.abs((txDate - rDate) / (1000 * 60 * 60 * 24));

        const rCheque = normalizeText(r.chequeNo);
        const rReceiptNo = normalizeText(r.receiptNo);
        const rTenant = normalizeText(r.tenantName);
        const rBank = normalizeText(r.bankName);

        const chqInDesc = rCheque.length > 2 && (txDesc.includes(rCheque) || txRef.includes(rCheque));
        const receiptNoInDesc = rReceiptNo.length > 2 && txDesc.includes(rReceiptNo);
        const tenantInDesc = rTenant.length > 3 && txDesc.includes(rTenant);

        // Exact match scenario: Amount + Cheque # or Receipt #
        if (amountExact && (chqInDesc || receiptNoInDesc)) {
          bestReceipt = r;
          matchConfidence = 100;
          break;
        }

        // High match scenario: Amount + Tenant name
        if (amountExact && tenantInDesc) {
          bestReceipt = r;
          matchConfidence = 95;
          break;
        }

        // Date proximity match: Exact amount within 30 days
        if (amountExact && daysDiff <= 30 && matchConfidence < 85) {
          bestReceipt = r;
          matchConfidence = 85;
        }

        // Suggested match: Tenant name + Date within 14 days, amount within 5%
        if (tenantInDesc && daysDiff <= 14 && Math.abs(rAmount - tx.amount) / rAmount < 0.05 && matchConfidence < 75) {
          bestReceipt = r;
          matchConfidence = 75;
        }
      }

      if (bestReceipt && matchConfidence >= 85) {
        matchedReceiptIds.add(bestReceipt.id);
        matchedCount++;
        return {
          ...tx,
          reconciliationStatus: 'matched' as const,
          matchedEntityType: 'receipt' as const,
          matchedEntityId: bestReceipt.id,
          matchedEntityRef: bestReceipt.receiptNo || bestReceipt.chequeNo,
          matchedEntityName: bestReceipt.tenantName || 'Tenant Deposit',
          matchedAmount: bestReceipt.amount,
          differenceAmount: Number((tx.amount - bestReceipt.amount).toFixed(2)),
          notes: `Auto-reconciled with Rent Receipt #${bestReceipt.receiptNo} (${matchConfidence}% confidence)`,
          reconciledAt: new Date().toISOString(),
          reconciledBy: 'System Auto-Match',
        };
      } else if (bestReceipt && matchConfidence >= 70) {
        suggestedCount++;
        return {
          ...tx,
          reconciliationStatus: 'suggested' as const,
          matchedEntityType: 'receipt' as const,
          matchedEntityId: bestReceipt.id,
          matchedEntityRef: bestReceipt.receiptNo || bestReceipt.chequeNo,
          matchedEntityName: bestReceipt.tenantName || 'Tenant Deposit',
          matchedAmount: bestReceipt.amount,
          differenceAmount: Number((tx.amount - bestReceipt.amount).toFixed(2)),
          notes: `Suggested Match: Rent Receipt #${bestReceipt.receiptNo} (Review & confirm)`,
        };
      }
    }

    // 2. DEBIT SIDE -> Match with PurchaseTaxInvoice (Maintenance / Bills)
    if (tx.type === 'debit') {
      let bestInvoice: PurchaseTaxInvoice | null = null;
      let matchConfidence = 0;

      for (const inv of invoices) {
        if (matchedInvoiceIds.has(inv.id)) continue;

        const grossAmount = Number(inv.totalInvoiceAmount);
        const netAmount = Number(inv.netAmount);

        // Check gross total or net total
        const grossExact = Math.abs(grossAmount - tx.amount) < 0.05;
        const netExact = Math.abs(netAmount - tx.amount) < 0.05;

        const invDate = new Date(inv.invoiceDate).getTime();
        const daysDiff = Math.abs((txDate - invDate) / (1000 * 60 * 60 * 24));

        const invNum = normalizeText(inv.invoiceNumber);
        const supplier = normalizeText(inv.supplierName);

        const numInDesc = invNum.length > 2 && (txDesc.includes(invNum) || txRef.includes(invNum));
        const supplierInDesc = supplier.length > 3 && txDesc.includes(supplier);

        // Exact match: Amount + (Invoice # or Supplier name)
        if ((grossExact || netExact) && (numInDesc || supplierInDesc)) {
          bestInvoice = inv;
          matchConfidence = 100;
          break;
        }

        // High match: Exact gross amount + within 45 days
        if (grossExact && daysDiff <= 45 && matchConfidence < 85) {
          bestInvoice = inv;
          matchConfidence = 85;
        }

        // Supplier match within 14 days
        if (supplierInDesc && daysDiff <= 14 && matchConfidence < 75) {
          bestInvoice = inv;
          matchConfidence = 75;
        }
      }

      if (bestInvoice && matchConfidence >= 85) {
        matchedInvoiceIds.add(bestInvoice.id);
        matchedCount++;
        return {
          ...tx,
          reconciliationStatus: 'matched' as const,
          matchedEntityType: 'invoice' as const,
          matchedEntityId: bestInvoice.id,
          matchedEntityRef: bestInvoice.invoiceNumber,
          matchedEntityName: bestInvoice.supplierName,
          matchedAmount: bestInvoice.totalInvoiceAmount,
          differenceAmount: Number((tx.amount - bestInvoice.totalInvoiceAmount).toFixed(2)),
          notes: `Auto-reconciled with Maintenance Invoice #${bestInvoice.invoiceNumber} (${matchConfidence}% confidence)`,
          reconciledAt: new Date().toISOString(),
          reconciledBy: 'System Auto-Match',
        };
      } else if (bestInvoice && matchConfidence >= 70) {
        suggestedCount++;
        return {
          ...tx,
          reconciliationStatus: 'suggested' as const,
          matchedEntityType: 'invoice' as const,
          matchedEntityId: bestInvoice.id,
          matchedEntityRef: bestInvoice.invoiceNumber,
          matchedEntityName: bestInvoice.supplierName,
          matchedAmount: bestInvoice.totalInvoiceAmount,
          differenceAmount: Number((tx.amount - bestInvoice.totalInvoiceAmount).toFixed(2)),
          notes: `Suggested Match: Maintenance Invoice #${bestInvoice.invoiceNumber} (Review & confirm)`,
        };
      }

      // Check if it's an identifiable common UAE property utility/fee
      const detectedCategory = detectOtherPaymentCategory(tx.description);
      if (detectedCategory) {
        return {
          ...tx,
          otherPaymentCategory: detectedCategory,
          notes: `Detected utility / service payment: ${detectedCategory}`,
        };
      }
    }

    return tx;
  });

  return {
    reconciledTransactions: updatedTransactions,
    matchedCount,
    suggestedCount,
  };
}

/**
 * Detects standard UAE utility / service expense from bank narrative
 */
export function detectOtherPaymentCategory(desc: string): OtherPaymentCategory | undefined {
  const lower = desc.toLowerCase();
  if (lower.includes('dewa') || lower.includes('sewa') || lower.includes('fewa') || lower.includes('electricity') || lower.includes('water')) {
    return 'DEWA / Electricity & Water';
  }
  if (lower.includes('empower') || lower.includes('tabreed') || lower.includes('chiller') || lower.includes('cooling')) {
    return 'Chiller & Air Conditioning';
  }
  if (lower.includes('ejari') || lower.includes('dubai land') || lower.includes('dld') || lower.includes('municipality')) {
    return 'Govt & Municipal / Ejari Fees';
  }
  if (lower.includes('bank charge') || lower.includes('service fee') || lower.includes('chq return') || lower.includes('vat on fee') || lower.includes('commission')) {
    return 'Bank Charges & Commission';
  }
  if (lower.includes('fta') || lower.includes('federal tax') || lower.includes('tax payment') || lower.includes('vat settlement')) {
    return 'VAT / FTA Tax Settlement';
  }
  if (lower.includes('mortgage') || lower.includes('loan') || lower.includes('emi') || lower.includes('finance')) {
    return 'Mortgage / Loan Installment';
  }
  if (lower.includes('deposit refund') || lower.includes('sec dep ret')) {
    return 'Security Deposit Refund';
  }
  return undefined;
}

/**
 * Computes standard Bank Reconciliation Statement (BRS) figures
 */
export function computeBankReconciliationSummary(
  statement: BankStatement | null,
  transactions: BankTransaction[],
  receipts: RentalReceipt[],
  invoices: PurchaseTaxInvoice[]
): BankReconciliationSummary {
  const closingBalance = statement ? statement.closingBalance : 0;

  // Track matched IDs
  const matchedReceiptIds = new Set<string>();
  const matchedInvoiceIds = new Set<string>();

  let reconciledDebitsAmount = 0;
  let reconciledCreditsAmount = 0;
  let unrecordedBankCredits = 0;
  let unrecordedBankDebits = 0;

  let totalDebits = 0;
  let totalCredits = 0;
  let pendingDebitsCount = 0;
  let pendingCreditsCount = 0;

  transactions.forEach((tx) => {
    if (tx.type === 'debit') {
      totalDebits += tx.amount;
      if (tx.reconciliationStatus === 'matched' || tx.reconciliationStatus === 'manual_other') {
        reconciledDebitsAmount += tx.amount;
        if (tx.matchedEntityId) matchedInvoiceIds.add(tx.matchedEntityId);
      } else {
        pendingDebitsCount++;
        unrecordedBankDebits += tx.amount;
      }
    } else {
      totalCredits += tx.amount;
      if (tx.reconciliationStatus === 'matched') {
        reconciledCreditsAmount += tx.amount;
        if (tx.matchedEntityId) matchedReceiptIds.add(tx.matchedEntityId);
      } else {
        pendingCreditsCount++;
        unrecordedBankCredits += tx.amount;
      }
    }
  });

  // 1. Deposits in Transit = Rental Receipts in books not yet credited in bank
  const unclearedReceipts = receipts.filter((r) => !matchedReceiptIds.has(r.id));
  const depositsInTransit = unclearedReceipts.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);

  // 2. Outstanding Cheques / Payments = Invoices in books not yet debited in bank
  const unclearedInvoices = invoices.filter((i) => !matchedInvoiceIds.has(i.id));
  const unclearedDebits = unclearedInvoices.reduce((sum, i) => sum + (Number(i.totalInvoiceAmount) || 0), 0);

  // Adjusted Bank Balance = Closing Balance + Deposits in transit - Uncleared debits
  const adjustedBankBalance = Number((closingBalance + depositsInTransit - unclearedDebits).toFixed(2));

  // Book Balance = Total receipts in books - Total invoices in books
  const totalBookReceipts = receipts.reduce((sum, r) => sum + (Number(r.amount) || 0), 0);
  const totalBookInvoices = invoices.reduce((sum, i) => sum + (Number(i.totalInvoiceAmount) || 0), 0);
  const bookBalance = Number((totalBookReceipts - totalBookInvoices).toFixed(2));

  // Adjusted Book Balance = Book Balance + unrecorded bank credits - unrecorded bank debits
  const adjustedBookBalance = Number((bookBalance + unrecordedBankCredits - unrecordedBankDebits).toFixed(2));

  // Difference / Variance
  const variance = Number((adjustedBankBalance - adjustedBookBalance).toFixed(2));
  const isBalanced = Math.abs(variance) < 1.0;

  return {
    statementClosingBalance: closingBalance,
    depositsInTransit: Number(depositsInTransit.toFixed(2)),
    unclearedDebits: Number(unclearedDebits.toFixed(2)),
    adjustedBankBalance,
    bookBalance,
    unrecordedBankCredits: Number(unrecordedBankCredits.toFixed(2)),
    unrecordedBankDebits: Number(unrecordedBankDebits.toFixed(2)),
    adjustedBookBalance,
    variance,
    isBalanced,
    totalDebits: Number(totalDebits.toFixed(2)),
    totalCredits: Number(totalCredits.toFixed(2)),
    reconciledDebitsAmount: Number(reconciledDebitsAmount.toFixed(2)),
    reconciledCreditsAmount: Number(reconciledCreditsAmount.toFixed(2)),
    pendingDebitsCount,
    pendingCreditsCount,
  };
}

/**
 * Generates sample UAE bank statement tailored to match existing invoices and receipts
 */
export function generateSampleUAEBankStatement(
  invoices: PurchaseTaxInvoice[] = [],
  receipts: RentalReceipt[] = []
): {
  statement: BankStatement;
  transactions: BankTransaction[];
} {
  const statementId = 'stmt_uae_' + Date.now();
  const userId = 'sample_user';
  const now = new Date();
  const startStr = new Date(now.getFullYear(), now.getMonth() - 1, 1).toISOString().slice(0, 10);
  const endStr = new Date(now.getFullYear(), now.getMonth(), 0).toISOString().slice(0, 10);

  const transactions: BankTransaction[] = [];
  let runningBalance = 250000; // Opening balance AED 250,000.00
  const openingBalance = runningBalance;

  // 1. Credits from receipts (match first 80% to leave some as deposits in transit)
  const receiptsToInclude = receipts.length > 0 ? receipts.slice(0, Math.max(1, Math.ceil(receipts.length * 0.8))) : [];

  if (receiptsToInclude.length === 0) {
    // Fallback realistic UAE rental deposits if no receipts exist yet
    const dummyReceipts = [
      { desc: 'CHQ DEP #88201 AL WASL TOWER UNIT 402 MOHAMMED ALI', amt: 35000, ref: '88201', date: '2025-05-05' },
      { desc: 'ONLINE TRF RENT INST MARINA PINNACLE UNIT 1205 JOHN SMITH', amt: 22500, ref: 'FT250508001', date: '2025-05-10' },
      { desc: 'CHQ CLEARING #77412 EXECUTIVE HEIGHTS SUITE 801 TECH SOLUTIONS', amt: 65000, ref: '77412', date: '2025-05-15' },
      { desc: 'DIRECT DEP RENT DOWNTOWN RESIDENCE APT 304 FATIMA AHMED', amt: 18000, ref: 'FT25052044', date: '2025-05-20' },
    ];
    dummyReceipts.forEach((r, idx) => {
      runningBalance += r.amt;
      transactions.push({
        id: `tx_credit_${idx + 1}`,
        statementId,
        userId,
        date: r.date,
        description: r.desc,
        referenceNo: r.ref,
        chequeNo: r.ref.startsWith('FT') ? undefined : r.ref,
        type: 'credit',
        amount: r.amt,
        balance: runningBalance,
        reconciliationStatus: 'unreconciled',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    });
  } else {
    receiptsToInclude.forEach((r, idx) => {
      runningBalance += Number(r.amount);
      transactions.push({
        id: `tx_rec_${r.id}`,
        statementId,
        userId,
        date: r.installmentDate || endStr,
        description: `CHQ DEP #${r.chequeNo || 'CHQ' + (1000 + idx)} ${r.tenantName || 'RENT DEPOSIT'} ${r.propertyRef || ''}`.trim(),
        referenceNo: r.chequeNo || r.receiptNo,
        chequeNo: r.chequeNo,
        type: 'credit',
        amount: Number(r.amount),
        balance: runningBalance,
        reconciliationStatus: 'unreconciled',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    });
  }

  // 2. Debits from invoices (match first 75% to leave some as uncleared unpresented cheques)
  const invoicesToInclude = invoices.length > 0 ? invoices.slice(0, Math.max(1, Math.ceil(invoices.length * 0.75))) : [];

  if (invoicesToInclude.length === 0) {
    // Fallback realistic UAE maintenance payments
    const dummyDebits = [
      { desc: 'WPS/TRF INV-9042 AL SHAMS HVAC CHILLER MAINTENANCE LLC', amt: 8400, ref: 'INV-9042', date: '2025-05-07' },
      { desc: 'CHQ PAID #501192 DUBAI CLEANING & FACILITY SERVICES', amt: 4200, ref: '501192', date: '2025-05-12' },
      { desc: 'DIRECT DEBIT DEWA DUBAI ELECTRICITY & WATER ACCOUNT 20049281', amt: 6350, ref: 'DEWA2004', date: '2025-05-18' },
      { desc: 'BANK SERVICE CHARGES & MONTHLY ACCOUNT MAINTENANCE FEE', amt: 105, ref: 'BKCHG-MAY', date: '2025-05-25' },
    ];
    dummyDebits.forEach((d, idx) => {
      runningBalance -= d.amt;
      transactions.push({
        id: `tx_debit_${idx + 1}`,
        statementId,
        userId,
        date: d.date,
        description: d.desc,
        referenceNo: d.ref,
        type: 'debit',
        amount: d.amt,
        balance: runningBalance,
        reconciliationStatus: 'unreconciled',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    });
  } else {
    invoicesToInclude.forEach((inv) => {
      runningBalance -= Number(inv.totalInvoiceAmount);
      transactions.push({
        id: `tx_inv_${inv.id}`,
        statementId,
        userId,
        date: inv.invoiceDate || endStr,
        description: `WPS/TRF #${inv.invoiceNumber} ${inv.supplierName} ${inv.expenseCategory || 'MAINTENANCE'}`.trim(),
        referenceNo: inv.invoiceNumber,
        type: 'debit',
        amount: Number(inv.totalInvoiceAmount),
        balance: runningBalance,
        reconciliationStatus: 'unreconciled',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
    });

    // Add 2 standard bank utility debits
    runningBalance -= 5400;
    transactions.push({
      id: `tx_util_dewa`,
      statementId,
      userId,
      date: startStr,
      description: 'DIRECT DEBIT DEWA DUBAI ELECTRICITY & WATER PREMISES 20088191',
      referenceNo: 'DEWA-MAY',
      type: 'debit',
      amount: 5400,
      balance: runningBalance,
      otherPaymentCategory: 'DEWA / Electricity & Water',
      reconciliationStatus: 'manual_other',
      notes: 'Monthly utility settlement for building common area',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });

    runningBalance -= 105;
    transactions.push({
      id: `tx_util_fee`,
      statementId,
      userId,
      date: endStr,
      description: 'BANK SERVICE CHARGES & LEDGER AUDIT FEE + 5% VAT',
      referenceNo: 'SC-MAY-25',
      type: 'debit',
      amount: 105,
      balance: runningBalance,
      otherPaymentCategory: 'Bank Charges & Commission',
      reconciliationStatus: 'manual_other',
      notes: 'Bank ledger maintenance fee',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }

  // Sort by date
  transactions.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  let totalDebits = 0;
  let totalCredits = 0;
  transactions.forEach((tx) => {
    if (tx.type === 'debit') totalDebits += tx.amount;
    else totalCredits += tx.amount;
  });

  const statement: BankStatement = {
    id: statementId,
    userId,
    bankName: 'Emirates NBD',
    accountNumber: 'AE290330001099281729401',
    accountTitle: 'DXB Real Estate Portfolio - Rental & Operations',
    statementPeriodStart: startStr,
    statementPeriodEnd: endStr,
    openingBalance: Number(openingBalance.toFixed(2)),
    closingBalance: Number(runningBalance.toFixed(2)),
    currency: 'AED',
    fileName: 'Emirates_NBD_Statement_May2025.csv',
    totalDebits: Number(totalDebits.toFixed(2)),
    totalCredits: Number(totalCredits.toFixed(2)),
    transactionsCount: transactions.length,
    reconciledCount: 0,
    unreconciledCount: transactions.length,
    status: 'draft',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  return { statement, transactions };
}

/**
 * Downloads a standard CSV template for bank statement upload
 */
export function downloadBankStatementTemplate() {
  const headers = ['Date', 'Value Date', 'Description / Narrative', 'Reference / Cheque No', 'Debit (Withdrawal)', 'Credit (Deposit)', 'Balance'];
  const sampleRows = [
    ['2025-05-02', '2025-05-02', 'OPENING BALANCE', 'OPB-001', '', '', '250000.00'],
    ['2025-05-05', '2025-05-05', 'CHQ DEP #88201 AL WASL TOWER UNIT 402 MOHAMMED ALI', '88201', '', '35000.00', '285000.00'],
    ['2025-05-08', '2025-05-08', 'WPS/TRF INV-9042 AL SHAMS HVAC CHILLER MAINTENANCE LLC', 'INV-9042', '8400.00', '', '276600.00'],
    ['2025-05-12', '2025-05-12', 'DIRECT DEBIT DEWA DUBAI ELECTRICITY PREMISES 20049281', 'DEWA2004', '4200.00', '', '272400.00'],
    ['2025-05-15', '2025-05-15', 'CHQ CLEARING #77412 EXECUTIVE HEIGHTS SUITE 801 TECH SOLUTIONS', '77412', '', '65000.00', '337400.00'],
    ['2025-05-20', '2025-05-20', 'CHQ PAID #501192 DUBAI CLEANING & FACILITY SERVICES', '501192', '3150.00', '', '334250.00'],
    ['2025-05-28', '2025-05-28', 'BANK SERVICE CHARGES & MONTHLY ACCOUNT FEE', 'BKCHG-MAY', '105.00', '', '334145.00'],
  ];

  const csvContent = [headers.join(','), ...sampleRows.map((r) => r.map((c) => `"${c}"`).join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'UAE_Bank_Statement_Upload_Template.csv';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
