import { BatchItem, TenancyContract, RentalReceipt, PurchaseTaxInvoice } from '../types';

export interface DuplicationAlert {
  type: 'invoice' | 'unit' | 'receipt';
  label: string;
  value: string;
  source: 'batch' | 'database';
  details: string;
  matchedName?: string;
}

const cleanString = (val?: string | null): string => {
  if (!val) return '';
  return val.trim().toLowerCase().replace(/\s+/g, ' ');
};

const isGenericPlaceholder = (val?: string | null): boolean => {
  if (!val) return true;
  const lower = val.trim().toLowerCase();
  return (
    lower === '' ||
    lower === '-' ||
    lower === 'n/a' ||
    lower === 'na' ||
    lower === 'pending' ||
    lower === 'none' ||
    lower === 'null' ||
    lower === 'undefined'
  );
};

/**
 * Checks for invoice number duplication against both existing database invoices and current batch
 */
export function checkInvoiceDuplication(
  invoiceNumber: string | undefined,
  currentItemId: string,
  allItems: BatchItem[],
  existingInvoices: PurchaseTaxInvoice[] = []
): DuplicationAlert | null {
  if (isGenericPlaceholder(invoiceNumber)) return null;
  const cleanInv = cleanString(invoiceNumber);
  if (cleanInv.length < 2) return null;

  // 1. Check against existing database invoices
  const dbMatch = existingInvoices.find(
    (inv) => cleanString(inv.invoiceNumber) === cleanInv
  );
  if (dbMatch) {
    return {
      type: 'invoice',
      label: 'Invoice Number',
      value: invoiceNumber!.trim(),
      source: 'database',
      details: `Invoice #${dbMatch.invoiceNumber} already exists in database (Supplier: ${
        dbMatch.supplierName || 'Unknown'
      }, Date: ${dbMatch.invoiceDate || 'N/A'})`,
      matchedName: dbMatch.supplierName,
    };
  }

  // 2. Check against other items in the batch
  const batchMatch = allItems.find((item) => {
    if (item.id === currentItemId) return false;
    const otherInv = item.extractedData?.invoice?.invoiceNumber;
    return !isGenericPlaceholder(otherInv) && cleanString(otherInv) === cleanInv;
  });

  if (batchMatch) {
    return {
      type: 'invoice',
      label: 'Invoice Number',
      value: invoiceNumber!.trim(),
      source: 'batch',
      details: `Duplicate Invoice #${invoiceNumber!.trim()} is also present in batch file "${
        batchMatch.fileName
      }"`,
      matchedName: batchMatch.fileName,
    };
  }

  return null;
}

/**
 * Checks for unit number (propertyNo) duplication against existing contracts and batch
 */
export function checkUnitDuplication(
  propertyNo: string | undefined,
  buildingName: string | undefined,
  currentItemId: string,
  allItems: BatchItem[],
  existingContracts: TenancyContract[] = []
): DuplicationAlert | null {
  if (isGenericPlaceholder(propertyNo)) return null;
  const cleanUnit = cleanString(propertyNo);
  const cleanBuilding = cleanString(buildingName);

  if (cleanUnit.length < 1) return null;

  // 1. Check against existing database contracts
  // If building is available, match exact building + unit. If building not available, match unit.
  const dbMatch = existingContracts.find((c) => {
    const existingUnit = cleanString(c.propertyNo);
    const existingBld = cleanString(c.buildingName);
    if (cleanBuilding && existingBld) {
      return existingUnit === cleanUnit && existingBld === cleanBuilding;
    }
    return existingUnit === cleanUnit;
  });

  if (dbMatch) {
    const bldInfo = dbMatch.buildingName ? ` in ${dbMatch.buildingName}` : '';
    return {
      type: 'unit',
      label: 'Unit Number',
      value: propertyNo!.trim(),
      source: 'database',
      details: `Unit "${dbMatch.propertyNo}"${bldInfo} already has an active tenancy contract in database (Tenant: ${
        dbMatch.tenantName || 'Unknown'
      }, Contract #${dbMatch.contractNo || 'N/A'})`,
      matchedName: dbMatch.buildingName || dbMatch.tenantName,
    };
  }

  // 2. Check against other items in the batch
  const batchMatch = allItems.find((item) => {
    if (item.id === currentItemId) return false;
    const otherContract = item.extractedData?.contract;
    if (!otherContract || isGenericPlaceholder(otherContract.propertyNo)) return false;
    const otherUnit = cleanString(otherContract.propertyNo);
    const otherBld = cleanString(otherContract.buildingName);

    if (cleanBuilding && otherBld) {
      return otherUnit === cleanUnit && otherBld === cleanBuilding;
    }
    return otherUnit === cleanUnit;
  });

  if (batchMatch) {
    return {
      type: 'unit',
      label: 'Unit Number',
      value: propertyNo!.trim(),
      source: 'batch',
      details: `Duplicate Unit "${propertyNo!.trim()}" also detected in batch file "${
        batchMatch.fileName
      }"`,
      matchedName: batchMatch.fileName,
    };
  }

  return null;
}

/**
 * Checks for receipt number duplication against existing receipts and batch
 */
export function checkReceiptDuplication(
  receiptNo: string | undefined,
  chequeNo: string | undefined,
  currentItemId: string,
  allItems: BatchItem[],
  existingReceipts: RentalReceipt[] = []
): DuplicationAlert | null {
  if (isGenericPlaceholder(receiptNo)) return null;
  const cleanRcp = cleanString(receiptNo);
  if (cleanRcp.length < 2) return null;

  // 1. Check against existing database receipts
  const dbMatch = existingReceipts.find(
    (r) => cleanString(r.receiptNo) === cleanRcp
  );
  if (dbMatch) {
    return {
      type: 'receipt',
      label: 'Receipt Number',
      value: receiptNo!.trim(),
      source: 'database',
      details: `Receipt #${dbMatch.receiptNo} already exists in database (Bank: ${
        dbMatch.bankName || 'Unknown'
      }, Amount: AED ${dbMatch.amount.toLocaleString()})`,
      matchedName: dbMatch.bankName,
    };
  }

  // 2. Check against other items in the batch
  const batchMatch = allItems.find((item) => {
    if (item.id === currentItemId) return false;
    const otherRcp = item.extractedData?.receipt?.receiptNo;
    return !isGenericPlaceholder(otherRcp) && cleanString(otherRcp) === cleanRcp;
  });

  if (batchMatch) {
    return {
      type: 'receipt',
      label: 'Receipt Number',
      value: receiptNo!.trim(),
      source: 'batch',
      details: `Duplicate Receipt #${receiptNo!.trim()} also found in batch file "${
        batchMatch.fileName
      }"`,
      matchedName: batchMatch.fileName,
    };
  }

  return null;
}

/**
 * Returns all duplication alerts for a single batch item
 */
export function getItemDuplicationAlerts(
  item: BatchItem,
  allItems: BatchItem[],
  existingContracts: TenancyContract[] = [],
  existingReceipts: RentalReceipt[] = [],
  existingInvoices: PurchaseTaxInvoice[] = []
): DuplicationAlert[] {
  const alerts: DuplicationAlert[] = [];

  // Check invoice duplication
  if (item.extractedData?.invoice?.invoiceNumber) {
    const alert = checkInvoiceDuplication(
      item.extractedData.invoice.invoiceNumber,
      item.id,
      allItems,
      existingInvoices
    );
    if (alert) alerts.push(alert);
  }

  // Check unit duplication
  if (item.extractedData?.contract?.propertyNo) {
    const alert = checkUnitDuplication(
      item.extractedData.contract.propertyNo,
      item.extractedData.contract.buildingName,
      item.id,
      allItems,
      existingContracts
    );
    if (alert) alerts.push(alert);
  }

  // Check receipt duplication
  if (item.extractedData?.receipt?.receiptNo) {
    const alert = checkReceiptDuplication(
      item.extractedData.receipt.receiptNo,
      item.extractedData.receipt.chequeNo,
      item.id,
      allItems,
      existingReceipts
    );
    if (alert) alerts.push(alert);
  }

  return alerts;
}

/**
 * Summarizes all duplicates across the entire batch
 */
export function getBatchDuplicationSummary(
  items: BatchItem[],
  existingContracts: TenancyContract[] = [],
  existingReceipts: RentalReceipt[] = [],
  existingInvoices: PurchaseTaxInvoice[] = []
): {
  totalAlerts: number;
  duplicateItems: { item: BatchItem; alerts: DuplicationAlert[] }[];
  byType: {
    invoices: number;
    units: number;
    receipts: number;
  };
} {
  const duplicateItems: { item: BatchItem; alerts: DuplicationAlert[] }[] = [];
  let invoiceCount = 0;
  let unitCount = 0;
  let receiptCount = 0;

  for (const item of items) {
    if (item.status !== 'success' || !item.extractedData) continue;
    const alerts = getItemDuplicationAlerts(
      item,
      items,
      existingContracts,
      existingReceipts,
      existingInvoices
    );
    if (alerts.length > 0) {
      duplicateItems.push({ item, alerts });
      for (const a of alerts) {
        if (a.type === 'invoice') invoiceCount++;
        if (a.type === 'unit') unitCount++;
        if (a.type === 'receipt') receiptCount++;
      }
    }
  }

  return {
    totalAlerts: invoiceCount + unitCount + receiptCount,
    duplicateItems,
    byType: {
      invoices: invoiceCount,
      units: unitCount,
      receipts: receiptCount,
    },
  };
}
