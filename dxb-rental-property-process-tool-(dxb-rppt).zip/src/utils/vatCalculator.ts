import { TenancyContract } from '../types';

export type TenancyContractType = 'Commercial' | 'Residence';

/**
 * Determines whether a contract or property type represents a Commercial tenancy under UAE VAT law.
 */
export function isCommercialContract(
  contractOrType?: { contractType?: string; propertyType?: string } | string | null
): boolean {
  if (!contractOrType) return false;

  let typeStr = '';
  if (typeof contractOrType === 'string') {
    typeStr = contractOrType;
  } else {
    typeStr = contractOrType.contractType || contractOrType.propertyType || '';
  }

  const normalized = typeStr.trim().toLowerCase();
  if (normalized === 'commercial' || normalized.includes('commercial')) {
    return true;
  }
  if (
    normalized.includes('office') ||
    normalized.includes('retail') ||
    normalized.includes('shop') ||
    normalized.includes('warehouse') ||
    normalized.includes('industrial')
  ) {
    return true;
  }
  return false;
}

/**
 * Normalizes the contract type to either 'Commercial' or 'Residence'
 */
export function normalizeContractType(
  contractOrType?: { contractType?: string; propertyType?: string } | string | null
): TenancyContractType {
  return isCommercialContract(contractOrType) ? 'Commercial' : 'Residence';
}

export interface ContractVatBreakdown {
  contractType: TenancyContractType;
  isCommercial: boolean;
  actualAnnualAmount: number;
  vatRate: number; // 5 for Commercial, 0 for Residence
  vatAmount: number; // 5% of actualAnnualAmount if Commercial, 0 if Residence
  totalAmountWithVat: number; // actualAnnualAmount + vatAmount
  statusBadge: string;
  lawDescription: string;
}

/**
 * Computes exact VAT details for a tenancy contract according to UAE VAT law:
 * - Commercial contracts: 5% VAT on the actual annual rent
 * - Residence contracts: 0% VAT (Exempt from VAT under UAE VAT law)
 */
export function calculateContractVat(
  contractOrType?: { contractType?: string; propertyType?: string } | string | null,
  annualRent?: number
): ContractVatBreakdown {
  const isCommercial = isCommercialContract(contractOrType);
  const contractType: TenancyContractType = isCommercial ? 'Commercial' : 'Residence';
  const rent = typeof annualRent === 'number' && !isNaN(annualRent) ? annualRent : 0;

  if (isCommercial) {
    const vatRate = 5;
    const vatAmount = Math.round(rent * 0.05 * 100) / 100;
    const totalAmountWithVat = Math.round((rent + vatAmount) * 100) / 100;
    return {
      contractType: 'Commercial',
      isCommercial: true,
      actualAnnualAmount: rent,
      vatRate,
      vatAmount,
      totalAmountWithVat,
      statusBadge: 'Commercial (5% VAT)',
      lawDescription: 'Standard 5% VAT applicable on commercial lease rent as per UAE VAT Law',
    };
  } else {
    return {
      contractType: 'Residence',
      isCommercial: false,
      actualAnnualAmount: rent,
      vatRate: 0,
      vatAmount: 0,
      totalAmountWithVat: rent,
      statusBadge: 'Residence (0% VAT)',
      lawDescription: 'Exempt from VAT (0% VAT) for residential leases as per UAE VAT Law',
    };
  }
}

/**
 * Aggregates portfolio contracts VAT statistics
 */
export function getContractsVatSummary(contracts: TenancyContract[]) {
  let commercialCount = 0;
  let residenceCount = 0;
  let commercialAnnualRent = 0;
  let residenceAnnualRent = 0;
  let totalContractVat = 0;
  let totalGrossAnnualWithVat = 0;

  for (const c of contracts) {
    const annualRent = c.actualAnnualAmount || c.contractAmount || 0;
    const vat = calculateContractVat(c.contractType || c.propertyType, annualRent);
    if (vat.isCommercial) {
      commercialCount++;
      commercialAnnualRent += annualRent;
      totalContractVat += vat.vatAmount;
      totalGrossAnnualWithVat += vat.totalAmountWithVat;
    } else {
      residenceCount++;
      residenceAnnualRent += annualRent;
      totalGrossAnnualWithVat += annualRent;
    }
  }

  return {
    totalContracts: contracts.length,
    commercialCount,
    residenceCount,
    commercialAnnualRent,
    residenceAnnualRent,
    totalActualAnnualRent: commercialAnnualRent + residenceAnnualRent,
    totalOutputVat: totalContractVat,
    totalGrossAnnualWithVat,
  };
}
