import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { TenancyContract, RentalReceipt, PurchaseTaxInvoice } from '../types';

import { isCommercialContract } from './vatCalculator';

export function formatAED(val: number | undefined | null): string {
  if (val === undefined || val === null || isNaN(val)) return 'AED 0.00';
  return `AED ${val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function exportToExcel(
  contracts: TenancyContract[],
  receipts: RentalReceipt[],
  invoices: PurchaseTaxInvoice[],
  type: 'consolidated' | 'zoho' | 'tally' = 'consolidated'
) {
  const wb = XLSX.utils.book_new();

  const totalContractAmount = contracts.reduce((acc, c) => acc + (c.contractAmount || 0), 0);
  const totalActualAnnual = contracts.reduce((acc, c) => acc + (c.actualAnnualAmount || 0), 0);
  const totalSecurityDeposit = contracts.reduce((acc, c) => acc + (c.securityDeposit || 0), 0);
  const totalReceipts = receipts.reduce((acc, r) => acc + (r.amount || 0), 0);
  const totalMaintenance = invoices.reduce((acc, i) => acc + (i.netAmount || (i.totalInvoiceAmount - (i.taxAmount || 0)) || 0), 0);
  const totalInvoiceAmount = invoices.reduce((acc, i) => acc + (i.totalInvoiceAmount || 0), 0);
  const totalVat = invoices.reduce((acc, i) => acc + (i.taxAmount || 0), 0);

  // UAE VAT Tenancy & Net FTA Payment
  let totalVatOnActualAnnualRent = 0;
  contracts.forEach((c) => {
    const isComm = isCommercialContract(c.contractType || c.propertyType);
    if (isComm) {
      const annualRent = c.actualAnnualAmount || c.contractAmount || 0;
      const vat = c.vatAmount != null ? c.vatAmount : Math.round(annualRent * 0.05 * 100) / 100;
      totalVatOnActualAnnualRent += vat;
    }
  });
  totalVatOnActualAnnualRent = Math.round(totalVatOnActualAnnualRent * 100) / 100;
  const netFtaPayment = Math.round((totalVatOnActualAnnualRent - totalVat) * 100) / 100;

  // 1. Executive Summary Sheet
  const totalNetIncome = totalActualAnnual - totalMaintenance;
  const summaryData = [
    { 'Metric / KPI': 'Report Generated At', 'Value (AED)': new Date().toLocaleString() },
    { 'Metric / KPI': 'Total Tenancy Contracts Processed', 'Value (AED)': contracts.length },
    { 'Metric / KPI': 'Total Contract Rent Amount', 'Value (AED)': totalContractAmount },
    { 'Metric / KPI': 'Total Actual Annual Rent Amount', 'Value (AED)': totalActualAnnual },
    { 'Metric / KPI': 'Total Purchase & Maintenance Expenses (Net)', 'Value (AED)': totalMaintenance },
    { 'Metric / KPI': 'Total Net Income (Actual Annual Rent - Maintenance)', 'Value (AED)': totalNetIncome },
    { 'Metric / KPI': 'Total VAT on Actual Annual Rent (Commercial 5% Output VAT)', 'Value (AED)': totalVatOnActualAnnualRent },
    { 'Metric / KPI': 'Total Recoverable Input VAT on Purchases', 'Value (AED)': totalVat },
    { 'Metric / KPI': 'Net FTA Payment (Output VAT on Rent - Input VAT)', 'Value (AED)': netFtaPayment },
    { 'Metric / KPI': 'Total Security Deposit Held', 'Value (AED)': totalSecurityDeposit },
    { 'Metric / KPI': 'Total Rental Receipts Collected', 'Value (AED)': totalReceipts },
    { 'Metric / KPI': 'Gross Purchase Tax Invoices Amount', 'Value (AED)': totalInvoiceAmount },
    { 'Metric / KPI': 'Net Operating Cash Flow (Receipts - Invoices)', 'Value (AED)': totalReceipts - totalInvoiceAmount },
  ];
  const summarySheet = XLSX.utils.json_to_sheet(summaryData);
  XLSX.utils.book_append_sheet(wb, summarySheet, 'Executive KPI Summary');

  // 2. Tenancy Contracts Sheet
  const contractRows = contracts.map((c, idx) => {
    const isComm = isCommercialContract(c.contractType || c.propertyType);
    const annualRent = c.actualAnnualAmount || c.contractAmount || 0;
    const vatAmount = isComm
      ? (c.vatAmount != null ? c.vatAmount : Math.round(annualRent * 0.05 * 100) / 100)
      : 0;
    return {
      'Sl No': idx + 1,
      'Contract / Ejari No': c.contractNo || 'N/A',
      'Owner Name': c.ownerName || '',
      'Lessor / Management': c.lessorName || '',
      'Tenant Name': c.tenantName || '',
      'Building Name': c.buildingName || '',
      'Property / Unit No': c.propertyNo || '',
      'Contract Classification': isComm ? 'Commercial (5% VAT)' : 'Residence (0% VAT Exempt)',
      'Property Type': c.propertyType || (isComm ? 'Commercial' : 'Residential'),
      'Sub Type': c.subType || (isComm ? 'Office' : 'Apartment'),
      'Size (Area)': c.size || '',
      'Contract Amount (AED)': c.contractAmount || 0,
      'Actual Annual Amount (AED)': annualRent,
      'VAT Rate (%)': isComm ? 5 : 0,
      'VAT on Annual Rent (AED)': vatAmount,
      'Total Annual with VAT (AED)': Math.round((annualRent + vatAmount) * 100) / 100,
      'Security Deposit (AED)': c.securityDeposit || 0,
      'Start Date': c.startDate || '',
      'End Date': c.endDate || '',
      'Registration Date': c.registrationDate || '',
      'File Source': c.fileName || '',
    };
  });
  const contractsSheet = XLSX.utils.json_to_sheet(contractRows.length > 0 ? contractRows : [{ 'Notice': 'No tenancy contracts recorded' }]);
  XLSX.utils.book_append_sheet(wb, contractsSheet, 'Tenancy Contracts');

  // 3. Rental Receipts Sheet
  const receiptRows = receipts.map((r, idx) => ({
    'Sl No': idx + 1,
    'Receipt No': r.receiptNo || 'N/A',
    'Installment Date': r.installmentDate || '',
    'Amount (AED)': r.amount || 0,
    'Cheque / Ref No': r.chequeNo || '',
    'Bank Name': r.bankName || '',
    'Tenant Name': r.tenantName || '',
    'Property Ref': r.propertyRef || '',
    'File Source': r.fileName || '',
  }));
  const receiptsSheet = XLSX.utils.json_to_sheet(receiptRows.length > 0 ? receiptRows : [{ 'Notice': 'No receipts recorded' }]);
  XLSX.utils.book_append_sheet(wb, receiptsSheet, 'Rental Receipts');

  // 4. Purchase Tax Invoices Sheet
  const invoiceRows = invoices.map((i, idx) => ({
    'Sl No': idx + 1,
    'Invoice Number': i.invoiceNumber || '',
    'Invoice Date': i.invoiceDate || '',
    'Supplier / Vendor Name': i.supplierName || '',
    'Supplier TRN (UAE)': i.supplierTrn || 'N/A',
    'Expense Category': i.expenseCategory || 'Maintenance',
    'Net Amount (AED)': i.netAmount || 0,
    'Tax Amount (5% VAT AED)': i.taxAmount || 0,
    'Total Gross Amount (AED)': i.totalInvoiceAmount || 0,
    'Property Ref': i.buildingRef || '',
    'File Source': i.fileName || '',
  }));
  const invoicesSheet = XLSX.utils.json_to_sheet(invoiceRows.length > 0 ? invoiceRows : [{ 'Notice': 'No purchase invoices recorded' }]);
  XLSX.utils.book_append_sheet(wb, invoicesSheet, 'Purchase Tax Invoices');

  // 5. Zoho Books (UAE) Import Format
  const zohoRows = [
    ...invoices.map((i) => ({
      'Entity Type': 'Bill / Vendor Expense',
      'Vendor Name': i.supplierName,
      'Bill Number': i.invoiceNumber,
      'Bill Date': i.invoiceDate,
      'Due Date': i.invoiceDate,
      'Account': i.expenseCategory === 'Maintenance' ? 'Repairs & Maintenance' : `${i.expenseCategory} Expenses`,
      'Item Description': `Maintenance bill for ${i.buildingRef || 'property'}`,
      'Item Price': i.netAmount || (i.totalInvoiceAmount - (i.taxAmount || 0)),
      'Quantity': 1,
      'Discount': 0,
      'Tax Name': 'Standard Rate (5%)',
      'Tax Percentage': 5,
      'Tax Amount': i.taxAmount,
      'Total': i.totalInvoiceAmount,
      'Currency Code': 'AED',
      'Vendor TRN': i.supplierTrn || '',
    })),
    ...contracts.map((c) => ({
      'Entity Type': 'Customer Invoice / Tenancy',
      'Vendor Name': c.tenantName,
      'Bill Number': c.contractNo || `CNT-${c.id.slice(0, 6)}`,
      'Bill Date': c.startDate,
      'Due Date': c.startDate,
      'Account': 'Rental Income',
      'Item Description': `Tenancy Contract ${c.buildingName} Unit ${c.propertyNo}`,
      'Item Price': c.contractAmount,
      'Quantity': 1,
      'Discount': 0,
      'Tax Name': c.propertyType === 'Commercial' ? 'Standard Rate (5%)' : 'Exempt / Zero Rated',
      'Tax Percentage': c.propertyType === 'Commercial' ? 5 : 0,
      'Tax Amount': c.propertyType === 'Commercial' ? c.contractAmount * 0.05 : 0,
      'Total': c.contractAmount,
      'Currency Code': 'AED',
      'Vendor TRN': '',
    })),
  ];
  const zohoSheet = XLSX.utils.json_to_sheet(zohoRows.length > 0 ? zohoRows : [{ 'Notice': 'No records for Zoho Books' }]);
  XLSX.utils.book_append_sheet(wb, zohoSheet, 'Zoho Books UAE Import');

  // 6. Tally Prime (UAE VAT) Import Format
  const tallyRows = [
    ...invoices.map((i) => ({
      'Date': i.invoiceDate,
      'Voucher Type': 'Purchase',
      'Voucher No': i.invoiceNumber,
      'Party Name': i.supplierName,
      'Party TRN': i.supplierTrn || '',
      'Place of Supply': 'Dubai',
      'Ledger Name': `${i.expenseCategory || 'Building Maintenance'} Expense`,
      'Debit (AED)': i.netAmount || (i.totalInvoiceAmount - (i.taxAmount || 0)),
      'Credit (AED)': 0,
      'Tax Ledger': 'Input VAT @ 5%',
      'Tax Rate': '5%',
      'Tax Amount (AED)': i.taxAmount,
      'Total Amount (AED)': i.totalInvoiceAmount,
      'Narration': `Being maintenance expense recorded against invoice ${i.invoiceNumber} for ${i.buildingRef || 'property'}`,
    })),
    ...receipts.map((r) => ({
      'Date': r.installmentDate,
      'Voucher Type': 'Receipt',
      'Voucher No': r.receiptNo || `RCP-${r.id.slice(0, 6)}`,
      'Party Name': r.tenantName || 'Tenant',
      'Party TRN': '',
      'Place of Supply': 'Dubai',
      'Ledger Name': r.bankName || 'Bank Account',
      'Debit (AED)': r.amount,
      'Credit (AED)': 0,
      'Tax Ledger': 'N/A',
      'Tax Rate': '0%',
      'Tax Amount (AED)': 0,
      'Total Amount (AED)': r.amount,
      'Narration': `Rental installment receipt via cheque ${r.chequeNo} at ${r.bankName}`,
    })),
    ...contracts.map((c) => ({
      'Date': c.startDate,
      'Voucher Type': 'Sales',
      'Voucher No': c.contractNo || `TEN-${c.id.slice(0, 6)}`,
      'Party Name': c.tenantName,
      'Party TRN': '',
      'Place of Supply': 'Dubai',
      'Ledger Name': 'Rental Income',
      'Debit (AED)': 0,
      'Credit (AED)': c.contractAmount,
      'Tax Ledger': c.propertyType === 'Commercial' ? 'Output VAT @ 5%' : 'Exempt Lease',
      'Tax Rate': c.propertyType === 'Commercial' ? '5%' : '0%',
      'Tax Amount (AED)': c.propertyType === 'Commercial' ? c.contractAmount * 0.05 : 0,
      'Total Amount (AED)': c.contractAmount,
      'Narration': `Tenancy Contract ${c.contractNo} for Unit ${c.propertyNo}, ${c.buildingName} with annual rent AED ${c.actualAnnualAmount}`,
    })),
  ];
  const tallySheet = XLSX.utils.json_to_sheet(tallyRows.length > 0 ? tallyRows : [{ 'Notice': 'No records for Tally Prime' }]);
  XLSX.utils.book_append_sheet(wb, tallySheet, 'Tally Prime UAE VAT');

  const fileName = `DXB_RPPT_Export_${type.toUpperCase()}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

export function exportToCSV(data: any[], filename: string) {
  if (!data || data.length === 0) {
    alert('No data available to export.');
    return;
  }
  const headers = Object.keys(data[0]);
  const csvRows = [
    headers.join(','),
    ...data.map((row) =>
      headers
        .map((header) => {
          const val = row[header] ?? '';
          const escaped = String(val).replace(/"/g, '""');
          return `"${escaped}"`;
        })
        .join(',')
    ),
  ];
  const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function exportToPDF(
  contracts: TenancyContract[],
  receipts: RentalReceipt[],
  invoices: PurchaseTaxInvoice[],
  userName?: string
) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });
  const now = new Date().toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  const totalContractAmount = contracts.reduce((acc, c) => acc + (c.contractAmount || 0), 0);
  const totalActualAnnual = contracts.reduce((acc, c) => acc + (c.actualAnnualAmount || 0), 0);
  const totalSecurityDeposit = contracts.reduce((acc, c) => acc + (c.securityDeposit || 0), 0);
  const totalReceipts = receipts.reduce((acc, r) => acc + (r.amount || 0), 0);
  const totalMaintenance = invoices.reduce((acc, i) => acc + (i.netAmount || 0), 0);
  const totalVat = invoices.reduce((acc, i) => acc + (i.taxAmount || 0), 0);
  const totalInvoicesGross = invoices.reduce((acc, i) => acc + (i.totalInvoiceAmount || 0), 0);

  // Apple-like Executive Header
  doc.setFillColor(11, 25, 44); // Deep Navy #0B192C
  doc.rect(0, 0, 297, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('DXB RENTAL PROPERTY PROCESS TOOL (DXB-RPPT)', 14, 11);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Official UAE Property & VAT Tax Audit Summary  |  Date: ${now}  |  Operator: ${userName || 'System User'}`, 14, 18);

  // KPI Highlights Box
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(14, 28, 269, 20, 2, 2, 'F');

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');

  const totalNetIncome = totalActualAnnual - totalMaintenance;
  const colWidth = 269 / 7;
  const kpiItems = [
    { label: 'CONTRACT VALUE', val: formatAED(totalContractAmount) },
    { label: 'ANNUAL RENT', val: formatAED(totalActualAnnual) },
    { label: 'MAINTENANCE EXP', val: formatAED(totalMaintenance) },
    { label: 'TOTAL NET INCOME', val: formatAED(totalNetIncome) },
    { label: 'SECURITY DEPOSIT', val: formatAED(totalSecurityDeposit) },
    { label: 'RENT RECEIPTS', val: formatAED(totalReceipts) },
    { label: 'INPUT VAT (5%)', val: formatAED(totalVat) },
  ];

  kpiItems.forEach((kpi, idx) => {
    const x = 14 + idx * colWidth + 4;
    doc.setTextColor(100, 116, 139);
    doc.setFontSize(7);
    doc.setFont('helvetica', 'bold');
    doc.text(kpi.label, x, 35);

    doc.setTextColor(15, 23, 42);
    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'bold');
    doc.text(kpi.val, x, 42);
  });

  let currentY = 54;

  // Contracts Table
  if (contracts.length > 0) {
    doc.setTextColor(15, 23, 42);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('1. UAE Tenancy Contracts (Ejari Records)', 14, currentY);

    autoTable(doc, {
      startY: currentY + 3,
      head: [
        [
          'Contract #',
          'Owner Name',
          'Building / Unit',
          'Tenant Name',
          'Type',
          'Contract Amt (AED)',
          'Actual Annual (AED)',
          'Deposit (AED)',
          'Period',
        ],
      ],
      body: contracts.map((c) => [
        c.contractNo || 'N/A',
        c.ownerName || '',
        `${c.buildingName || ''} ${c.propertyNo ? `[${c.propertyNo}]` : ''}`,
        c.tenantName || '',
        `${c.propertyType || ''} - ${c.subType || ''}`,
        (c.contractAmount || 0).toLocaleString(),
        (c.actualAnnualAmount || 0).toLocaleString(),
        (c.securityDeposit || 0).toLocaleString(),
        `${c.startDate || ''} to ${c.endDate || ''}`,
      ]),
      theme: 'grid',
      headStyles: { fillColor: [0, 102, 204], textColor: 255, fontSize: 7.5 },
      bodyStyles: { fontSize: 7, textColor: [30, 41, 59] },
      styles: { cellPadding: 1.8 },
      margin: { left: 14, right: 14 },
    });
    // @ts-ignore
    currentY = doc.lastAutoTable.finalY + 10;
  }

  // If table went too low, add page
  if (currentY > 150) {
    doc.addPage();
    currentY = 20;
  }

  // Receipts Table
  if (receipts.length > 0) {
    doc.setTextColor(15, 23, 42);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('2. Rental Payment Receipts & Cheques', 14, currentY);

    autoTable(doc, {
      startY: currentY + 3,
      head: [['Receipt #', 'Installment Date', 'Amount (AED)', 'Cheque #', 'Bank Name', 'Tenant', 'Property']],
      body: receipts.map((r) => [
        r.receiptNo || 'N/A',
        r.installmentDate || '',
        (r.amount || 0).toLocaleString(),
        r.chequeNo || '',
        r.bankName || '',
        r.tenantName || '',
        r.propertyRef || '',
      ]),
      theme: 'grid',
      headStyles: { fillColor: [14, 116, 144], textColor: 255, fontSize: 7.5 },
      bodyStyles: { fontSize: 7, textColor: [30, 41, 59] },
      styles: { cellPadding: 1.8 },
      margin: { left: 14, right: 14 },
    });
    // @ts-ignore
    currentY = doc.lastAutoTable.finalY + 10;
  }

  if (currentY > 150) {
    doc.addPage();
    currentY = 20;
  }

  // Invoices Table
  if (invoices.length > 0) {
    doc.setTextColor(15, 23, 42);
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.text('3. Purchase Tax Invoices (UAE 5% VAT Deductible)', 14, currentY);

    autoTable(doc, {
      startY: currentY + 3,
      head: [
        [
          'Invoice #',
          'Date',
          'Supplier Name',
          'UAE TRN',
          'Expense Category',
          'Net (AED)',
          'VAT 5% (AED)',
          'Total Gross (AED)',
        ],
      ],
      body: invoices.map((i) => [
        i.invoiceNumber || '',
        i.invoiceDate || '',
        i.supplierName || '',
        i.supplierTrn || 'N/A',
        i.expenseCategory || 'Maintenance',
        (i.netAmount || 0).toLocaleString(),
        (i.taxAmount || 0).toLocaleString(),
        (i.totalInvoiceAmount || 0).toLocaleString(),
      ]),
      theme: 'grid',
      headStyles: { fillColor: [79, 70, 229], textColor: 255, fontSize: 7.5 },
      bodyStyles: { fontSize: 7, textColor: [30, 41, 59] },
      styles: { cellPadding: 1.8 },
      margin: { left: 14, right: 14 },
    });
  }

  doc.save(`DXB_RPPT_Official_Report_${new Date().toISOString().slice(0, 10)}.pdf`);
}

/**
 * Exports formal Bank Reconciliation Statement and transactions to Excel
 */
export function exportBankReconciliationToExcel(
  statement: any,
  transactions: any[],
  summary: any,
  receipts: RentalReceipt[],
  invoices: PurchaseTaxInvoice[]
) {
  const wb = XLSX.utils.book_new();

  // 1. Formal Bank Reconciliation Statement (BRS) Sheet
  const brsData = [
    { 'Reconciliation Item': 'Company / Portfolio', 'Amount (AED)': statement?.accountTitle || 'DXB Real Estate Portfolio' },
    { 'Reconciliation Item': 'Bank Name', 'Amount (AED)': statement?.bankName || 'UAE Commercial Bank' },
    { 'Reconciliation Item': 'Bank Account / IBAN', 'Amount (AED)': statement?.accountNumber || 'N/A' },
    { 'Reconciliation Item': 'Statement Period', 'Amount (AED)': `${statement?.statementPeriodStart || ''} to ${statement?.statementPeriodEnd || ''}` },
    { 'Reconciliation Item': 'Report Date', 'Amount (AED)': new Date().toLocaleDateString() },
    { 'Reconciliation Item': '----------------------------------------', 'Amount (AED)': '----------------------' },
    { 'Reconciliation Item': '1. BALANCE AS PER BANK STATEMENT (Closing)', 'Amount (AED)': summary.statementClosingBalance },
    { 'Reconciliation Item': 'ADD: Deposits in Transit (Rent Receipts not yet in Bank)', 'Amount (AED)': summary.depositsInTransit },
    { 'Reconciliation Item': 'LESS: Outstanding Cheques / Payments (Uncleared Invoices)', 'Amount (AED)': -summary.unclearedDebits },
    { 'Reconciliation Item': '= ADJUSTED BANK BALANCE', 'Amount (AED)': summary.adjustedBankBalance },
    { 'Reconciliation Item': '----------------------------------------', 'Amount (AED)': '----------------------' },
    { 'Reconciliation Item': '2. BALANCE AS PER BOOKS (General Ledger)', 'Amount (AED)': summary.bookBalance },
    { 'Reconciliation Item': 'ADD: Unrecorded Bank Credits (Direct Deposits)', 'Amount (AED)': summary.unrecordedBankCredits },
    { 'Reconciliation Item': 'LESS: Unrecorded Bank Debits (Direct Debits / Bank Charges)', 'Amount (AED)': -summary.unrecordedBankDebits },
    { 'Reconciliation Item': '= ADJUSTED BOOK BALANCE', 'Amount (AED)': summary.adjustedBookBalance },
    { 'Reconciliation Item': '----------------------------------------', 'Amount (AED)': '----------------------' },
    { 'Reconciliation Item': 'NET RECONCILIATION VARIANCE (Adjusted Bank - Adjusted Book)', 'Amount (AED)': summary.variance },
    { 'Reconciliation Item': 'RECONCILIATION AUDIT STATUS', 'Amount (AED)': summary.isBalanced ? 'BALANCED (AED 0.00)' : 'UNRECONCILED VARIANCE' },
  ];
  const brsSheet = XLSX.utils.json_to_sheet(brsData);
  XLSX.utils.book_append_sheet(wb, brsSheet, 'Reconciliation Statement');

  // 2. Bank Transactions Ledger
  const txRows = transactions.map((tx) => ({
    'Tx Date': tx.date,
    'Type': tx.type.toUpperCase(),
    'Debit (AED)': tx.type === 'debit' ? tx.amount : '',
    'Credit (AED)': tx.type === 'credit' ? tx.amount : '',
    'Balance (AED)': tx.balance || '',
    'Reference / Cheque #': tx.referenceNo || tx.chequeNo || '',
    'Description / Particulars': tx.description,
    'Recon Status': tx.reconciliationStatus.toUpperCase(),
    'Matched Entity': tx.matchedEntityType || (tx.otherPaymentCategory ? 'OTHER_PAYMENT' : 'NONE'),
    'Matched Doc #': tx.matchedEntityRef || '',
    'Matched Party': tx.matchedEntityName || tx.otherPaymentCategory || '',
    'Difference (AED)': tx.differenceAmount || 0,
    'Notes / Classification': tx.notes || '',
  }));
  const txSheet = XLSX.utils.json_to_sheet(txRows);
  XLSX.utils.book_append_sheet(wb, txSheet, 'Bank Transactions Ledger');

  // 3. Uncleared Deposits in Transit (Rent Receipts)
  const matchedReceiptIds = new Set(transactions.filter(t => t.type === 'credit' && t.matchedEntityId).map(t => t.matchedEntityId));
  const unclearedReceipts = receipts.filter(r => !matchedReceiptIds.has(r.id)).map(r => ({
    'Receipt Voucher #': r.receiptNo,
    'Date': r.installmentDate,
    'Amount (AED)': r.amount,
    'Cheque #': r.chequeNo,
    'Tenant Name': r.tenantName,
    'Bank': r.bankName,
    'Property Reference': r.propertyRef || '',
    'Status': 'Outstanding Deposit in Transit',
  }));
  const unclearedRecSheet = XLSX.utils.json_to_sheet(unclearedReceipts.length > 0 ? unclearedReceipts : [{ 'Info': 'All rental receipts are reconciled!' }]);
  XLSX.utils.book_append_sheet(wb, unclearedRecSheet, 'Uncleared Rent Receipts');

  // 4. Uncleared Maintenance Payments (Invoices)
  const matchedInvoiceIds = new Set(transactions.filter(t => t.type === 'debit' && t.matchedEntityId).map(t => t.matchedEntityId));
  const unclearedInvoices = invoices.filter(i => !matchedInvoiceIds.has(i.id)).map(i => ({
    'Invoice #': i.invoiceNumber,
    'Invoice Date': i.invoiceDate,
    'Supplier / Vendor': i.supplierName,
    'Expense Category': i.expenseCategory,
    'Gross Amount (AED)': i.totalInvoiceAmount,
    'VAT 5% (AED)': i.taxAmount,
    'Building Reference': i.buildingRef || '',
    'Status': 'Unpresented Cheque / Uncleared Payment',
  }));
  const unclearedInvSheet = XLSX.utils.json_to_sheet(unclearedInvoices.length > 0 ? unclearedInvoices : [{ 'Info': 'All maintenance invoices are reconciled!' }]);
  XLSX.utils.book_append_sheet(wb, unclearedInvSheet, 'Uncleared Maintenance Invoices');

  XLSX.writeFile(wb, `DXB_RPPT_Bank_Reconciliation_${statement?.bankName?.replace(/\s+/g, '_') || 'Statement'}_${new Date().toISOString().slice(0, 10)}.xlsx`);
}

/**
 * Exports formal Bank Reconciliation Statement to PDF
 */
export function exportBankReconciliationToPDF(
  statement: any,
  transactions: any[],
  summary: any
) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });

  // Header banner
  doc.setFillColor(10, 37, 64);
  doc.rect(0, 0, 210, 32, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(16);
  doc.setFont('helvetica', 'bold');
  doc.text('BANK RECONCILIATION STATEMENT', 14, 14);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.text(`Bank: ${statement?.bankName || 'UAE Commercial Bank'} | Account: ${statement?.accountNumber || 'N/A'}`, 14, 21);
  doc.text(`Period: ${statement?.statementPeriodStart || ''} to ${statement?.statementPeriodEnd || ''} | Generated: ${new Date().toLocaleDateString()}`, 14, 27);

  // Status Badge in header
  if (summary.isBalanced) {
    doc.setFillColor(16, 185, 129);
    doc.roundedRect(148, 10, 48, 12, 2, 2, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'bold');
    doc.text('STATUS: BALANCED', 152, 17.5);
  } else {
    doc.setFillColor(245, 158, 11);
    doc.roundedRect(144, 10, 52, 12, 2, 2, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(8.5);
    doc.setFont('helvetica', 'bold');
    doc.text('STATUS: VARIANCE', 148, 17.5);
  }

  // Formal BRS Table
  autoTable(doc, {
    startY: 38,
    head: [['Line', 'Bank Reconciliation Item', 'Subtotal (AED)', 'Total (AED)']],
    body: [
      ['1', 'Balance as per Bank Statement (Closing)', '', formatAED(summary.statementClosingBalance)],
      ['2', 'ADD: Deposits in Transit (Rent Receipts recorded in books, not in bank)', formatAED(summary.depositsInTransit), ''],
      ['3', 'LESS: Outstanding Cheques / Payments (Maintenance Invoices recorded in books, not in bank)', `(${formatAED(summary.unclearedDebits)})`, ''],
      ['4', '= ADJUSTED BANK BALANCE', '', formatAED(summary.adjustedBankBalance)],
      ['', '--------------------------------------------------------------------------------', '', ''],
      ['5', 'Balance as per General Ledger / Books (Receipts - Invoices)', '', formatAED(summary.bookBalance)],
      ['6', 'ADD: Unrecorded Bank Credits (Direct rental credits / interest)', formatAED(summary.unrecordedBankCredits), ''],
      ['7', 'LESS: Unrecorded Bank Debits (Direct debits, utility bills, bank charges)', `(${formatAED(summary.unrecordedBankDebits)})`, ''],
      ['8', '= ADJUSTED BOOK BALANCE', '', formatAED(summary.adjustedBookBalance)],
      ['', '--------------------------------------------------------------------------------', '', ''],
      ['9', 'NET RECONCILIATION VARIANCE (Adjusted Bank - Adjusted Book)', '', formatAED(summary.variance)],
    ],
    theme: 'grid',
    headStyles: { fillColor: [15, 23, 42], textColor: 255, fontSize: 8 },
    bodyStyles: { fontSize: 8, textColor: [30, 41, 59] },
    styles: { cellPadding: 2.2 },
    margin: { left: 14, right: 14 },
  });

  // @ts-ignore
  let nextY = doc.lastAutoTable.finalY + 8;

  // Sign-off Block
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('Accounting Sign-off & Audit Certification', 14, nextY);

  nextY += 4;
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text('I hereby certify that the bank reconciliation statement above has been reviewed and reconciled in accordance with UAE VAT and accounting standards.', 14, nextY);

  nextY += 10;
  doc.setDrawColor(203, 213, 225);
  doc.line(14, nextY + 12, 70, nextY + 12);
  doc.line(80, nextY + 12, 136, nextY + 12);
  doc.line(146, nextY + 12, 196, nextY + 12);

  doc.setFontSize(7.5);
  doc.text('Prepared by (Accountant)', 14, nextY + 16);
  doc.text('Reviewed by (Finance Manager)', 80, nextY + 16);
  doc.text('Approved by (Director / Auditor)', 146, nextY + 16);

  doc.save(`DXB_RPPT_Bank_Reconciliation_Statement_${new Date().toISOString().slice(0, 10)}.pdf`);
}

