import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  getDoc,
  getDocs,
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestoreErrors';
import { TenancyContract, RentalReceipt, PurchaseTaxInvoice, UserProfile, UserRole, BankStatement, BankTransaction } from '../types';

export async function getUserProfile(userId: string): Promise<UserProfile | null> {
  const path = `user_profiles/${userId}`;
  try {
    const snap = await getDoc(doc(db, 'user_profiles', userId));
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function upsertUserProfile(profile: UserProfile): Promise<void> {
  const path = `user_profiles/${profile.userId}`;
  try {
    await setDoc(doc(db, 'user_profiles', profile.userId), {
      ...profile,
      updatedAt: new Date().toISOString(),
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function getAllUserProfiles(): Promise<UserProfile[]> {
  const path = 'user_profiles';
  try {
    const snap = await getDocs(collection(db, 'user_profiles'));
    return snap.docs.map(d => d.data() as UserProfile);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function updateUserRole(userId: string, role: UserRole): Promise<void> {
  const path = `user_profiles/${userId}`;
  try {
    await updateDoc(doc(db, 'user_profiles', userId), {
      role,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// Tenancy Contracts
export function subscribeContracts(
  userId: string,
  isAdmin: boolean,
  callback: (contracts: TenancyContract[]) => void
) {
  const path = 'contracts';
  const colRef = collection(db, 'contracts');
  const q = isAdmin ? colRef : query(colRef, where('userId', '==', userId));

  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...docSnap.data(),
      })) as TenancyContract[];
      callback(items);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function saveContract(contract: TenancyContract): Promise<void> {
  const path = `contracts/${contract.id}`;
  try {
    await setDoc(doc(db, 'contracts', contract.id), contract);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateContract(id: string, data: Partial<TenancyContract>): Promise<void> {
  const path = `contracts/${id}`;
  try {
    await updateDoc(doc(db, 'contracts', id), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteContract(id: string): Promise<void> {
  const path = `contracts/${id}`;
  try {
    await deleteDoc(doc(db, 'contracts', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Rental Receipts
export function subscribeReceipts(
  userId: string,
  isAdmin: boolean,
  callback: (receipts: RentalReceipt[]) => void
) {
  const path = 'receipts';
  const colRef = collection(db, 'receipts');
  const q = isAdmin ? colRef : query(colRef, where('userId', '==', userId));

  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...docSnap.data(),
      })) as RentalReceipt[];
      callback(items);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function saveReceipt(receipt: RentalReceipt): Promise<void> {
  const path = `receipts/${receipt.id}`;
  try {
    await setDoc(doc(db, 'receipts', receipt.id), receipt);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateReceipt(id: string, data: Partial<RentalReceipt>): Promise<void> {
  const path = `receipts/${id}`;
  try {
    await updateDoc(doc(db, 'receipts', id), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteReceipt(id: string): Promise<void> {
  const path = `receipts/${id}`;
  try {
    await deleteDoc(doc(db, 'receipts', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Purchase Tax Invoices
export function subscribeInvoices(
  userId: string,
  isAdmin: boolean,
  callback: (invoices: PurchaseTaxInvoice[]) => void
) {
  const path = 'invoices';
  const colRef = collection(db, 'invoices');
  const q = isAdmin ? colRef : query(colRef, where('userId', '==', userId));

  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...docSnap.data(),
      })) as PurchaseTaxInvoice[];
      callback(items);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function saveInvoice(invoice: PurchaseTaxInvoice): Promise<void> {
  const path = `invoices/${invoice.id}`;
  try {
    await setDoc(doc(db, 'invoices', invoice.id), invoice);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateInvoice(id: string, data: Partial<PurchaseTaxInvoice>): Promise<void> {
  const path = `invoices/${id}`;
  try {
    await updateDoc(doc(db, 'invoices', id), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteInvoice(id: string): Promise<void> {
  const path = `invoices/${id}`;
  try {
    await deleteDoc(doc(db, 'invoices', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Bank Statements
export function subscribeBankStatements(
  userId: string,
  isAdmin: boolean,
  callback: (statements: BankStatement[]) => void
) {
  const path = 'bank_statements';
  const colRef = collection(db, 'bank_statements');
  const q = isAdmin ? colRef : query(colRef, where('userId', '==', userId));

  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...docSnap.data(),
      })) as BankStatement[];
      callback(items);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function saveBankStatement(statement: BankStatement): Promise<void> {
  const path = `bank_statements/${statement.id}`;
  try {
    await setDoc(doc(db, 'bank_statements', statement.id), statement);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function updateBankStatement(id: string, data: Partial<BankStatement>): Promise<void> {
  const path = `bank_statements/${id}`;
  try {
    await updateDoc(doc(db, 'bank_statements', id), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteBankStatement(id: string): Promise<void> {
  const path = `bank_statements/${id}`;
  try {
    await deleteDoc(doc(db, 'bank_statements', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Bank Transactions
export function subscribeBankTransactions(
  userId: string,
  isAdmin: boolean,
  callback: (transactions: BankTransaction[]) => void,
  statementId?: string
) {
  const path = 'bank_transactions';
  const colRef = collection(db, 'bank_transactions');
  let q = isAdmin ? colRef : query(colRef, where('userId', '==', userId));
  if (statementId) {
    q = query(q, where('statementId', '==', statementId));
  }

  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...docSnap.data(),
      })) as BankTransaction[];
      callback(items);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    }
  );
}

export async function saveBankTransaction(transaction: BankTransaction): Promise<void> {
  const path = `bank_transactions/${transaction.id}`;
  try {
    await setDoc(doc(db, 'bank_transactions', transaction.id), transaction);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function saveBankTransactionsBatch(transactions: BankTransaction[]): Promise<void> {
  for (const tx of transactions) {
    const path = `bank_transactions/${tx.id}`;
    try {
      await setDoc(doc(db, 'bank_transactions', tx.id), tx);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }
}

export async function updateBankTransaction(id: string, data: Partial<BankTransaction>): Promise<void> {
  const path = `bank_transactions/${id}`;
  try {
    await updateDoc(doc(db, 'bank_transactions', id), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteBankTransaction(id: string): Promise<void> {
  const path = `bank_transactions/${id}`;
  try {
    await deleteDoc(doc(db, 'bank_transactions', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

