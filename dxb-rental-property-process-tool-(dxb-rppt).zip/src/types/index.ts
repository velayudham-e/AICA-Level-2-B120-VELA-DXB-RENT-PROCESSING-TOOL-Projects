export type UserRole = 'admin' | 'manager' | 'accountant' | 'viewer';

export interface UserProfile {
  userId: string;
  email: string;
  displayName: string;
  role: UserRole;
  createdAt?: string;
  updatedAt?: string;
}

export interface TenancyContract {
  id: string;
  userId: string;
  contractNo: string;
  ownerName: string;
  lessorName: string;
  tenantName: string;
  buildingName: string;
  propertyNo: string;
  contractType?: 'Commercial' | 'Residence'; // Commercial (5% VAT) or Residence (0% VAT) as per UAE VAT Law
  propertyType: string; // Residential, Commercial, Industrial
  subType: string; // Apartment, Villa, Office, Warehouse, Retail
  size: string; // e.g. "1,250 Sq.Ft"
  contractAmount: number; // AED
  actualAnnualAmount: number; // AED
  vatRate?: number; // 5% for Commercial, 0% for Residence
  vatAmount?: number; // 5% on actual annual rent if Commercial, 0 if Residence (AED)
  totalAmountWithVat?: number; // actualAnnualAmount + vatAmount (AED)
  securityDeposit: number; // AED
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  registrationDate: string; // YYYY-MM-DD
  fileName?: string;
  fileUrl?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface RentalReceipt {
  id: string;
  userId: string;
  receiptNo: string;
  installmentDate: string; // YYYY-MM-DD
  amount: number; // AED
  chequeNo: string;
  bankName: string;
  tenantName?: string;
  propertyRef?: string;
  fileName?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PurchaseTaxInvoice {
  id: string;
  userId: string;
  invoiceNumber: string;
  invoiceDate: string; // YYYY-MM-DD
  supplierName: string;
  supplierTrn?: string; // UAE 15-digit TRN
  expenseCategory: string; // Maintenance, HVAC, Plumbing, Electrical, Cleaning, etc.
  netAmount: number; // AED (before VAT)
  taxAmount: number; // AED (5% VAT)
  totalInvoiceAmount: number; // AED (Gross amount)
  buildingRef?: string;
  fileName?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BankStatement {
  id: string;
  userId: string;
  bankName: string; // e.g. Emirates NBD, ADCB, Dubai Islamic Bank, Mashreq, FAB, etc.
  accountNumber: string;
  accountTitle?: string;
  statementPeriodStart: string; // YYYY-MM-DD
  statementPeriodEnd: string; // YYYY-MM-DD
  openingBalance: number; // AED
  closingBalance: number; // AED
  currency: string; // AED
  fileName?: string;
  totalDebits: number; // Sum of withdrawals / payments (AED)
  totalCredits: number; // Sum of deposits / receipts (AED)
  transactionsCount: number;
  reconciledCount: number;
  unreconciledCount: number;
  status: 'draft' | 'in_progress' | 'reconciled';
  createdAt: string;
  updatedAt: string;
}

export type BankTransactionType = 'debit' | 'credit';
export type ReconciliationStatus = 'unreconciled' | 'matched' | 'suggested' | 'manual_other';
export type MatchedEntityType = 'invoice' | 'receipt' | 'other_payment';

export type OtherPaymentCategory =
  | 'Maintenance & Repairs'
  | 'DEWA / Electricity & Water'
  | 'Chiller & Air Conditioning'
  | 'Govt & Municipal / Ejari Fees'
  | 'Bank Charges & Commission'
  | 'VAT / FTA Tax Settlement'
  | 'Mortgage / Loan Installment'
  | 'Security Deposit Refund'
  | 'General Property Expense'
  | 'Owner Drawing / Dividend'
  | 'Other';

export interface BankTransaction {
  id: string;
  statementId: string;
  userId: string;
  date: string; // YYYY-MM-DD
  valueDate?: string;
  description: string; // Bank narrative / particulars
  referenceNo?: string; // Cheque number, wire ref, or transaction ID
  chequeNo?: string;
  type: BankTransactionType; // 'debit' (money out / maintenance) or 'credit' (money in / rent receipts)
  amount: number; // AED (positive number)
  balance?: number; // Running balance AED
  reconciliationStatus: ReconciliationStatus;
  matchedEntityType?: MatchedEntityType;
  matchedEntityId?: string; // PurchaseTaxInvoice ID or RentalReceipt ID
  matchedEntityRef?: string; // Invoice number or Receipt voucher number
  matchedEntityName?: string; // Supplier name or Tenant name
  matchedAmount?: number; // AED
  differenceAmount?: number; // Difference if any (e.g. bank fee)
  otherPaymentCategory?: OtherPaymentCategory;
  notes?: string;
  reconciledAt?: string;
  reconciledBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BankReconciliationSummary {
  statementClosingBalance: number;
  depositsInTransit: number; // Rent receipts recorded in books but not yet credited in bank
  unclearedDebits: number; // Maintenance invoices/payments recorded in books but not yet debited in bank
  adjustedBankBalance: number;
  bookBalance: number; // Total Receipts - Total Invoices/Payments
  unrecordedBankCredits: number; // Bank credits not matched to any rent receipt
  unrecordedBankDebits: number; // Bank debits not matched to any invoice or categorized
  adjustedBookBalance: number;
  variance: number; // adjustedBankBalance - adjustedBookBalance (0 = balanced)
  isBalanced: boolean;
  totalDebits: number;
  totalCredits: number;
  reconciledDebitsAmount: number;
  reconciledCreditsAmount: number;
  pendingDebitsCount: number;
  pendingCreditsCount: number;
}

export interface BatchItem {
  id: string;
  file: File;
  fileName: string;
  fileSize: number;
  mimeType: string;
  status: 'pending' | 'uploading' | 'processing' | 'success' | 'error';
  targetType: 'auto' | 'contract' | 'receipt' | 'invoice' | 'bank_statement';
  detectedType?: 'contract' | 'receipt' | 'invoice' | 'bank_statement';
  progress: number;
  extractedData?: {
    contract?: Partial<TenancyContract>;
    receipt?: Partial<RentalReceipt>;
    invoice?: Partial<PurchaseTaxInvoice>;
    bankStatement?: Partial<BankStatement>;
    bankTransactions?: Partial<BankTransaction>[];
    summaryNotes?: string;
  };
  errorMessage?: string;
}

export type ActiveTab =
  | 'dashboard'
  | 'upload'
  | 'contracts'
  | 'receipts'
  | 'invoices'
  | 'bank-reconciliation'
  | 'reports'
  | 'roles';

