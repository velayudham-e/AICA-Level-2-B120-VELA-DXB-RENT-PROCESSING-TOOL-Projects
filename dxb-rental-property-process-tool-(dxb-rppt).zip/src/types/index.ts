export type UserRole = 'admin' | 'manager' | 'accountant' | 'viewer';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  createdAt: string;
  photoURL?: string;
}

export interface TenancyContract {
  id: string;
  ownerName: string;
  buildingName: string;
  propertyNo: string;
  type: 'Residential' | 'Commercial' | 'Industrial' | string;
  subType: 'Apartment' | 'Villa' | 'Office' | 'Retail' | 'Warehouse' | string;
  size: number; // in sq ft
  tenantName: string;
  contractAmount: number; // AED
  actualAnnualAmount: number; // AED
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  securityDeposit: number; // AED
  lessorName: string;
  registrationDate: string; // Ejari registration date
  vatRate: number; // 0 for residential, 5 for commercial
  vatAmount: number; // AED
  createdBy: string;
  createdAt: string;
  fileName?: string;
}

export interface Receipt {
  id: string;
  propertyNo: string;
  contractId?: string;
  installmentDate: string; // YYYY-MM-DD
  amount: number; // AED
  chequeNo: string;
  bankName: string;
  tenantName: string;
  status: 'Pending' | 'Deposited' | 'Cleared' | 'Bounced';
  matchedBankTxId?: string;
  createdBy: string;
  createdAt: string;
  fileName?: string;
}

export interface PurchaseInvoice {
  id: string;
  invoiceNumber: string;
  invoiceDate: string; // YYYY-MM-DD
  supplierName: string;
  supplierTRN?: string;
  propertyNo: string;
  buildingName: string;
  description: string;
  totalInvoiceAmount: number; // AED (incl. VAT)
  netAmount: number; // AED (excl. VAT)
  taxAmount: number; // AED (5% VAT)
  matchedBankTxId?: string;
  createdBy: string;
  createdAt: string;
  fileName?: string;
}

export interface BankStatement {
  id: string;
  accountNumber?: string;
  bankName: string;
  statementPeriod?: string;
  transactionDate: string; // YYYY-MM-DD
  transactionName: string;
  chequeNumber?: string;
  debitAmount: number; // AED (payments / expenses)
  creditAmount: number; // AED (receipts / deposits)
  netBalance: number; // AED
  reconciliationStatus: 'Unmatched' | 'Matched' | 'Ignored';
  matchedType?: 'Receipt' | 'PurchaseInvoice' | 'None';
  matchedRefId?: string;
  createdBy: string;
  createdAt: string;
}

export interface DashboardMetrics {
  totalContractAmount: number;
  totalActualAnnualAmount: number;
  totalSecurityDeposit: number;
  totalReceipts: number;
  totalPurchaseMaintenanceExp: number;
  totalVATOnPurchaseInvoice: number;
  netRentIncome: number; // actualAnnualAmount - purchaseMaintenanceExp
  totalVATOnActualRent: number;
  netVAT: number; // totalVATOnActual - totalVATOnPurchase
  monthlyTrends: {
    month: string;
    contractAmount: number;
    actualAnnualAmount: number;
    receipts: number;
    expenses: number;
  }[];
}

export interface FilterState {
  propertyFilter: string; // 'ALL' or specific propertyNo
  periodFilter: 'ALL' | 'THIS_MONTH' | 'LAST_MONTH' | 'THIS_QUARTER' | 'THIS_YEAR' | 'CUSTOM';
  startDate?: string;
  endDate?: string;
  searchTerm: string;
}

export type ActiveTab =
  | 'dashboard'
  | 'upload'
  | 'contracts'
  | 'receipts'
  | 'invoices'
  | 'bank-statements'
  | 'reconciliation'
  | 'reports'
  | 'export'
  | 'users';
