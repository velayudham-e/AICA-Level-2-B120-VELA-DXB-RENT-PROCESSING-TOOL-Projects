import { GoogleGenAI, Type, Schema } from '@google/genai';
import dotenv from 'dotenv';
dotenv.config();

const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI(apiKey ? { apiKey } : {});

export interface ExtractedContract {
  contractNo?: string;
  ownerName?: string;
  lessorName?: string;
  tenantName?: string;
  buildingName?: string;
  propertyNo?: string;
  contractType?: 'Commercial' | 'Residence';
  propertyType?: string;
  subType?: string;
  size?: string;
  contractAmount?: number;
  actualAnnualAmount?: number;
  vatRate?: number;
  vatAmount?: number;
  totalAmountWithVat?: number;
  securityDeposit?: number;
  startDate?: string;
  endDate?: string;
  registrationDate?: string;
}

export interface ExtractedReceipt {
  receiptNo?: string;
  installmentDate?: string;
  amount?: number;
  chequeNo?: string;
  bankName?: string;
  tenantName?: string;
  propertyRef?: string;
}

export interface ExtractedInvoice {
  invoiceNumber?: string;
  invoiceDate?: string;
  supplierName?: string;
  supplierTrn?: string;
  expenseCategory?: string;
  netAmount?: number;
  taxAmount?: number;
  totalInvoiceAmount?: number;
  buildingRef?: string;
}

export interface ExtractionResult {
  detectedType: 'contract' | 'receipt' | 'invoice';
  confidence: number;
  contract?: ExtractedContract;
  receipt?: ExtractedReceipt;
  invoice?: ExtractedInvoice;
  summaryNotes?: string;
}

const contractSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    contractNo: { type: Type.STRING, description: 'Ejari or Contract registration number' },
    ownerName: { type: Type.STRING, description: 'Name of the property owner' },
    lessorName: { type: Type.STRING, description: 'Name of the lessor / landlord / property management' },
    tenantName: { type: Type.STRING, description: 'Name of the tenant' },
    buildingName: { type: Type.STRING, description: 'Building or property development name' },
    propertyNo: { type: Type.STRING, description: 'Unit number / apartment / flat number' },
    contractType: { type: Type.STRING, description: 'UAE VAT Law tenancy classification: "Commercial" (offices, shops, retail, warehouse) or "Residence" (apartments, villas, residential flats)' },
    propertyType: { type: Type.STRING, description: 'Property type e.g. Residential, Commercial, Industrial' },
    subType: { type: Type.STRING, description: 'Property sub-type e.g. Apartment, Villa, Office, Warehouse, Shop' },
    size: { type: Type.STRING, description: 'Size of unit e.g. 1,250 Sq.Ft or Sq.M' },
    contractAmount: { type: Type.NUMBER, description: 'Total contract amount in AED (UAE Dirhams)' },
    actualAnnualAmount: { type: Type.NUMBER, description: 'Actual annual rent amount in AED' },
    vatRate: { type: Type.NUMBER, description: 'UAE VAT percentage rate: 5 for Commercial contracts, 0 for Residence contracts' },
    vatAmount: { type: Type.NUMBER, description: 'UAE VAT amount in AED: 5% of actual annual rent for Commercial, 0 for Residence' },
    totalAmountWithVat: { type: Type.NUMBER, description: 'Total annual rent including VAT in AED (actualAnnualAmount + vatAmount)' },
    securityDeposit: { type: Type.NUMBER, description: 'Security deposit in AED' },
    startDate: { type: Type.STRING, description: 'Contract start date in YYYY-MM-DD format (e.g. 2026-02-01)' },
    endDate: { type: Type.STRING, description: 'Contract end date in YYYY-MM-DD format (e.g. 2027-01-31)' },
    registrationDate: { type: Type.STRING, description: 'Registration or Ejari issue date in YYYY-MM-DD format (e.g. 2026-01-15)' },
  },
};

const receiptSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    receiptNo: { type: Type.STRING, description: 'Receipt voucher or serial number' },
    installmentDate: { type: Type.STRING, description: 'Date of installment or receipt in YYYY-MM-DD (e.g. 2026-03-01)' },
    amount: { type: Type.NUMBER, description: 'Amount paid or received in AED' },
    chequeNo: { type: Type.STRING, description: 'Cheque number or payment transaction reference' },
    bankName: { type: Type.STRING, description: 'Bank name e.g. Emirates NBD, ADCB, FAB, DIB, Mashreq' },
    tenantName: { type: Type.STRING, description: 'Tenant or payer name' },
    propertyRef: { type: Type.STRING, description: 'Unit or building reference' },
  },
};

const invoiceSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    invoiceNumber: { type: Type.STRING, description: 'Supplier Tax Invoice number' },
    invoiceDate: { type: Type.STRING, description: 'Invoice date in YYYY-MM-DD format (e.g. 2026-02-10)' },
    supplierName: { type: Type.STRING, description: 'Supplier / Contractor / Vendor company name' },
    supplierTrn: { type: Type.STRING, description: 'UAE 15-digit Tax Registration Number (TRN)' },
    expenseCategory: { type: Type.STRING, description: 'Category e.g. Maintenance, HVAC/AC, Plumbing, Electrical, Cleaning' },
    netAmount: { type: Type.NUMBER, description: 'Net amount before VAT in AED' },
    taxAmount: { type: Type.NUMBER, description: 'VAT amount in AED (UAE 5% standard VAT)' },
    totalInvoiceAmount: { type: Type.NUMBER, description: 'Total gross invoice amount including VAT in AED' },
    buildingRef: { type: Type.STRING, description: 'Building or property unit reference' },
  },
};

const mainSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    detectedType: {
      type: Type.STRING,
      enum: ['contract', 'receipt', 'invoice'],
      description: 'Document classification: contract (UAE Tenancy/Ejari), receipt (rent receipt/cheque), or invoice (purchase tax invoice)',
    },
    confidence: { type: Type.NUMBER, description: 'Confidence score from 0.0 to 1.0' },
    contract: contractSchema,
    receipt: receiptSchema,
    invoice: invoiceSchema,
    summaryNotes: { type: Type.STRING, description: 'Brief 1-line summary in English describing the document' },
  },
  required: ['detectedType'],
};

export async function processDocumentWithGemini(
  base64Data: string,
  rawMimeType: string,
  fileName: string,
  targetType?: string
): Promise<ExtractionResult> {
  // Normalize mime type based on extension
  const lowerName = (fileName || '').toLowerCase();
  let mimeType = rawMimeType || 'application/pdf';
  if (lowerName.endsWith('.pdf')) {
    mimeType = 'application/pdf';
  } else if (lowerName.endsWith('.png')) {
    mimeType = 'image/png';
  } else if (lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg')) {
    mimeType = 'image/jpeg';
  }

  const prompt = `You are an expert UAE Real Estate, Ejari & Tax Auditor AI system.
Thoroughly examine this document (${fileName}) which is a PDF document or image of:
1. UAE Tenancy Contract (Unified Tenancy Contract / Ejari registration certificate / tenancy agreement)
2. Rental Installment Receipt / Cheque acknowledgment / payment voucher
3. Purchase Tax Invoice / Maintenance bill (with UAE 5% VAT)

CRITICAL INSTRUCTIONS FOR DATES:
- Look carefully across all tables, headers, Ejari stamps, and footers for dates:
  * For Tenancy Contracts:
    - Start Date: Usually labeled as "Contract Period From", "Start Date", "Lease Start", or "From"
    - End Date: Usually labeled as "To Date", "Contract Period To", "End Date", or "To"
    - Registration Date: Usually labeled as "Registration Date", "Ejari Issue Date", "Issue Date", "Date of Registration"
  * For Receipts:
    - Installment Date: Labeled as "Receipt Date", "Date", "Cheque Date", or "Payment Date"
  * For Tax Invoices:
    - Invoice Date: Labeled as "Invoice Date", "Tax Invoice Date", "Issue Date", or "Date"
- Date Normalization: Convert all dates (e.g. "15/02/2026", "1-Jan-2026", "2026.03.01", "12-05-2026") into standard ISO format: YYYY-MM-DD.

CRITICAL INSTRUCTIONS FOR FINANCIAL AMOUNTS:
- All monetary values must be numeric in UAE Dirhams (AED). Do not add currency symbols or commas in the numeric fields.
- Contract Amount: Total rent for the contract duration in AED.
- Actual Annual Amount: Annual rent amount in AED.
- Security Deposit: Deposit amount in AED.
- Total Invoice Amount: Gross total in AED including 5% VAT.
- Tax Amount: 5% VAT amount in AED.
- Net Amount: Subtotal before VAT in AED.

CRITICAL INSTRUCTIONS FOR TENANCY CONTRACT TYPE & UAE VAT LAW:
- Classify the Tenancy Contract into one of two official types:
  1. "Commercial" — for offices, shops, retail units, showrooms, warehouses, commercial buildings.
  2. "Residence" — for residential apartments, flats, villas, penthouses, townhouses.
- As per UAE VAT Law (Federal Decree-Law No. (8) of 2017):
  * Commercial leases are subject to 5% Standard VAT on the actual annual rent. Set vatRate = 5, vatAmount = actualAnnualAmount * 0.05, totalAmountWithVat = actualAnnualAmount + vatAmount.
  * Residence leases are Exempt from VAT (0% VAT). Set vatRate = 0, vatAmount = 0, totalAmountWithVat = actualAnnualAmount.

${targetType && targetType !== 'auto' ? `- Note: The user classified this document as a ${targetType}. Prioritize that structure if applicable.` : ''}

Output strictly structured JSON according to the schema provided.`;

  const cleanBase64 = base64Data.includes(',')
    ? base64Data.split(',')[1].replace(/\s/g, '')
    : base64Data.replace(/\s/g, '');

  // Models in priority order with fallback to handle regional load spikes
  const candidateModels = ['gemini-3.1-flash-lite', 'gemini-3.8-flash', 'gemini-flash-latest'];
  let lastError: any = null;

  for (const modelName of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: [
          {
            role: 'user',
            parts: [
              { text: prompt },
              {
                inlineData: {
                  data: cleanBase64,
                  mimeType,
                },
              },
            ],
          },
        ],
        config: {
          responseMimeType: 'application/json',
          responseSchema: mainSchema,
          temperature: 0.1,
        },
      });

      const text = response.text;
      if (!text) {
        throw new Error(`Empty response from model ${modelName}`);
      }

      const parsed = JSON.parse(text) as ExtractionResult;

      // Post-processing: normalize UAE VAT Law rules on Tenancy Contract
      if (parsed.contract) {
        const cType = (parsed.contract.contractType || parsed.contract.propertyType || '').toLowerCase();
        const isCommercial =
          cType.includes('commercial') ||
          cType.includes('office') ||
          cType.includes('retail') ||
          cType.includes('shop') ||
          cType.includes('warehouse') ||
          cType.includes('industrial');

        const rent = Number(parsed.contract.actualAnnualAmount) || Number(parsed.contract.contractAmount) || 0;
        parsed.contract.contractType = isCommercial ? 'Commercial' : 'Residence';
        parsed.contract.vatRate = isCommercial ? 5 : 0;
        parsed.contract.vatAmount = isCommercial ? Math.round(rent * 0.05 * 100) / 100 : 0;
        parsed.contract.totalAmountWithVat = Math.round((rent + (parsed.contract.vatAmount || 0)) * 100) / 100;
      }

      return parsed;
    } catch (err: any) {
      console.warn(`Model ${modelName} failed, trying next candidate...`, err.message || err);
      lastError = err;
    }
  }

  throw lastError || new Error('Failed to process document with Gemini OCR.');
}
